
#include "search.h"

#include "globals.h"
#include "option_parser.h"
#include "global_state.h"
#include "global_operator.h"
#include "heuristic.h"
#include "unsatisfiability_heuristic.h"
#include "open_sets.h"
#include "state_registry.h"
#include "successor_generator.h"
#include "plugin.h"

#include <iostream>
#include <vector>
#include <unordered_set>
#include <cstdio>

#include <cassert>

Search::Search(const Options &opts)
    : SearchEngine(opts),
    search_space(cost_type),
    _num_expansions(1),
    unsath_refine(opts.get<bool>("u_refine")),
    c_unsath_new(opts.get<bool>("u_new")),
    c_unsath_open(opts.get<bool>("u_open")),
    c_unsath_closed(opts.get<bool>("u_closed")),
    open_set(opts.get<OpenSet*>("open_set")),
    init_state_id(StateID::no_state)
{
    search_h = NULL;
    unsat_h = NULL;
    unsat_h_search = NULL;
    if (opts.contains("search_h")) {
        search_h = opts.get<Heuristic*>("search_h");
    }
    if (opts.contains("unsat_h")) {
        unsat_h = opts.get<UnsatisfiabilityHeuristic*>("unsat_h");
    }
    if (unsat_h && !search_h) {
        unsat_h_search = dynamic_cast<Heuristic*>(unsat_h);
    }
}

bool Search::check_goal_and_set_plan(const GlobalState &state) {
    if (test_goal(state)) {
        std::cout << "Solution found!" << std::endl;
        Plan plan;
        search_space.trace_path(state, plan);
        set_plan(plan);
        return true;
    }
    return false;
}

void Search::evaluate(const GlobalState &state) {
    cached_dead_end = false;
    if (search_h) {
        search_progress.inc_evaluations(1);
        search_progress.inc_evaluated_states(1);
        search_h->evaluate(state);
        cached_h = search_h->get_value();
        cached_dead_end = search_h->dead_ends_are_reliable() && search_h->is_dead_end();
    }
    if (!cached_dead_end && unsat_h) {
        //cached_dead_end = unsat_h->slow_dead_end_check(state);
        if (c_unsath_new) {
            cached_dead_end = unsat_h->evaluate_dead_end(state);
            search_progress.inc_evaluations(1);
            search_progress.inc_evaluated_states(1);
        } else {
            //cached_dead_end = unsat_h->fast_dead_end_check(state);
        }
        if (!search_h && unsat_h_search && c_unsath_new && !cached_dead_end) {
            cached_h = unsat_h_search->get_value();
        }
    }
}

void Search::initialize() {
    GlobalState init = g_initial_state();
    evaluate(init);
    if (!cached_dead_end) {
        SearchNode node = search_space.get_node(init);
        node.open_initial(cached_dead_end);
        open_set->push(node);
    }
    init_state_id = init.get_id();
}

void Search::print_statistics() const {
    if (unsat_h) {
        unsat_h->print_statistics();
    }
    search_progress.print_statistics();
    printf("Registered: %zu state(s).\n", g_state_registry->size());
}

SearchStatus Search::step() {
    if (open_set->empty()) {
        print_statistics();
        return FAILED;
    }
    StateID state_id = open_set->pop();
    GlobalState state = g_state_registry->lookup_state(state_id);
    SearchNode node = search_space.get_node(state);
    if (node.is_closed() || node.is_dead_end()) {
        return IN_PROGRESS;
    }
    if (check_goal_and_set_plan(state)) {
        print_statistics();
        return SOLVED;
    }

    _num_expansions++;

    if (unsat_h) {
        bool dead_end = false;
        if (c_unsath_open) {
            dead_end = unsat_h->evaluate_dead_end(state);
        } else  {
            //dead_end = unsat_h->fast_dead_end_check(state);
        }
        // TODO: add option to not evaluate this at all
        if (dead_end) {
            node.mark_as_dead_end();
            if (unsath_refine) {
                backward_propagation(state);
            }
            return IN_PROGRESS;
        }
    }

    search_progress.inc_expanded(1);
    node.close();
    std::vector<const GlobalOperator *> ops;
    g_successor_generator->generate_applicable_ops(state, ops);
    bool non_closed_child = false;
    std::vector<StateID> &successors = node.get_all_successors();
    successors.resize(ops.size(), StateID::no_state);
    for (uint i = 0; i < ops.size(); i++) {
        search_progress.inc_generated(1);
        GlobalState succ = g_state_registry->get_successor_state(state, *ops[i]);
        SearchNode succ_node = search_space.get_node(succ);
        successors[i] = succ_node.get_state_id();
        succ_node.add_parent(state);
        if (succ_node.is_new()) {
            evaluate(succ);
            if (cached_dead_end) {
                search_progress.inc_dead_ends(1);
                succ_node.mark_as_dead_end();
            } else {
                succ_node.open(cached_h, node, ops[i]);
            }
        }

        if (succ_node.is_open()) {
            non_closed_child = true;
            open_set->push(succ_node);
        }
    }

    if (!non_closed_child && !open_set->empty()) {
        check_and_learn_dead_end(node);
    }

    return IN_PROGRESS;
}

bool Search::check_and_learn_dead_end(const SearchNode &node)
{
    if (!unsat_h || !unsath_refine) {
        return false;
    }

    GlobalState node_state = node.get_state();

    // setup search for open node in search space
    std::vector<GlobalState> open_states;
    std::vector<GlobalState> visited;
    std::unordered_set<StateID> recognized_neighbors;
    bool open_node_reachable = false;
    //dedet_statistics.start_open_node_search();
    bool initial_state = false;
    open_node_reachable = search_open_state(node, visited, recognized_neighbors, open_states, initial_state);
    //dedet_statistics.end_open_node_search(visited.size(), 0);

    bool is_dead_end = false;
    // if node is a dead end
    if (!open_node_reachable) {
        if (initial_state) {
            return false;
        }
#ifndef NDEBUG
        for (const GlobalState &state : visited) {
            SearchNode node = search_space.get_node(state);
            assert(node.is_flagged());
        }
        if (unsat_h->refinement_requires_rn()) {
            for (const GlobalState &state : visited) {
                SearchNode node = search_space.get_node(state);
                const std::vector<StateID> &succs = node.get_all_successors();
                for (uint i = 0; i < succs.size(); i++) {
                    SearchNode succ_node = search_space.get_node(g_state_registry->lookup_state(succs[i]));
                    assert(succ_node.is_flagged() || recognized_neighbors.count(succs[i]));
                }
            }
        }
#endif

#ifndef NDEBUG
        std::cout << "Dead end refinement check ..." << std::endl;
#endif
        //cout << "LearnC>>>" << endl;
        // try to refine C if requirements are met
        //dedet_statistics.refinement_start();
        is_dead_end = unsat_h->refine(visited, recognized_neighbors);
        if (!is_dead_end) {
            unsath_refine = false;
        }
        //dedet_statistics.refinement_end();

#ifndef NDEBUG
        unsat_h->print_statistics_short();
#endif
    }

    for (uint i = 0; i < visited.size(); i++) {
        SearchNode v_node = search_space.get_node(visited[i]);
        if (is_dead_end) {
            v_node.mark_as_dead_end();
        }
        v_node.set_flag(false);
    }

    recognized_neighbors.clear();

    if (is_dead_end) {
        backward_propagation(visited);
    }
    visited.clear();

    if (is_dead_end) {
        backward_propagation(open_states);
    }
    open_states.clear();

    return is_dead_end;
}

bool Search::search_open_state(SearchNode node,
        std::vector<GlobalState> &closed_states,
        std::unordered_set<StateID> &rn,
        std::vector<GlobalState> &open_states,
        bool &init)
{
    if (node.get_expansion_counter() == _num_expansions) {
        return true;
    }

    closed_states.push_back(node.get_state());
    node.set_expansion_counter(_num_expansions);
    node.set_flag();

    unsigned i = 0;
    while (i < closed_states.size()) {
        GlobalState state = closed_states[i++];
        SearchNode node = search_space.get_node(state);
        init = init || state.get_id() == init_state_id;
        const std::vector<StateID> &successors = node.get_all_successors();
        for (unsigned j = 0; j < successors.size(); j++) {
            GlobalState succ = g_state_registry->lookup_state(successors[j]);
            SearchNode succ_node = search_space.get_node(succ);
            if (succ_node.is_flagged()) {
                continue;
            }
            if (succ_node.is_dead_end()) {
                if (unsat_h->refinement_requires_rn()) {
                    rn.insert(succ.get_id());
                }
                continue;
            }
            if (succ_node.get_expansion_counter() == _num_expansions
                    || succ_node.is_open()) {
                return true;
            }
            bool dead_end = false;
            if (c_unsath_closed) {
                dead_end = unsat_h->evaluate_dead_end(succ);
            } else {
                // TODO: add option to not evaluate this et all
                dead_end = unsat_h->fast_dead_end_check(succ);
            }
            if (dead_end) {
                mark_dead_ends(succ_node, open_states);
                rn.insert(succ.get_id());
                continue;
            }
            succ_node.set_expansion_counter(_num_expansions);
            succ_node.set_flag();
            closed_states.push_back(succ);
        }
    }

    return false;
}

void Search::backward_propagation(const GlobalState &state)
{
    assert(unsat_h != NULL);
    assert(unsath_refine);
    SearchNode snode = search_space.get_node(state);
    const std::unordered_set<StateID> &parents = snode.get_all_parents();
    for (std::unordered_set<StateID>::const_iterator it = parents.begin();
           it != parents.end(); it++) {
        GlobalState parent = g_state_registry->lookup_state(*it);
        SearchNode node = search_space.get_node(parent);
        if (!node.is_dead_end()) { // && !node.is_open_node_reachable(expansion_counter)) {
            //dedet_statistics.h_dedet_re_evaluation_start();
            // TODO rember some kind of revision of uC evaluation to speed up things here
            bool is_dead_end = unsat_h->evaluate_dead_end(parent);
            //dedet_statistics.h_dedet_re_evaluation_end(dedet_identifier->is_dead_end());
            if (is_dead_end) {
                std::vector<GlobalState> open;
                mark_dead_ends(node, open);
                backward_propagation(open);
                open.clear();
            } else {
                check_and_learn_dead_end(node);
            }
        }
    }
}

void Search::backward_propagation(const std::vector<GlobalState> &states)
{
    for (unsigned i = 0; i < states.size(); i++) {
        backward_propagation(states[i]);
    }
}

void Search::mark_dead_ends(SearchNode node, std::vector<GlobalState> &open)
{
    // TODO: when marking state dead end, clear parents and successor pointers
    // (before doing that have to do bw prop of >open< states)
    std::vector<GlobalState> dead_ends;
    dead_ends.push_back(node.get_state());
    mark_dead_ends(dead_ends, open);
    // TODO: delete dead_ends[0]?
    unsat_h->learn(dead_ends);
    dead_ends.clear();
}

void Search::mark_dead_ends(std::vector<GlobalState> &dead_ends, std::vector<GlobalState> &open)
{
    unsigned i = 0;
    while (i < dead_ends.size()) {
        GlobalState state = dead_ends[i++];
        SearchNode node = search_space.get_node(state);
        const std::vector<StateID> &successors = node.get_all_successors();
        for (uint j = 0; j < successors.size(); j++) {
            GlobalState succ = g_state_registry->lookup_state(successors[j]);
            SearchNode succ_node = search_space.get_node(succ);
            if (succ_node.is_open()) {
                succ_node.close();
                open.push_back(succ);
            }
            if (!succ_node.is_dead_end()) {
                succ_node.mark_as_dead_end();
                dead_ends.push_back(succ);
            }
        }
    }
}

void Search::add_options_to_parser(OptionParser &parser) {
    SearchEngine::add_options_to_parser(parser);
    parser.add_option<OpenSet*>("open_set", "", "dfsh");
    parser.add_option<Heuristic*>("search_h", "", "", OptionFlags(false));
    parser.add_option<UnsatisfiabilityHeuristic*>("unsat_h", "", "", OptionFlags(false));
    parser.add_option<bool>("u_refine", "", "true");
    parser.add_option<bool>("u_new", "", "false");
    parser.add_option<bool>("u_open", "", "true");
    parser.add_option<bool>("u_closed", "", "false");
}

static SearchEngine *_parse(OptionParser &parser) {
    Search::add_options_to_parser(parser);
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new Search(opts);
    }
    return NULL;
}

static Plugin<SearchEngine> _plugin_search("search", _parse);

