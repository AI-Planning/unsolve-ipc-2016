
#ifndef UNSATISFIABILITY_HEURISTIC_H
#define UNSATISFIABILITY_HEURISTIC_H

#include "heuristic.h"
#include "state_id.h"

#include <vector>
#include <unordered_set>

class GlobalState;

class UnsatisfiabilityHeuristic {
public:
    UnsatisfiabilityHeuristic(const Options &opts);
    virtual bool evaluate_dead_end(const GlobalState &state) = 0;
    // Learn to recognize UNRECOGNIZED dead ends:
    virtual bool refine(const std::vector<GlobalState> &root,
            const std::unordered_set<StateID> &rn) = 0;
    // Learn to recognize RECOGNIZED dead ends more quickly:
    virtual void learn(const std::vector<GlobalState> &dead_ends) = 0;
    virtual void learn(const GlobalState &state) = 0;
    virtual bool fast_dead_end_check(const GlobalState &state) = 0;
    virtual bool slow_dead_end_check(const GlobalState &state) = 0;
    virtual bool is_refinement_enabled() const = 0;
    virtual bool refinement_requires_rn() const = 0;
    virtual bool refinement_requires_scc() const = 0;
    virtual void print_statistics() const = 0;
    virtual void print_statistics_short() const {};
};

#endif
