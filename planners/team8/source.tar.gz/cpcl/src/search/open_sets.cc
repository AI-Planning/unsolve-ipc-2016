
#include "open_sets.h"
#include "search_space.h"
#include "option_parser.h"
#include "plugin.h"

#include "rng.h"

#include <list>
#include <queue>
#include <cassert>

class DFShOpenSet : public OpenSet
{
protected:
    std::list<std::priority_queue<std::pair<int, int> > > open_list;
    size_t _size;
    bool newdepth;
public:
    DFShOpenSet(const Options &opts)
        : OpenSet(opts),
          _size(0),
          newdepth(true) {}
    virtual void push(const SearchNode &node) {
        if (newdepth) {
            open_list.push_front(std::priority_queue<std::pair<int, int> >());
            newdepth = false;
        }
        open_list.front().push(std::make_pair(node.get_h(),
                                              node.get_state_id().hash()));
        _size++;
    }
    virtual StateID pop() {
        newdepth = true;
        assert(_size > 0);
        std::priority_queue<std::pair<int, int> > &top = open_list.front();
        assert(top.size() > 0);
        StateID elem = StateID(top.top().second);
        top.pop();
        if (top.size() == 0) {
            open_list.pop_front();
        }
        _size--;
        return elem;
    }
    virtual size_t size() const {
        return _size;
    }
    virtual bool empty() const {
        return size() == 0;
    }
    virtual void clear() {
        open_list.clear();
    }
    static void add_options_to_parser(OptionParser &) {
    }
};

static OpenSet *_parse_dfsh(OptionParser &parser)
{
    DFShOpenSet::add_options_to_parser(parser);
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new DFShOpenSet(opts);
    }
    return NULL;
}

static Plugin<OpenSet> _plugin_dfsh("dfsh", _parse_dfsh);

class DFSRandomTiesOpenSet : public OpenSet
{
protected:
    std::list<std::list<int> > open_list;
    size_t _size;
    bool newdepth;
    RandomNumberGenerator rng;
public:
    DFSRandomTiesOpenSet(const Options &opts)
        : OpenSet(opts),
          _size(0),
          newdepth(true),
          rng(opts.get<int>("seed")) {}
    virtual void push(const SearchNode &node) {
        if (newdepth) {
            open_list.push_front(std::list<int>());
            newdepth = false;
        }
        std::list<int> &l = open_list.front();
        std::list<int>::iterator it = std::next(l.begin(),
                (l.empty() ? 0 : rng.next32() % l.size()) + 1);
        l.insert(it, node.get_state_id().hash());
        _size++;
    }
    virtual StateID pop() {
        newdepth = true;
        assert(_size > 0);
        std::list<int> &l = open_list.front();
        StateID elem(l.front());
        l.pop_front();
        if (l.empty()) {
            open_list.pop_front();
        }
        _size--;
        return elem;
    }
    virtual size_t size() const {
        return _size;
    }
    virtual bool empty() const {
        return size() == 0;
    }
    virtual void clear() {
        open_list.clear();
    }
    static void add_options_to_parser(OptionParser &p) {
        p.add_option<int>("seed", "", "1");
    }
};

static OpenSet *_parse_dfsrt(OptionParser &parser)
{
    DFSRandomTiesOpenSet::add_options_to_parser(parser);
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new DFSRandomTiesOpenSet(opts);
    }
    return NULL;
}

static Plugin<OpenSet> _plugin_dfsrt("dfsrt", _parse_dfsrt);




