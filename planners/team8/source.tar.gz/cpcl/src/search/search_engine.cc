#include "search_engine.h"

#include "countdown_timer.h"
#include "globals.h"
#include "operator_cost.h"
#include "option_parser.h"

#include <cassert>
#include <iostream>
#include <limits>

using namespace std;


SearchEngine::SearchEngine(const Options &opts)
    : status(IN_PROGRESS),
      solution_found(false),
      cost_type(OperatorCost(opts.get_enum("cost_type"))),
      max_time(opts.get<double>("max_time"))
{
}

SearchEngine::~SearchEngine()
{
}

void SearchEngine::statistics() const
{
}

bool SearchEngine::found_solution() const
{
    return solution_found;
}

SearchStatus SearchEngine::get_status() const
{
    return status;
}

const SearchEngine::Plan &SearchEngine::get_plan() const
{
    assert(solution_found);
    return plan;
}

void SearchEngine::set_plan(const Plan &p)
{
    solution_found = true;
    plan = p;
}

void SearchEngine::search()
{
    initialize();
    CountdownTimer timer(max_time);
    while (status == IN_PROGRESS) {
        status = step();
        if (timer.is_expired()) {
            cout << "Time limit reached. Abort search." << endl;
            status = TIMEOUT;
            break;
        }
    }
    cout << "Actual search time: " << timer
         << " [t=" << g_timer << "]" << endl;
}

void SearchEngine::save_plan_if_necessary() const
{
    if (found_solution()) {
        save_plan(get_plan(), 0);
    }
}

int SearchEngine::get_adjusted_cost(const GlobalOperator &op) const
{
    return get_adjusted_action_cost(op, cost_type);
}

void SearchEngine::add_options_to_parser(OptionParser &parser)
{
    ::add_cost_type_option_to_parser(parser);
    parser.add_option<int>(
        "bound",
        "exclusive depth bound on g-values. Cutoffs are always performed according to "
        "the real cost, regardless of the cost_type parameter", "infinity");
    parser.add_option<double>(
        "max_time",
        "maximum time in seconds the search is allowed to run for. The "
        "timeout is only checked after each complete search step "
        "(usually a node expansion), so the actual runtime can be arbitrarily "
        "longer. Therefore, this parameter should not be used for time-limiting "
        "experiments. Timed-out searches are treated as failed searches, "
        "just like incomplete search algorithms that exhaust their search space.",
        "infinity");
}
