
#include "unsatisfiability_heuristic.h"

#include "option_parser.h"

UnsatisfiabilityHeuristic::UnsatisfiabilityHeuristic(const Options &)
{}
