
#include "uc_refinement.h"
#include "conjunction_operations.h"

#include "../globals.h"
#include "../option_parser.h"
#include "../global_state.h"
#include "../state_registry.h"
#include "../plugin.h"

#include <algorithm>
#include <cassert>

#include <boost/dynamic_bitset.hpp>
#include <map>

#define BOOST_DYNAMIC_BITSET_DONT_USE_FRIENDS

namespace boost {
    template <typename B, typename A>
    std::size_t hash_value(const boost::dynamic_bitset<B, A>& bs) {
        return boost::hash_value(bs.m_bits);
    }
}

RNUCRefinement::RNUCRefinement(const Options &opts)
    : UCRefinement(opts), c_use_root_state_conflicts(true)
{}

void RNUCRefinement::set_rn_initializer(RNInitializer *initializer)
{
    rn_initializer = initializer;
}

bool RNUCRefinement::prepare_refinement(HCHeuristic *h,
                            const std::vector<GlobalState> &states,
                            const std::unordered_set<StateID> &rn)
{
    bool _early = h->set_early_termination(false);
    h->evaluate(states[0]);
    h->set_early_termination(_early);
    if (h->is_dead_end()) {
        return true;
    }

    _comp = &states;

    this->h = h;

    facts_to_conflicts.resize(g_variable_domain.size());
    for (unsigned var = 0; var < facts_to_conflicts.size(); var++) {
        facts_to_conflicts[var].resize(g_variable_domain[var]);
    }

    state_component_size = states.size();
    current_states.resize(h->num_facts());
    for (unsigned var = 0; var < g_variable_domain.size(); var++) {
        for (int val = 0; val < g_variable_domain[var]; val++) {
            unsigned f = h->get_fact_id(var, val);
            for (unsigned state = 0; state < states.size(); state++) {
                if (states[state][var] != val) {
                    current_states[f].push_back(state);
                }
            }
        }
    }

    if (c_use_root_state_conflicts) {
        root_conflicts.resize(h->num_facts());
        for (unsigned i = 0; i < h->num_conjunctions(); i++) {
            if (!h->get_conjunction(i).is_achieved()) {
                const Fluent &fluent = h->get_fluent(i);
                for (Fluent::const_iterator it = fluent.begin(); it != fluent.end(); it++) {
                    root_conflicts[h->get_fact_id(it->first, it->second)].push_back(i);
                }
            }
        }
    }

    successor_conflicts.resize(h->num_conjunctions());
    recognized_neighborhood_size = 0;
    for (std::unordered_set<StateID>::const_iterator succ_id = rn.begin();
         succ_id != rn.end(); succ_id++) {
        (*rn_initializer)(h, *succ_id);
        //GlobalState succ = g_state_registry->lookup_state(*succ_id);
        //h->evaluate(succ);
        for (unsigned i = 0; i < h->num_conjunctions(); i++) {
            const Conjunction &conj = h->get_conjunction(i);
            if (!conj.is_achieved()) {
                successor_conflicts[i].push_back(recognized_neighborhood_size);
            }
        }
        recognized_neighborhood_size++;
    }

    return false;
}

bool RNUCRefinement::refine(HCHeuristic *h,
                            const std::vector<GlobalState> &states,
                            const std::unordered_set<StateID> &rn)
{
    assert(states.size() > 0);

    if (prepare_refinement(h, states, rn)) {
        return true;
    }

    Fluent goal;
    for (uint i = 0; i < g_goal.size(); i++) {
        goal.insert(g_goal[i]);
    }

    compute_conflict_set(goal);

    bool res = h->update_c(_conflicts);

    this->h = NULL;
    current_states.clear();
    facts_to_conflicts.clear();
    _conflicts.clear();
    root_conflicts.clear();
    successor_conflicts.clear();

    return res;
}

bool RNUCRefinement::conflict_exists(const Fluent &subgoal) const
{
    std::vector<int> subset;

    if (c_use_root_state_conflicts) {
        subset.resize(h->num_conjunctions(), 0);
        for (Fluent::const_iterator it = subgoal.begin(); it != subgoal.end(); it++) {
            const std::vector<int> &conjs =
                root_conflicts[h->get_fact_id(it->first, it->second)];
            for (const int & conj : conjs) {
                if (++subset[conj] == h->get_conjunction(conj).fluent_size) {
                    return true;
                }
            }
        }
    }

    subset.clear();
    subset.resize(_conflicts.size(), 0);
    for (Fluent::const_iterator it = subgoal.begin(); it != subgoal.end(); it++) {
        const std::vector<unsigned> &confls = facts_to_conflicts[it->first][it->second];
        for (const unsigned & confl : confls) {
            if ((unsigned) ++subset[confl] == _conflicts[confl].get_fluent().size()) {
                return true;
            }
        }
    }
    subset.clear();

    return false;
}

void RNUCRefinement::compute_conflict_set(Fluent &subgoal)
{
    if (conflict_exists(subgoal)) {
        return;
    }

    unsigned conflict_id = _conflicts.size();
    _conflicts.resize(_conflicts.size() + 1);
    Conflict &conflict = _conflicts.back();
    select_conflict(subgoal, conflict);
    break_subset(subgoal, conflict);

    for (Fluent::const_iterator it = conflict.get_fluent().begin();
         it != conflict.get_fluent().end(); it++) {
        facts_to_conflicts[it->first][it->second].push_back(conflict_id);
    }

    std::vector<int> can_add;
    h->compute_can_add(can_add, conflict.get_fluent());
    for (unsigned act = 0; act < can_add.size(); act++) {
        // NOTE that the conflict reference might become invalid due to vector
        // reallocation!
        if (can_add[act] != 1) {
            continue;
        }
        const StripsAction &action = h->get_action(act);

        Fluent pre;
        pre.insert(action.precondition.begin(), action.precondition.end());
        fluent_op::set_minus(_conflicts[conflict_id].get_fluent(), action.add_effect,
                             pre);

        if (!h->contains_mutex(pre)) {
            compute_conflict_set(pre);
        }
    }
    can_add.clear();
}

void RNUCRefinement::break_subset(const Fluent &subgoal,
                                  Conflict &conflict) const
{
    std::vector<bool> counter;
    counter.resize(h->num_facts(), false);
    std::vector<int> conflicts;
    conflicts.resize(state_component_size, -1);
    int togo = state_component_size;
    for (Fluent::const_iterator it = conflict.get_fluent().begin(); togo > 0
         && it != conflict.get_fluent().end();
         it++) {
        unsigned cid = h->get_fact_id(it->first, it->second);
        counter[cid] = true;
        for (const unsigned & s : current_states[cid]) {
            if (conflicts[s] == -1) {
                togo--;
            }
            conflicts[s] = cid;
        }
    }
    if (togo == 0) {
        return;
    }
    for (Fluent::const_iterator it = subgoal.begin(); togo > 0
         && it != subgoal.end();
         it++) {
        unsigned cid = h->get_fact_id(it->first, it->second);
        bool found_new = false;
        for (const unsigned & s : current_states[cid]) {
            if (conflicts[s] == -1) {
                found_new = true;
                break;
            }
        }
        if (found_new) {
            for (const unsigned & s : current_states[cid]) {
                if (conflicts[s] == -1) {
                    togo--;
                }
                conflicts[s] = cid;
            }
        }
    }
#ifndef NDEDBUG
    if (togo > 0) {
        std::cout << "COULD NOT ENSURE SUBSET PROPERTY!" << std::endl;
        h->dump_fluent_pddl(subgoal);
        std::cout << std::endl;
        for (uint i = 0; i < conflicts.size(); i++) {
            if (conflicts[i] == -1) {
                std::cout << "STATE " << i << std::endl;
                (*_comp)[i].dump_pddl();
            }
        }
    }
#endif
    assert(togo == 0);
    for (unsigned i = 0; i < conflicts.size(); i++) {
        assert(conflicts[i] >= 0);
        if (counter[conflicts[i]]) {
            continue;
        }
        counter[conflicts[i]] = true;
        conflict.merge(h->get_fluent(conflicts[i]));
    }
    counter.clear();
}



class GreedyRNUCRefinement : public RNUCRefinement {
protected:
    virtual void select_conflict(const Fluent &subgoal, Conflict &conflict);
public:
    GreedyRNUCRefinement(const Options &opts);
};


GreedyRNUCRefinement::GreedyRNUCRefinement(const Options &opts)
    : RNUCRefinement(opts) {}

void GreedyRNUCRefinement::select_conflict(const Fluent &subgoal,
        Conflict &conflict)
{
    std::vector<int> counter;
    counter.resize(h->num_conjunctions(), 0);
    std::vector<int> conflicts;
    conflicts.resize(recognized_neighborhood_size, -1);
    int togo = recognized_neighborhood_size;
    for (Fluent::const_iterator it = subgoal.begin(); togo > 0
         && it != subgoal.end();
         it++) {
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(h->get_fact_id(
                *it));
        for (const unsigned & cid : conjs) {
            if (++counter[cid] == h->get_conjunction(cid).fluent_size) {
                bool found_new = false;
                for (const unsigned & succ : successor_conflicts[cid]) {
                    if (conflicts[succ] == -1) {
                        found_new = true;
                        break;
                    }
                }
                if (found_new) {
                    for (int succ : successor_conflicts[cid]) {
                        if (conflicts[succ] == -1) {
                            togo--;
                        }
                        conflicts[succ] = cid;
                    }
                }
            }
        }
    }
    assert(togo == 0);
    counter.clear();
    counter.resize(h->num_conjunctions(), 0);
    for (unsigned i = 0; i < recognized_neighborhood_size; i++) {
        if (counter[conflicts[i]]) {
            continue;
        }
        counter[conflicts[i]] = 1;
        conflict.merge(h->get_fluent(conflicts[i]));
    }
    counter.clear();
}


template<typename T>
class Greedy2RNUCRefinement : public RNUCRefinement {
protected:
    const bool update_successors;
    const bool update_size;
    std::vector<int> open_successors;
    std::vector<int> open_facts;
    T update_best;
    //int c1_max_successors;
    //int c2_min_size;
    int best;
    unsigned best_pos;
    //bool update_best(int cid);
    virtual void select_conflict(const Fluent &subgoal, Conflict &conflict);
public:
    Greedy2RNUCRefinement(const Options &opts);
    static void add_options_to_parser(OptionParser &parser) {
        parser.add_option<bool>("u_succ", "", "true");
        parser.add_option<bool>("u_size", "", "false");
    }
};

template<typename T>
Greedy2RNUCRefinement<T>::Greedy2RNUCRefinement(const Options &opts)
    : RNUCRefinement(opts),
      update_successors(opts.get<bool>("u_succ")),
      update_size(opts.get<bool>("u_size")),
      update_best(open_successors, open_facts)
{}

template<typename T>
void Greedy2RNUCRefinement<T>::select_conflict(const Fluent &subgoal,
        Conflict &conflict)
{
    std::deque<unsigned> candidates;
    std::vector<int> counter;
    counter.resize(h->num_conjunctions(), 0);

    std::vector<std::vector<unsigned> > selected_conflicts;
    selected_conflicts.resize(recognized_neighborhood_size);

    open_successors.resize(h->num_conjunctions(), 0);
    open_facts.resize(h->num_conjunctions(), 0);

    best = -1;
    //c1_max_successors = -1;
    //c2_min_size = -1;

    update_best.reset();
    for (Fluent::const_iterator it = subgoal.begin(); it != subgoal.end();
         it++) {
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(h->get_fact_id(
                *it));
        for (const unsigned & cid : conjs) {
            if (++counter[cid] == h->get_conjunction(cid).fluent_size
                    && successor_conflicts[cid].size() > 0) {
                candidates.push_back(cid);
                for (const int &x : successor_conflicts[cid]) {
                    selected_conflicts[x].push_back(cid);
                }
                open_successors[cid] = successor_conflicts[cid].size();
                open_facts[cid] = h->get_fluent(cid).size();
                if (update_best(cid)) {
                    best = cid;
                    best_pos = candidates.size() - 1;
                }
            }
        }
    }

    std::vector<bool> successor_handled;
    successor_handled.resize(recognized_neighborhood_size, false);
    std::vector<bool> conjunction;
    conjunction.resize(h->num_facts(), false);

    int togo = recognized_neighborhood_size;
    while (togo > 0 && !candidates.empty()) {
        bool merge = false;

        for (const unsigned & i : successor_conflicts[best]) {
            if (!successor_handled[i]) {
                merge = true;
                successor_handled[i] = true;
                togo--;
                if (update_successors) {
                    for (const unsigned &cid : selected_conflicts[i]) {
                        --open_successors[cid];
                    }
                }
            }
        }

        if (merge) {
            conflict.merge(h->get_fluent(best));
        }

        if (update_size && open_facts[best] > 0) {
            const Fluent &fluent = h->get_fluent(best);
            for (const Fact &fact : fluent) {
                unsigned fid = h->get_fact_id(fact.first, fact.second);
                if (!conjunction[fid]) {
                    conjunction[fid] = true;
                    const std::vector<unsigned> &conjs = h->get_fact_conj_relation(fid);
                    for (const unsigned &cid : conjs) {
                        --open_facts[cid];
                    }
                }
            }
        }

        candidates.erase(candidates.begin() + best_pos);
        best = -1;
        best_pos = -1;
        update_best.reset();
#if 1
        uint i = 0;
        std::deque<unsigned>::iterator it = candidates.begin();
        while (it != candidates.end()) {
            if (open_successors[*it] == 0) {
                it = candidates.erase(it);
                continue;
            }
            if (open_facts[*it] == 0) {
                best = *it;
                best_pos = i;
                break;
            }
            if (update_best(*it)) {
                best = *it;
                best_pos = i;
            }
            it++;
            i++;
        }
#else
        std::vector<unsigned> newcandidates;
        newcandidates.reserve(candidates.size());
        for (uint i = 0; i < candidates.size(); i++) {
            unsigned cid = candidates[i];
            if (open_successors[cid] > 0) {
                newcandidates.push_back(cid);
                if (update_best(cid)) {
                    best_pos = newcandidates.size() - 1;
                }
            }
        }
        candidates.swap(newcandidates);
#endif
    }

    open_successors.clear();
    open_facts.clear();

    assert(togo == 0);
}

struct Sel1 {
    const std::vector<int> &open_successors;
    const std::vector<int> &open_facts;
    int c1_max_successors;
    int c2_min_size;
    bool resetted;
    Sel1(const std::vector<int> &open_successors, const std::vector<int> &open_facts)
        : open_successors(open_successors), open_facts(open_facts), resetted(true)
    {}
    bool operator()(int cid) {
        if (resetted ||
            open_facts[cid] == 0 ||
            open_successors[cid] > c1_max_successors ||
            (open_successors[cid] == c1_max_successors
             && open_facts[cid] < c2_min_size)) {
            c1_max_successors = open_successors[cid];
            c2_min_size = open_facts[cid];
            resetted = false;
            return true;
        }
        return false;
    }
    void reset() {
        resetted = true;
    }
};

struct Sel2 {
    const std::vector<int> &open_successors;
    const std::vector<int> &open_facts;
    int x, y;
    bool resetted;
    Sel2(const std::vector<int> &open_successors, const std::vector<int> &open_facts)
        : open_successors(open_successors), open_facts(open_facts), resetted(true)
    {}
    bool operator()(int cid) {
        if (resetted ||
            x < open_facts[cid] ||
            (x == open_facts[cid] && y > open_successors[cid])) {
            x = open_facts[cid];
            y = open_successors[cid];
            resetted = false;
            return true;
        }
        return false;
    }
    void reset() {
        resetted = true;
    }
};



class MinimalConflictSelectionRefinement : public RNUCRefinement {
protected:
    std::vector<int> _subset;
    //std::vector<bool> _handled;
    struct T {
        boost::dynamic_bitset<> facts;
        boost::dynamic_bitset<> succs;
        std::vector<int> subset;
        T(size_t facts, size_t succs) : facts(facts), succs(succs) {}
        T(const T &parent) : facts(parent.facts), succs(parent.succs), subset(parent.subset) {
#ifndef NDEBUG
            assert(facts.size() == parent.facts.size());
            assert(succs.size() == parent.succs.size());
            assert(subset.size() == parent.subset.size());
            for (uint i = 0; i < facts.size(); i++) {
                assert(facts.test(i) == parent.facts.test(i));
            }
            for (uint i = 0; i < succs.size(); i++) {
                assert(succs.test(i) == parent.succs.test(i));
            }
            for (uint i = 0; i < subset.size(); i++) {
                assert(subset[i] == parent.subset[i]);
            }
#endif
        }
        boost::dynamic_bitset<>::reference operator[](const unsigned &i) {
            return facts[i];
        }
        boost::dynamic_bitset<>::const_reference operator[](const unsigned &i) const {
            return facts[i];
        }
    };
    typedef std::map<unsigned, std::map<unsigned, std::deque<T*> > > OpenList;
    /*
    struct Hasher {
        const SegmentedVector<boost::dynamic_bitset<>> &state_space;
        Hasher(const SegmentedVector<boost::dynamic_bitset<>> &state_space)
            : state_space(state_space) {}
        size_t operator()(unsigned x) const {
            return boost::hash_value(state_space[x]);
        }
    };
    struct Comparator {
        const SegmentedVector<boost::dynamic_bitset<>> &state_space;
        Comparator(const SegmentedVector<boost::dynamic_bitset<>> &state_space)
            : state_space(state_space) {}
        bool operator()(unsigned x, unsigned y) const {
            return state_space[x] == state_space[y];
        }
    };*/
#if 0
    bool is_goal(const T &state, const Fluent &subgoal) {
        for (uint i = 0; i < _subset.size(); i++) _subset[i] = 0;
        for (uint i = 0; i < _handled.size(); i++) _handled[i] = false;
        int handled = _handled.size();
        unsigned index = 0;
        for (const Fact &f : subgoal) {
            if (!state[index++]) continue;
            const std::vector<unsigned> &conjs = h->get_fact_conj_relation(h->get_fact_id(f));
            for (const unsigned &x : conjs) {
                const std::vector<int> &succs = successor_conflicts[x];
                for (const int & i : succs) {
                    if (!_handled[i]) {
                        _handled[i] = true;
                        if (--handled == 0) break;
                    }
                }
                if (handled == 0) break;
            }
            if (handled == 0) break;
        }
        return handled == 0;
    }
#else
    bool is_goal(const T &state, const Fluent &) {
        return state.succs.count() == recognized_neighborhood_size;
    }
#endif
    void initialize_openlist(OpenList &open, const Fluent &, T *init) {
        open[0][0].push_back(init);
    }
    T* pop(OpenList &open) const {
        assert(!open.empty());
        OpenList::iterator it = open.begin();
        std::map<unsigned, std::deque<T*> > &x = it->second;
        assert(!x.empty());
        std::map<unsigned, std::deque<T*> >::reverse_iterator it2 = x.rbegin();
        T *res = it2->second.front();
        it2->second.pop_front();
        if (it2->second.empty()) {
            x.erase(--(it2.base()));
            if (x.empty()) {
                open.erase(it);
            }
        }
        return res;
    }
    void push(OpenList &open, T *state) {
        open[state->facts.count()][state->succs.size()].push_back(state);
    }
    void clear(OpenList &open) {
        for (OpenList::iterator it1 = open.begin(); it1 != open.end(); it1++) {
            for (std::map<unsigned, std::deque<T*> >::iterator it2 = it1->second.begin();
                    it2 != it1->second.end(); it2++) {
                for (std::deque<T*>::iterator it3 = it2->second.begin(); it3 != it2->second.end(); it3++) {
                    delete(*it3);
                }
            }
        }
        open.clear();
    }
    virtual void select_conflict(const Fluent &subgoal, Conflict &conflict);
public:
    MinimalConflictSelectionRefinement(const Options &opts);
};


MinimalConflictSelectionRefinement::MinimalConflictSelectionRefinement(const Options &opts)
    : RNUCRefinement(opts) {}

void MinimalConflictSelectionRefinement::select_conflict(const Fluent &subgoal,
        Conflict &conflict)
{
    _subset.resize(h->num_conjunctions());
    for (uint i = 0; i < _subset.size(); i++) _subset[i] = 0;

    unsigned index = 0;
    std::vector<unsigned> subgoal_facts;
    subgoal_facts.resize(subgoal.size(), -1);
    std::vector<unsigned> mapping;
    mapping.resize(h->num_facts(), -1);
    std::vector<std::vector<bool> > conflict_facts;
    conflict_facts.resize(recognized_neighborhood_size);
    for (uint i = 0; i < conflict_facts.size(); i++) {
        conflict_facts[i].resize(subgoal.size(), false);
    }
    for (Fluent::const_iterator it = subgoal.begin(); it != subgoal.end();
         it++) {
        subgoal_facts[index] = h->get_fact_id(*it);
        mapping[subgoal_facts[index]] = index;
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(subgoal_facts[index]);
        ++index;
        for (const unsigned & cid : conjs) {
            if (++_subset[cid] == h->get_conjunction(cid).fluent_size
                    && successor_conflicts[cid].size() > 0) {
                for (const int &x : successor_conflicts[cid]) {
                    const Fluent &fluent = h->get_fluent(cid);
                    for (const Fact &f : fluent) {
                        conflict_facts[x][mapping[h->get_fact_id(f)]] = true;
                    }
                }
            }
        }
    }
    mapping.clear();

    T *state = new T(subgoal.size(), recognized_neighborhood_size);
    state->subset.resize(h->num_conjunctions(), 0);

    OpenList open;
    initialize_openlist(open, subgoal, state);
    size_t size = 1;

    //std::cout << "START m = " << recognized_neighborhood_size << std::endl;

    while (size > 0) {
        state = pop(open);
        size--;
        //std::cout << "popped " << state->facts.count() << ", " << state->succs.count() << std::endl;
        //std::cout << "subset = [";
        //for (uint i = 0; i < state->subset.size(); i++) {
        //    std::cout << " " << state->subset[i];
        //}
        //std::cout << " ]" << std::endl;
        if (is_goal(*state, subgoal)) {
            index = 0;
            for (const Fact &fact : subgoal) {
                if (!(*state)[index++]) continue;
                unsigned fid = h->get_fact_id(fact);
                conflict.merge(h->get_fluent(fid));
            }
            break;
        }
        unsigned next = 0;
        for (index = subgoal.size(); index > 0; index--) {
            if ((*state)[index - 1]) {
                next = index;
                break;
            }
        }
        for (index = next; index < subgoal_facts.size(); index++) {
            bool expand = false;
            for (uint i = 0; !expand && i < recognized_neighborhood_size; i++) {
                expand = !(state->succs[i]) && conflict_facts[i][index];
            }
            if (!expand) {
                continue;
            }
            /*state_space.push_back(state->facts);
            boost::dynamic_bitset<> &tmp = state_space[state_space.size() - 1];
            tmp[index] = true;
            if (!closed.insert(state_space.size() - 1).second) {
                assert(false);
                state_space.pop_back();
                // POR should subsume duplicate pruning!
                continue;
            }*/
            T *succ = new T(*state);
            succ->facts[index] = true;
            const std::vector<unsigned> &conjs = h->get_fact_conj_relation(subgoal_facts[index]);
            //std::cout << " -(" << index << ")-> fact_id = " << subgoal_facts[index]
            //    << ", conjs.size() = " << conjs.size() << std::endl;
            for (const unsigned & i : conjs) {
                assert(i < succ->subset.size());
                //std::cout << " -----> subset[" << i << "]: " << succ->subset[i] << std::flush;
                succ->subset[i] = succ->subset[i] + 1;
                //std::cout << " -> " << succ->subset[i]
                //    << " (/" << h->get_conjunction(i).fluent_size << ")" << std::endl;
                if (succ->subset[i] == h->get_conjunction(i).fluent_size) {
                    //std::cout << " -------> is subset: " << successor_conflicts[i].size() << std::endl;
                    const std::vector<int> &succs = successor_conflicts[i];
                    for (const int & j : succs) {
                        if (!succ->succs[j]) {
                            succ->succs[j] = true;
                        }
                    }
                }
            }
            push(open, succ);
            size++;
            //std::cout << " -(" << index << ")-> " << size << ": "
            //    << succ->facts.count() << ", " << succ->succs.count() << std::endl;
            //std::cout << " -(" << index << ")-> subset = [";
            //for (uint i = 0; i < succ->subset.size(); i++) {
            //    std::cout << " " << succ->subset[i];
            //}
            //std::cout << " ]" << std::endl;
        }
        delete(state);
    }
    clear(open);

#ifndef NDEBUG
    unsigned _debug_not_covered = recognized_neighborhood_size;
    std::vector<bool> _debug_check;
    _debug_check.resize(recognized_neighborhood_size, false);
    _subset.resize(h->num_conjunctions());
    for (uint i = 0; i < _subset.size(); i++) _subset[i] = 0;
    for (const Fact &f : conflict.get_fluent()) {
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(h->get_fact_id(f));
        for (const unsigned &i : conjs) {
            if (++_subset[i] == h->get_conjunction(i).fluent_size) {
                for (const int &j : successor_conflicts[i]) {
                    if (!_debug_check[j]) {
                        _debug_check[j] = true;
                        _debug_not_covered--;
                    }
                }
            }
        }
    }
    assert(_debug_not_covered == 0);
#endif
}


static UCRefinement *_parse(OptionParser &parser)
{
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new GreedyRNUCRefinement(opts);
    }
    return NULL;
}

static Plugin<UCRefinement> bw("bw", _parse);

template<typename T>
static UCRefinement *_parse2(OptionParser &parser)
{
    Greedy2RNUCRefinement<T>::add_options_to_parser(parser);
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new Greedy2RNUCRefinement<T>(opts);
    }
    return NULL;
}

static Plugin<UCRefinement> bw2_1("bw2_1", _parse2<Sel1>);
static Plugin<UCRefinement> bw2_2("bw2_2", _parse2<Sel2>);

static UCRefinement *_parse_min(OptionParser &parser)
{
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new MinimalConflictSelectionRefinement(opts);
    }
    return NULL;
}

static Plugin<UCRefinement> minbw("minbw", _parse_min);


