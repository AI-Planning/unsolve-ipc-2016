
#include "uc_clause_learning.h"

#include "../globals.h"
#include "../global_state.h"
#include "../option_parser.h"
#include "../plugin.h"

GreedyStateMinClauseStore::GreedyStateMinClauseStore()
{
    fact_to_clause.resize(g_variable_domain.size());
    for (uint var = 0; var < fact_to_clause.size(); var++) {
        fact_to_clause[var].resize(g_variable_domain[var]);
    }
}

const GreedyStateMinClauseStore::Clause &GreedyStateMinClauseStore::operator[](unsigned i) const
{
    return clauses[i];
}

unsigned GreedyStateMinClauseStore::store(const Clause &clause)
{
    clauses.push_back(clause);
    for (uint i = 0; i < clause.size(); i++) {
        fact_to_clause[clause[i].first][clause[i].second].push_back(
            clause_sizes.size());
    }
    clause_sizes.push_back(clause.size());
    return clause_sizes.size() - 1;
}

unsigned GreedyStateMinClauseStore::find(HCHeuristic *, const GlobalState &state)
{
    std::vector<unsigned> subset;
    subset.resize(clause_sizes.size(), 0);
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        for (unsigned c : fact_to_clause[var][state[var]]) {
            if (++subset[c] == clause_sizes[c]) {
                return c;
            }
        }
    }
    return NO_MATCH;
}

size_t GreedyStateMinClauseStore::size() const
{
    return clause_sizes.size();
}






GreedyMinVarUCClauseLearning::GreedyMinVarUCClauseLearning(
    const Options &opts) : UCClauseLearning(opts) {}

bool GreedyMinVarUCClauseLearning::project_var(HCHeuristic *h, int var,
        int orig_val)
{
    std::vector<unsigned> exploration;
    exploration.reserve(h->num_conjunctions());

    // Add all values of the given variable to the current state
    for (int val = 0; val < g_variable_domain[var]; val++) {
        if (val == orig_val) {
            continue;
        }
        unsigned fid = h->get_fact_id(var, val);
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(fid);
        for (unsigned cid : conjs) {
            _state_conjs[cid]++;
            Conjunction &conj = h->get_conjunction(cid);

            // check whether all facts of the conjunctions are now contained
            // in the current state
            // however, if we have already achieved the conjunction in the
            // previous iteration of the hmax computation, then there is
            // nothing left to do
            if (!conj.is_achieved()
                && _state_conjs[cid] == conj.fluent_size) {
                conj.check_and_update(0, NULL);
                exploration.push_back(cid);
            }
        }
    }

    // check whether the state is still a dead end
    bool is_dead = h->simple_traversal_wrapper(exploration,
                   0) == Heuristic::DEAD_END;

    if (!is_dead) {
        // Have to revert all changes made during relaxed traversal
        // - all conjunctions that are contained in the exploration queue
        //  were unreachable before
        for (unsigned cid : exploration) {
            Conjunction &conj = h->get_conjunction(cid);
            conj.clear();
            const std::vector<ActionEffectCounter *> &triggered = conj.triggered_counters;
            for (size_t i = 0; i < triggered.size(); i++) {
                triggered[i]->unsatisfied_preconditions++;
            }
        }
        // Remove the facts from the current state that were added before
        for (int val = 0; val < g_variable_domain[var]; val++) {
            if (val == orig_val) {
                continue;
            }
            unsigned fid = h->get_fact_id(var, val);
            const std::vector<unsigned> &conjs = h->get_fact_conj_relation(fid);
            for (int cid : conjs) {
                _state_conjs[cid]--;
            }
        }
    }
    exploration.clear();
    return is_dead;
}

void GreedyMinVarUCClauseLearning::refine(HCHeuristic *h,
        const GlobalState &state)
{
    assert(h->is_dead_end());
    _state_conjs.resize(h->num_conjunctions(), 0);
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(
                h->get_fact_id(var, state[var]));
        for (int cid : conjs) {
            _state_conjs[cid]++;
        }
    }

    // try to project away each variable
    // if not possible, add it to the nogood
    GreedyStateMinClauseStore::Clause clause;
#if 0
    if (nogood_learning_multi) {
        vector<bool> projected;
        for (int var = g_variable_domain.size() - 1; var >= 0; var--) {
            project_var(var, state[var], projected);
            for (int val = 0; val < projected.size(); val++) {
                if (projected[val]) {
                    nogood.push_back(make_pair(var, val));
                }
            }
        }
        projected.clear();
        added = _nogoods->store(nogood);
    }
#endif
    bool _term = h->set_early_termination(false);
    for (int var = g_variable_domain.size() - 1; var >= 0; var--) {
        if (!project_var(h, var, state[var])) {
            clause.push_back(std::make_pair(var, state[var]));
        }
    }
    h->set_early_termination(_term);

//#ifndef NDEBUG
//    std::vector<unsigned> exploration;
//    std::vector<int> subset;
//    subset.resize(h->num_conjunctions(), 0);
//    for (uint i = 0; i < h->num_conjunctions(); i++) {
//        h->get_conjunction(i).clear();
//    }
//    std::vector<int> abstr_state;
//    abstr_state.resize(g_variable_domain.size(), -1);
//    for (const std::pair<int, int> &fact : clause) {
//        abstr_state[fact.first] = fact.second;
//    }
//    for (uint var = 0; var < g_variable_domain.size(); var++) {
//        if (abstr_state[var] != -1) {
//            const std::vector<unsigned> &conjs = h->get_fact_conj_relation(
//                    h->get_fact_id(var, abstr_state[var]));
//            for (const unsigned &conj : conjs) {
//                Conjunction &c = h->get_conjunction(conj);
//                if (++subset[conj] == c.fluent_size) {
//                    c.check_and_update(0, NULL);
//                    exploration.push_back(conj);
//                }
//            }
//            continue;
//        }
//        for (int val = 0; val < g_variable_domain[var]; val++) {
//            const std::vector<unsigned> &conjs = h->get_fact_conj_relation(
//                    h->get_fact_id(var, val));
//            for (const unsigned &conj : conjs) {
//                Conjunction &c = h->get_conjunction(conj);
//                if (++subset[conj] == c.fluent_size) {
//                    c.check_and_update(0, NULL);
//                    exploration.push_back(conj);
//                }
//            }
//        }
//    }
//    for (uint i = 0; i < h->num_counters(); i++) {
//        ActionEffectCounter &counter = h->get_counter(i);
//        counter.unsatisfied_preconditions = counter.preconditions;
//        if (counter.unsatisfied_preconditions == 0) {
//            Conjunction &conj = *counter.effect;
//            if (conj.check_and_update(0, NULL)) {
//                exploration.push_back(conj.id);
//            }
//        }
//    }
//
//    assert(h->simple_traversal_wrapper(exploration, 0) == Heuristic::DEAD_END);
//#endif

    store.store(clause);

    _state_conjs.clear();
}

static UCClauseLearning *_parse_statemin(OptionParser &parser) {
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new GreedyMinVarUCClauseLearning(opts);
    }
    return NULL;
}

static UCClauseLearning *_parse_none(OptionParser &parser) {
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new NoClauseLearning(opts);
    }
    return NULL;
}

static Plugin<UCClauseLearning> _var("statemin", _parse_statemin);
static Plugin<UCClauseLearning> _none("none", _parse_none);
































CPGClauseStore::CPGClauseStore() : m_num_clauses(0) {}

std::vector<unsigned> &CPGClauseStore::get_clauses(unsigned conj_id)
{
    if (conj_id >= m_clauses.size()) {
        m_clauses.resize(conj_id + 1);
    }
    return m_clauses[conj_id];
}

void CPGClauseStore::add(unsigned conj_id, unsigned clause_id)
{
    get_clauses(conj_id).push_back(clause_id);
}

unsigned CPGClauseStore::find(HCHeuristic *h, const GlobalState &_state)
{
    if (m_num_clauses == 0) {
        return NO_MATCH;
    }
    __subset.resize(h->num_conjunctions());
    for (uint i = 0; i < __subset.size(); i++) {
        __subset[i] = 0;
    }
    __matched.resize(m_num_clauses);
    for (uint i = 0; i < __matched.size(); i++) {
        __matched[i] = false;
    }
    unsigned left = m_num_clauses;
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        const std::vector<unsigned> &conjs = h->get_fact_conj_relation(h->get_fact_id(var, _state[var]));
        for (const unsigned & conj : conjs) {
            if (++__subset[conj] == h->get_conjunction(conj).fluent_size) {
                const std::vector<unsigned> &clauses = get_clauses(conj);
                for (const unsigned & clause : clauses) {
                    if (!__matched[clause]) {
                        __matched[clause] = true;
                        left--;
                    }
                }
            }
        }
    }
    return left > 0 ? 1 : NO_MATCH;
}

size_t CPGClauseStore::size() const
{
    return m_num_clauses;
}


CPGClauseLearning::CPGClauseLearning(const Options &opts)
    : UCClauseLearning(opts)
{
}

void CPGClauseLearning::refine(HCHeuristic *h, const GlobalState &)
{
    marked.resize(h->num_conjunctions());
    for (uint i = 0; i < marked.size(); i++) {
        marked[i] = false;
    }
    //h->evaluate(state);
    collect(h, h->get_goal_counter_id(), store.size());
    store.new_clause();
}

void CPGClauseLearning::collect(HCHeuristic *h, unsigned counter_id, unsigned clause_id)
{
    assert(counter_id < h->num_counters());
    unsigned conj = -1;
    const std::vector<unsigned> &pre = h->get_counter_precondition(counter_id);
    for (uint i = 0; i < pre.size(); i++) {
        if (!h->get_conjunction(pre[i]).is_achieved()) {
            conj = pre[i];
            break;
        }
    }
    assert(conj < h->num_conjunctions());
    if (marked[conj]) {
        return;
    }
    marked[conj] = true;
    store.add(conj, clause_id);
    const std::vector<unsigned> &succs = h->get_conjunction_achievers(conj);
    for (const unsigned & succ : succs) {
        collect(h, succ, clause_id);
    }
}

ClauseStore *CPGClauseLearning::get_store()
{
    return &store;
}


static UCClauseLearning *_parse_cpg(OptionParser &parser) {
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new CPGClauseLearning(opts);
    }
    return NULL;
}

static Plugin<UCClauseLearning> _cpg("cpg", _parse_cpg);













/*
void HCHeuristic::project_var(int var, int orig_val, std::vector<bool> &projected)
{
    //cout << "Projecting away " << g_fact_names[var][orig_val] << endl;

    projected.clear();
    projected.resize(g_variable_domain[var], false);
    projected[orig_val] = true;
    size_t num_projected = 1;

    vector<int> exploration;
    for (int val = g_variable_domain[var] - 1; val >= 0; val--) {
        if (val == orig_val) {
            continue;
        }

        // add the fact <var = val> to the initial state
        // -> also add conjunctions that are now part of the initial state
        int fid = get_fact_id(var, val);
        const vector<int> &conjs = get_fact_conj_relation(fid);
        for (int cid : conjs) {
            _nogood_state_conjs[cid]++;
            Conjunction &conj = get_conjunction(cid);
            // check whether all facts of the conjunctions are now contained
            // in the current state
            // however, if we have already achieved the conjunction in the
            // previous iteration of the hmax computation, then there is
            // nothing left to do
            if (!conj.is_achieved()
                && _nogood_state_conjs[cid] == conj.fluent_size) {
                conj.check_and_update(0, NULL);
                exploration.push_back(cid);
            }
        }

        // check whether state is still a dead end
        if (simple_traversal_wrapper_reachability(exploration) != DEAD_END) {
            //cout << "Cannot add " << g_fact_names[var][val] << endl;
            // Have to revert all changes made during relaxed traversal
            // - all conjunctions that are contained in the exploration queue
            //  were unreachable before
            for (int cid : exploration) {
                Conjunction &conj = get_conjunction(cid);
                conj.clear();
                const vector<ActionEffectCounter*> &triggered = conj.triggered_counters;
                for (size_t i = 0; i < triggered.size(); i++) {
                    triggered[i]->unsatisfied_preconditions++;
                }
            }
            // Remove the facts from the current state that were added before
            for (int cid : conjs) {
                _nogood_state_conjs[cid]--;
            }
        } else {
            //cout << "Added " << g_fact_names[var][val] << endl;
            projected[val] = true;
            num_projected++;
        }
        exploration.clear();
    }

    if (num_projected == projected.size()) {
        projected.clear();
    }
}*/

/*bool HCHeuristic::learn_nogoods(const vector<GlobalState> &states)
{
    if (!_nogoods) {
        return false;
    }

    vector<int> exploration;
    simple_traversal_setup(states, exploration);
    simple_traversal_wrapper_reachability(exploration, 0);

    bool res = false;
    for (size_t i = 0; i < states.size(); i++) {
        NoGoodID added = NoGoods::NONOGOOD;

        const GlobalState &state = states[i];

        if (check_state_nogoods(state)) {
            continue;
        }

        _nogood_state_conjs.resize(num_conjunctions(), 0);
        for (int var = 0; var < g_variable_domain.size(); var++) {
            const vector<int> &conjs = get_fact_conj_relation(
                                           get_fact_id(var, state[var]));
            for (int cid : conjs) {
                _nogood_state_conjs[cid]++;
            }
        }

        // try to project away each variable
        // if not possible, add it to the nogood
        vector<pair<int, int> > nogood;
        if (nogood_learning_multi) {
            vector<bool> projected;
            for (int var = g_variable_domain.size() - 1; var >= 0; var--) {
                project_var(var, state[var], projected);
                for (int val = 0; val < projected.size(); val++) {
                    if (projected[val]) {
                        nogood.push_back(make_pair(var, val));
                    }
                }
            }
            projected.clear();
            added = _nogoods->store(nogood);
            res = res || (added != NoGoods::NONOGOOD);
        } else {
            for (int var = g_variable_domain.size() - 1; var >= 0; var--) {
                if (!project_var(var, state[var])) {
                    nogood.push_back(make_pair(var, state[var]));
                }
            }
            // if the nogood is just the state, we do not have to store it
            added = _nogoods->store(nogood);
            res = res || (added != NoGoods::NONOGOOD);
        }

        _nogood_state_conjs.clear();
        nogood.clear();

        if (added != NoGoods::NONOGOOD && _enable_caching) {
            _cached_conflicts.push_back(CachedData(num_conjunctions()));
            vector<int> &cache = _cached_conflicts[_cached_conflicts.size() - 1].unreach;
            for (int i = 0; i < num_conjunctions(); i++) {
                if (!get_conjunction(i).is_achieved()) {
                    cache.push_back(i);
                }
            }
            _last_used = &cache;
        }
    }

    return res;
}*/
