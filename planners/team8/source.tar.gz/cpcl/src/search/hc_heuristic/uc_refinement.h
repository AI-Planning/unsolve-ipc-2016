
#ifndef UC_REFINEMENT_H
#define UC_REFINEMENT_H

#include "hc_heuristic.h"

#include "../global_state.h"
#include "../state_id.h"

#include <vector>
#include <unordered_set>

class Options;
class GlobalState;

struct RNInitializer {
    virtual void operator()(HCHeuristic *h, StateID state) = 0;
};

class UCRefinement {
public:
    UCRefinement(const Options &) {}
    virtual void set_rn_initializer(RNInitializer *) {};
    virtual bool requires_rn() const = 0;
    virtual bool requires_scc() const = 0;
    virtual bool refine(HCHeuristic *h, const std::vector<GlobalState> &state,
            const std::unordered_set<StateID> &rn) = 0;
};

class RNUCRefinement : public UCRefinement {
protected:
    RNInitializer *rn_initializer;

    /* Options */
    bool c_use_root_state_conflicts;

    /* Input data */
    const std::vector<GlobalState> *_comp;
    HCHeuristic *h;
    size_t state_component_size;
    std::vector<std::vector<unsigned> > current_states;
    std::vector<std::vector<int> > root_conflicts;
    size_t recognized_neighborhood_size;
    std::vector<std::vector<int> > successor_conflicts;

    /* Output data */
    std::vector<Conflict> _conflicts;
    std::vector<std::vector<std::vector<unsigned> > > facts_to_conflicts;

    void compute_conflict_set(Fluent &subgoal);
    bool conflict_exists(const Fluent &x) const;
    virtual void select_conflict(const Fluent &subgoal, Conflict &conflict) = 0;
    void break_subset(const Fluent &subgoal, Conflict &conflict) const;

    bool prepare_refinement(HCHeuristic *h, const std::vector<GlobalState> &states, const std::unordered_set<StateID> &rn);
public:
    RNUCRefinement(const Options &opts);
    virtual void set_rn_initializer(RNInitializer *initializer);
    virtual bool requires_rn() const {
        return true;
    }
    virtual bool requires_scc() const {
        return true;
    }
    virtual bool refine(HCHeuristic *h, const std::vector<GlobalState> &states, const std::unordered_set<StateID> &rn);
};


#endif
