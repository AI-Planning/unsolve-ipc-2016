
#include "uc_heuristic.h"

#include "../globals.h"
#include "../global_state.h"
#include "../operator_cost.h"
#include "../option_parser.h"
#include "../plugin.h"
#include "../utilities.h"

#include "../state_registry.h"

#include <vector>

struct StateRNInitializer : public RNInitializer {
    virtual void operator()(HCHeuristic *h, StateID state_id) {
        GlobalState state = g_state_registry->lookup_state(state_id);
        h->evaluate(state);
        assert(h->is_dead_end());
    }
};

struct ClauseRNInitializer : public RNInitializer {
private:
    const GreedyStateMinClauseStore &store;
public:
    ClauseRNInitializer(const GreedyStateMinClauseStore &store) : store(store) {}
    virtual void operator()(HCHeuristic *h, StateID clause_id) {
        const GreedyStateMinClauseStore::Clause &clause = store[clause_id.hash()];
        std::vector<unsigned> exploration;
        std::vector<int> subset;
        subset.resize(h->num_conjunctions(), 0);
        for (uint i = 0; i < h->num_conjunctions(); i++) {
            h->get_conjunction(i).clear();
        }
        std::vector<int> abstr_state;
        abstr_state.resize(g_variable_domain.size(), -1);
        for (const std::pair<int, int> &fact : clause) {
            abstr_state[fact.first] = fact.second;
        }
        for (uint var = 0; var < g_variable_domain.size(); var++) {
            if (abstr_state[var] != -1) {
                const std::vector<unsigned> &conjs = h->get_fact_conj_relation(
                        h->get_fact_id(var, abstr_state[var]));
                for (const unsigned & conj : conjs) {
                    Conjunction &c = h->get_conjunction(conj);
                    if (++subset[conj] == c.fluent_size) {
                        c.check_and_update(0, NULL);
                        exploration.push_back(conj);
                    }
                }
                continue;
            }
            for (int val = 0; val < g_variable_domain[var]; val++) {
                const std::vector<unsigned> &conjs = h->get_fact_conj_relation(
                        h->get_fact_id(var, val));
                for (const unsigned & conj : conjs) {
                    Conjunction &c = h->get_conjunction(conj);
                    if (++subset[conj] == c.fluent_size) {
                        c.check_and_update(0, NULL);
                        exploration.push_back(conj);
                    }
                }
            }
        }
        for (uint i = 0; i < h->num_counters(); i++) {
            ActionEffectCounter &counter = h->get_counter(i);
            counter.unsatisfied_preconditions = counter.preconditions;
            if (counter.unsatisfied_preconditions == 0) {
                Conjunction &conj = *counter.effect;
                if (conj.check_and_update(0, NULL)) {
                    exploration.push_back(conj.id);
                }
            }
        }

#ifndef NDEBUG
        assert(h->simple_traversal_wrapper(exploration, 0) == Heuristic::DEAD_END);
#else
        h->simple_traversal_wrapper(exploration, 0);
#endif
    }
};

UCHeuristic::UCHeuristic(const Options &opts)
    : HCHeuristic(opts), UnsatisfiabilityHeuristic(opts),
      clause_store(NULL),
      refinement(opts.get<UCRefinement *>("refinement")),
      clause_learning(NULL),
      c_rnc(opts.get<bool>("rnc")),
      c_eval_hc(opts.get<bool>("hc"))
{
    if (opts.contains("clauses")) {
        clause_learning = opts.get<UCClauseLearning *>("clauses");
    }
    cost_type = OperatorCost::ONE;
    max_ratio_repr_counters = opts.get<float>("x");
    if (clause_learning != NULL) {
        clause_store = clause_learning->get_store();
    }
    if (c_rnc) {
        if (!clause_learning) {
            exit_with(EXIT_CRITICAL_ERROR);
        }
        refinement->set_rn_initializer(new ClauseRNInitializer(
                    *dynamic_cast<GreedyStateMinClauseStore*>(clause_store)));
    } else {
        refinement->set_rn_initializer(new StateRNInitializer());
    }
}

bool UCHeuristic::evaluate_dead_end(const GlobalState &state)
{
    //if (heuristic == NOT_INITIALIZED) {
    //    initialize();
    //    heuristic = -1;
    //}
    statistics.increase_dead_end_evaluations();
    statistics.increase_fast_dead_end_evaluations();
    if (fast_dead_end_check(state)) {
        return true;
    }
    statistics.increase_slow_dead_end_evaluations();
    return slow_dead_end_check(state);
}

bool UCHeuristic::slow_dead_end_check(const GlobalState &state)
{
    if (c_eval_hc) {
        statistics.increase_real_slow_dead_end_evaluations();
        statistics.start();
        evaluate(state);
        statistics.end_hc_evaluation();
        if (is_dead_end()) {
            statistics.increase_num_hc_dead_ends();
            if (clause_learning) {
                statistics.increase_learnings();
                statistics.start();
                clause_learning->refine(this, state);
                statistics.end_clause_learning();
            }
            return true;
        }
    }
    return false;
}

bool UCHeuristic::fast_dead_end_check(const GlobalState &state)
{
    statistics.increase_real_fast_dead_end_evaluations();
    statistics.start();
    bool res = clause_learning && clause_store->find(this, state) != ClauseStore::NO_MATCH;
    statistics.end_clause_evaluation();
#ifndef NDEBUG
    if (res && false) {
        evaluate(state);
        assert(is_dead_end());
    }
#endif
    return res;
}

bool UCHeuristic::refine(const std::vector<GlobalState> &root,
                         const std::unordered_set<StateID> &rn)
{
    assert(root.size() > 0);
#ifndef NDEBUG
    evaluate(root[0]);
    bool dead_end = is_dead_end();
    for (uint i = 1; i < root.size(); i++) {
        evaluate(root[i]);
        assert(!dead_end || is_dead_end());
    }
#endif
    // TODO: try out
    // (1) iterate over all states in root, and check clauses
    // (2) only check clause for first state in root
    for (const GlobalState & state : root) {
        if (fast_dead_end_check(state)) {
            learn(root);
            return true;
        }
    }
    // TODO might have to learn some clauses ...

    const std::unordered_set<StateID> *rnp = NULL;
    std::unordered_set<StateID> clauses;
    if (c_rnc) {
        for (const StateID & id : rn) {
            GlobalState state = g_state_registry->lookup_state(id);
            // TODO: cache this information? (PerStateInformation field)
            unsigned c = clause_store->find(this, state);
            assert(c != ClauseStore::NO_MATCH);
            clauses.insert(StateID(c));
        }
        rnp = &clauses;
    } else {
        rnp = &rn;
    }
    //std::unordered_set<unsigned> clauses;
    //std::cout << clauses.size() << " vs " << rn.size() << std::endl;

    statistics.increase_refinements();
    statistics.increase_component_sizes(root.size());
    statistics.increase_rn_sizes(rn.size());
    statistics.increase_real_rn_sizes(rnp->size());
    statistics.start();
    bool res = this->refinement->refine(this, root, *rnp);
#ifndef NDEBUG
    if (res) {
        for (uint i = 0; i < root.size(); i++) {
            evaluate(root[i]);
            assert(is_dead_end());
        }
    }
#endif
    statistics.end_refinement();
    if (res) {
        learn(root);
    }

    return res;
}

void UCHeuristic::learn(const std::vector<GlobalState> &dead_ends)
{
    // TODO: try out
    // (1) just iterate over all states in root, and learn clauses seperately
    // (2) only learn clause for first state in root
    // (3) learn clauses for all states at once
    for (const GlobalState & s : dead_ends) {
        learn(s);
    }
}

void UCHeuristic::learn(const GlobalState &state)
{
    if (!clause_learning || fast_dead_end_check(state)) {
        return;
    }
    statistics.increase_learnings();
    statistics.start();
    evaluate(state);
    assert(is_dead_end());
    clause_learning->refine(this, state);
    statistics.end_clause_learning();
}

bool UCHeuristic::is_refinement_enabled() const
{
    return exceeded_size_limit();
}

bool UCHeuristic::refinement_requires_rn() const
{
    return refinement->requires_rn();
}

bool UCHeuristic::refinement_requires_scc() const
{
    return refinement->requires_scc();
}

void UCHeuristic::print_statistics() const
{
    dump_compilation_information();
    printf("Number of Learned Clauses: %zu\n", !clause_learning ? 0 : clause_store->size());
    statistics.print_statistics();
}

void UCHeuristic::print_statistics_short() const
{
    dump_compilation_information();
    printf("Number of Learned Clauses: %zu\n", !clause_learning ? 0 : clause_store->size());
}

void UCHeuristic::add_options_to_parser(OptionParser &parser)
{
    HCHeuristic::add_options_to_parser(parser);
    parser.add_option<float>("x", "", "1.0");
    parser.add_option<UCRefinement *>("refinement", "", "bw");
    parser.add_option<UCClauseLearning *>("clauses", "", "", OptionFlags(false));
    parser.add_option<bool>("rnc", "", "false");
    parser.add_option<bool>("hc", "", "true");
}

static UnsatisfiabilityHeuristic *_parse(OptionParser &parser)
{
    UCHeuristic::add_options_to_parser(parser);
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new UCHeuristic(opts);
    }
    return NULL;
}

static Plugin<UnsatisfiabilityHeuristic> _plugin_uc("uc", _parse);


