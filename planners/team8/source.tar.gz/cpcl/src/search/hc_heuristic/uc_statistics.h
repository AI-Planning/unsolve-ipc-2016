
#ifndef UC_STATISTICS_H
#define UC_STATISTICS_H

#include <stdio.h>
#include <ctime>

class UCHeuristicStatistics
{
    size_t num_dead_end_evaluations;
    size_t num_real_fast_dead_end_evaluations;
    size_t num_real_slow_dead_end_evaluations;
    size_t num_fast_dead_end_evaluations;
    size_t num_slow_dead_end_evaluations;
    size_t num_refines;
    size_t num_learns;

    size_t summed_component_size;
    size_t summed_rn_size;
    size_t summed_real_rn_size;

    size_t num_hc_dead_ends;

    double t_refinement;
    double t_clause_learning;
    double t_hc_evaluation;
    double t_clause_evaluation;

    clock_t _timestamp;
public:
    UCHeuristicStatistics() :
        num_dead_end_evaluations(0),
        num_real_fast_dead_end_evaluations(0),
        num_real_slow_dead_end_evaluations(0),
        num_fast_dead_end_evaluations(0),
        num_slow_dead_end_evaluations(0),
        num_refines(0),
        num_learns(0),
        summed_component_size(0),
        summed_rn_size(0),
        summed_real_rn_size(0),
        num_hc_dead_ends(0),
        t_refinement(0),
        t_clause_learning(0),
        t_hc_evaluation(0),
        t_clause_evaluation(0) {
    }

    void increase_dead_end_evaluations() {
        num_dead_end_evaluations++;
    }
    void increase_fast_dead_end_evaluations() {
        num_fast_dead_end_evaluations++;
    }
    void increase_slow_dead_end_evaluations() {
        num_slow_dead_end_evaluations++;
    }
    void increase_real_fast_dead_end_evaluations() {
        num_real_fast_dead_end_evaluations++;
    }
    void increase_real_slow_dead_end_evaluations() {
        num_real_slow_dead_end_evaluations++;
    }
    void increase_refinements() {
        num_refines++;
    }
    void increase_learnings() {
        num_learns++;
    }
    void increase_component_sizes(size_t size) {
        summed_component_size += size;
    }
    void increase_rn_sizes(size_t size) {
        summed_rn_size += size;
    }
    void increase_real_rn_sizes(size_t size) {
        summed_real_rn_size += size;
    }
    void increase_num_hc_dead_ends() {
        num_hc_dead_ends += 1;
    }
    void start() {
        _timestamp = clock();
    }
    void end_refinement() {
        clock_t end = clock();
        t_refinement += ((double) (end - _timestamp) / CLOCKS_PER_SEC);
    }
    void end_clause_learning() {
        clock_t end = clock();
        t_clause_learning += ((double) (end - _timestamp) / CLOCKS_PER_SEC);
    }
    void end_hc_evaluation() {
        clock_t end = clock();
        t_hc_evaluation += ((double) (end - _timestamp) / CLOCKS_PER_SEC);
    }
    void end_clause_evaluation() {
        clock_t end = clock();
        t_clause_evaluation += ((double) (end - _timestamp) / CLOCKS_PER_SEC);
    }
    void print_statistics() const {
        double avg_component = 0;
        double avg_rn = 0;
        double avg_rrn = 0;
        if (num_refines > 0) {
            avg_component = summed_component_size / (double) num_refines;
            avg_rn = summed_rn_size / (double) num_refines;
            avg_rrn = summed_real_rn_size / (double) num_refines;
        }
        printf("Number of u-Refinements: %zu\n", num_refines);
        printf("Number of u-Learnings: %zu\n", num_learns);
        printf("Average Component Size: %.6f\n", avg_component);
        printf("Average Recognized Neighborhood Size: %.6f\n", avg_rn);
        printf("Average Real Recognized Neighborhood Size: %.6f\n", avg_rrn);
        printf("Number of u-Evaluations: %zu\n", num_dead_end_evaluations);
        printf("Number of fast u-Evaluations: %zu\n", num_fast_dead_end_evaluations);
        printf("Number of slow u-Evaluations: %zu\n", num_slow_dead_end_evaluations);
        printf("Number of real fast u-Evaluations: %zu\n", num_real_fast_dead_end_evaluations);
        printf("Number of real slow u-Evaluations: %zu\n", num_real_slow_dead_end_evaluations);
        printf("Number of u-recognized Dead Ends: %zu\n", num_hc_dead_ends);
        printf("Total time spent on u-Refinement: %.6fs\n", t_refinement);
        printf("Total time spent on u-Learnings: %.6fs\n", t_clause_learning);
        printf("Total time spent on u-Evaluations (slow): %.6fs\n", t_hc_evaluation);
        printf("Total time spent on u-Evaluations (fast): %.6fs\n", t_clause_evaluation);
    }
};

#endif
