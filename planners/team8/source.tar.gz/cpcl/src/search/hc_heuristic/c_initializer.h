
#ifndef C_INITIALIZER_H
#define C_INITIALIZER_H

#include "hc_heuristic.h"

#include <vector>
#include <list>
#include <set>

class CInitializer {
public:
    CInitializer(const Options &) {}
    virtual void initialize(HCHeuristic *h) = 0;
};

class ConnectectedVarPairCInitializer : public CInitializer {
public:
    ConnectectedVarPairCInitializer(const Options &opts);
    virtual void initialize(HCHeuristic *h);
};

class SCCCInitializer : public ConnectectedVarPairCInitializer {
protected:
    struct dat {
        int index;
        int lowlink;
        int largelink;
        bool onstack;
        unsigned scc;
        dat() : index(-1) {}
        void update(int x) {
            lowlink = lowlink < x ? lowlink : x;
        }
    };
    std::vector<std::vector<unsigned> > sccs;
    std::vector<std::unordered_set<unsigned> > scc_graph;
    std::set<std::pair<int, unsigned> > scc_order;
    std::list<unsigned> stack;
    std::vector<dat> data;
    int index;
    void dfs(unsigned var);
    void release_memory1();
    void release_memory2();

    const unsigned c_m;
    void enumerate_and_add(HCHeuristic *h, const std::vector<unsigned> &vars, const Conflict &conj, unsigned i, int m);
    //void enumerate_and_add(HCHeuristic *h, const std::vector<unsigned> &vars, int m);
public:
    SCCCInitializer(const Options &opts);
    virtual void initialize(HCHeuristic *h);
};

#endif
