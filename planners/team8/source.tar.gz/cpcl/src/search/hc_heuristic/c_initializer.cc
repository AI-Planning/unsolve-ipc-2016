
#include "c_initializer.h"

#include "../option_parser.h"
#include "../plugin.h"
#include "../globals.h"
#include "../causal_graph.h"
//#include "../"

ConnectectedVarPairCInitializer::ConnectectedVarPairCInitializer(const Options &opts)
    : CInitializer(opts) {}

#if 0
void ConnectectedVarPairCInitializer::initialize(HCHeuristic *h) {
    std::vector<unsigned> max_out;
    unsigned max = 0;
    for (unsigned var = 0; var < g_variable_domain.size(); var++) {
        if (g_causal_graph->get_successors(var).size() > max) {
            max = g_causal_graph->get_successors(var).size();
            max_out.clear();
            max_out.push_back(var);
        }
    }
    if (max == 0) {
        std::cout << "Causual graph completely unconnected?" << std::endl;
        return;
    }
    if (max_out.size() == g_variable_domain.size()) {
        std::cout << "max_out contains all variables" << std::endl;
        return;
    }
    std::cout << "Continuing with " << max_out.size() << " / " << g_variable_domain.size() << " variables" << std::endl;
    for (uint i = 0; i < max_out.size(); i++) {
        unsigned var0 = max_out[i];
        for (int val0 = 0; val0 < g_variable_domain[var0]; val0++) {
            const std::vector<int> &pred = g_causal_graph->get_predecessors(var0);
            for (uint j = 0; j < pred.size(); j++) {
                unsigned var1 = pred[j];
                for (int val1 = 0; val1 < g_variable_domain[var1]; val1++) {
                    Conflict conj;
                    conj.merge(h->get_fact(var0, val0));
                    conj.merge(h->get_fact(var1, val1));
                    h->add_conflict(conj);
                }
            }
        }
    }
}
#else
void ConnectectedVarPairCInitializer::initialize(HCHeuristic *) {
}
#endif


SCCCInitializer::SCCCInitializer(const Options &opts)
    : ConnectectedVarPairCInitializer(opts),
    c_m(opts.get<int>("m"))
{
}

void SCCCInitializer::dfs(unsigned var)
{
    data[var].onstack = true;
    data[var].index = index;
    data[var].lowlink = index;
    data[var].largelink = 0;
    stack.push_front(var);
    index++;

    const std::vector<int> &succs = g_causal_graph->get_successors(var);
    for (uint i = 0; i < succs.size(); i++) {
        if (data[succs[i]].index == -1) {
            dfs(succs[i]);
            data[var].update(data[succs[i]].lowlink);
        } else if (data[succs[i]].onstack) {
            data[var].update(data[succs[i]].index);
        }

        if (data[succs[i]].largelink >= data[var].largelink) {
            data[var].largelink = data[succs[i]].largelink + 1;
        }
    }

    if (data[var].index == data[var].lowlink) {
        unsigned scc_id = sccs.size();
        sccs.resize(sccs.size() + 1);
        scc_graph.push_back(std::unordered_set<unsigned>());
        std::vector<unsigned> &scc = sccs.back();
        std::list<unsigned>::iterator it = stack.begin();
        while (true) {
            scc.push_back(*it);
            data[*it].onstack = false;
            data[*it].scc = scc_id;
            const std::vector<int> &tmp = g_causal_graph->get_successors(*it);
            for (uint i = 0; i < tmp.size(); i++) {
                scc_graph[scc_id].insert(data[tmp[i]].scc);
            }
            if (*(it++) == var) {
                break;
            }
        }
        stack.erase(stack.begin(), it);
        scc_order.insert(std::make_pair(data[var].largelink, scc_id));
    }
}

void SCCCInitializer::release_memory1()
{
    scc_graph.clear();
    scc_order.clear();
    stack.clear();
    data.clear();
}

void SCCCInitializer::release_memory2()
{
    sccs.clear();
}

void SCCCInitializer::enumerate_and_add(HCHeuristic *h,
                                        const std::vector<unsigned> &vars,
                                        const Conflict &conj,
                                        unsigned i,
                                        int m)
{
    if (i == vars.size() || m == 0) {
        return;
    }

    for (unsigned j = i; j < vars.size(); j++) {
        unsigned var = vars[j];
        for (int val = 0; val < g_variable_domain[var]; val++) {
            Conflict conj2(conj);
            conj2.merge(h->get_fact(var, val));
            if (conj2.get_fluent().size() > 1) {
                //std::cout << "adding conjunction: ";
                //h->dump_fluent_pddl(conj2.get_fluent());
                //std::cout << std::endl;
                h->add_conflict(conj2);
            }
            enumerate_and_add(h, vars, conj2, j + 1, m - 1);
        }
    }
}

void SCCCInitializer::initialize(HCHeuristic *h)
{
    std::cout << "Initializing C based on causual graph SCCs" << std::endl;

    data.resize(g_variable_domain.size());
    index = 0;
    dfs(0);

    if (sccs.size() == 1) {
        release_memory1();
        release_memory2();
        std::cout << "causual graph is one big SCC" << std::endl;
        std::cout << "switching to greedy variable selection strategy" << std::endl;
        ConnectectedVarPairCInitializer::initialize(h);
        return;
    }

    std::vector<unsigned> roots;
    std::set<std::pair<int, unsigned> >::reverse_iterator rit = scc_order.rbegin();
    int root_largelink = rit->first;
    while (rit != scc_order.rend() && rit->first == root_largelink) {
        roots.push_back(rit->second);
        rit++;
    }

    release_memory1();

    std::cout << "Continuing with " << roots.size() << " root SCCs" << std::endl;

    for (uint i = 0; i < roots.size(); i++) {
        if (sccs[roots[i]].size() == 1) {
            continue;
        }
        std::cout << "Constructing conjunction of root#" << i << " with size = " << sccs[roots[i]].size() << std::endl;
        enumerate_and_add(h, sccs[roots[i]], Conflict(), 0, sccs[roots[i]].size() > c_m ? c_m : sccs[roots[i]].size());
    }

    release_memory2();

    std::cout << "Done Initializing C" << std::endl;
}

static CInitializer *_parse(OptionParser &parser) {
    parser.add_option<int>("m", "", "2");
    Options opts = parser.parse();
    if (!parser.dry_run()) {
        return new SCCCInitializer(opts);
    }
    return NULL;
}

static Plugin<CInitializer> _plugin("scc", _parse);

