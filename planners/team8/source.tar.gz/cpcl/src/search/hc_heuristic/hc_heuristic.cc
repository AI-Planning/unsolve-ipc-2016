#include "hc_heuristic.h"

#include "../globals.h"
#include "../global_operator.h"
#include "../global_state.h"
#include "../option_parser.h"
#include "../plugin.h"

#include "conjunction_operations.h"
#include "c_initializer.h"

#include <cassert>
#include <vector>
#include <algorithm>
#include <fstream>

#include <map>

#define DUMP_CONJUNCTIONS_ 0

using namespace std;
using namespace fluent_op;

#define TIME_ANALYSIS 0

#if TIME_ANALYSIS
static clock_t G_t1 = 0;
static clock_t G_start = 0;
static void G_start_timer()
{
    G_start = clock();
}
static clock_t G_get_duration()
{
    return clock() - G_start;
}
#endif


void My_hash_combine(std::size_t &h, const std::size_t &v)
{
    // from boost
    h ^= v + 0x9e3779b9 + (h << 6) + (h >> 2);
}


void Conflict::merge(const Fact &fact)
{
    Fluent fluent;
    fluent.insert(fact);
    merge(fluent);
}

void Conflict::merge(const Conflict &conj)
{
    merge(conj.fluent);
}

void Conflict::merge(const Fluent &fluent)
{
    /* merge the current conjunction stored insided with the given conjunction */
    // update the fluent set by inserting all elements contained in conj
    this->fluent.insert(fluent.begin(), fluent.end());
}

// construction and destruction
HCHeuristic::HCHeuristic(const Options &opts)
    : Heuristic(opts), _comp(this), _unique_conjunctions(_comp)
{
    max_number_fluents = -1;
    //if (opts.contains("c")) {
    //    max_number_fluents = (unsigned) opts.get<int>("c");
    //}
    max_ratio_repr_counters = -1;
    //if (opts.contains("x")) {
    //    max_ratio_repr_counters = opts.get<float>("x");
    //    if (max_ratio_repr_counters >= 0 && max_ratio_repr_counters < 1) {
    //        max_ratio_repr_counters = 1;
    //    }
    //}
    current_fluents = 0;
    max_num_counters = -1;

    hard_size_limit = true;
    if (opts.contains("hard_size_limit")) {
        hard_size_limit = opts.get<bool>("hard_size_limit");
    }

    _m = opts.get<int>("m");

    __load_from_file = opts.get<string>("file");

    prune_counter_precondition = opts.get<bool>("prune_pre");

    early_termination = opts.get<bool>("early_term");

    _c_init = NULL;
    if (opts.contains("cinit")) {
        _c_init = opts.get<CInitializer*>("cinit");
    }
}

int HCHeuristic::get_number_of_conjunctions() const
{
    return current_fluents;
}

int HCHeuristic::get_number_of_counters() const
{
    return counters.size();
}

double HCHeuristic::get_counter_ratio() const
{
    return (double) counters.size() / _num_counters;
}

bool HCHeuristic::dump_fact_pddl(int var, int val,
        std::ostream &out, bool sep, bool negated) const
{
    const string &descr = g_fact_names[var][val];
    int i = descr.find(" ");
    if (i != 4) {
        if (!negated) {
            return false;
        }
        if (sep) {
            out << ", ";
        }
        out << "!";
    } else if (sep) {
        out << ", ";
    }
    out << g_fact_names[var][val].substr(i + 1); // cut atom
    return true;
}

void HCHeuristic::dump_state_pddl(const GlobalState &state,
        std::ostream &out) const
{
    out << "[";
    bool sep = false;
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        if (dump_fact_pddl(var, state[var], out, sep)) {
            sep = true;
        }
    }
    out << "]";
}

void HCHeuristic::dump_fluent_pddl(const Fluent &pi,
        std::ostream &out) const
{
    out << "[";
    bool sep = false;
    for (Fluent::iterator it = pi.begin(); it != pi.end(); it++) {
        if (dump_fact_pddl(it->first, it->second, out, sep)) {
            sep = true;
        }
    }
    out << "]";
}

void HCHeuristic::dump_conjunctions_pddl(int from, int to,
        bool breakes, bool with_cost, bool with_id, std::ostream &out) const
{
    bool sep = false;
    for (int i = from; i < to; i++) {
        if (sep) {
            out << ", ";
            if (breakes) {
                out << endl;
            }
        }
        if (with_id) {
            out << i << ". ";
        }
        dump_fluent_pddl(_fluents[i], out);
        if (with_cost) {
            out << ": " << conjunctions[i].cost;
        }
        sep = true;
    }
}

void HCHeuristic::dump_facts_pddl(bool breakes, bool with_cost,
        std::ostream &out) const
{
    dump_conjunctions_pddl(0, conjunction_offset, breakes, with_cost, false,
                           out);
}

void HCHeuristic::dump_c_pddl(bool breakes, bool with_id,
        bool with_cost,
        std::ostream &out) const
{
    dump_conjunctions_pddl(conjunction_offset, conjunctions.size(), breakes,
                           with_cost, with_id, out);
    if (breakes) {
        cout << endl;
    }
}

void HCHeuristic::dump_fluent_set_pddl(const vector<unsigned>
        &fluent_ids,
        std::ostream &out, int from, int to) const
{
    int i = 0;
    vector<unsigned>::const_iterator
    it = fluent_ids.begin(),
    itEnd = fluent_ids.end();
    bool sep = false;

    while (i < from && it != itEnd) {
        i++;
        it++;
    }

    out << "{";
    while ((to < 0 || i < to) && it != itEnd) {
        if (sep) {
            out << ", ";
        }
        dump_fluent_pddl(_fluents[*it], out);
        sep = true;
        i++;
        it++;
    }
    out << "}";
}

void HCHeuristic::load_conjunctions_from_file(std::string path)
{
    ifstream infile;
    infile.open(path.c_str());
    if (!infile.good()) {
        return;
    }
    cout << "Going to load conjunctions from file \"" << path << "\"" << endl;
    while (!infile.eof()) {
        string line;
        getline(infile, line);
        Conflict confl;
        for (uint i = 0; i < g_fact_names.size(); i++) {
            for (uint j = 0; j < g_fact_names[i].size(); j++) {
                if (line.find(g_fact_names[i][j]) != string::npos) {
                    Fact repr_f = get_fact(i, j);
                    unsigned fid = get_fact_id(repr_f);
                    confl.merge(_fluents[fid]);
                }
            }
        }
        if (confl.get_fluent().size() > 1) {
            add_conflict(confl);
        }
    }
    infile.close();
    dump_compilation_information(cout);
}

void HCHeuristic::dump_conjunctions_to_file(std::string path) const
{
    ofstream outfile;
    outfile.open(path.c_str());
    dump_conjunctions_to_ostream(outfile);
    outfile.close();
}

void HCHeuristic::dump_conjunctions_to_ostream(ostream &out) const
{
    for (uint i = conjunction_offset; i < conjunctions.size(); i++) {
        bool sep = false;
        for (Fluent::iterator fact = _fluents[i].begin();
             fact != _fluents[i].end(); fact++) {
            if (sep) {
                out << " ";
            }
            out << g_fact_names[fact->first][fact->second];
            sep = true;
        }
        out << endl;
    }
}

void HCHeuristic::dump_counter(size_t counter_id,
        ostream &out) const
{
    const ActionEffectCounter &counter = counters[counter_id];
    out << "[Counter " << counter_id << "] " << endl;
    out << "Base operator: ";
    //g_operators[actions[counter.action].operator_no].dump();
    out << "Effect: ";
    dump_fluent_pddl(_fluents[counter.effect->id], out);
    out << endl;
    //if (store_counter_precondition) {
    //    out << "Precondition: ";
    //    dump_fluent_set_pddl(counter_preconditions[counter_id], out);
    //    out << endl;
    //}
    //out << "[/" << counter_id << "]" << endl;
}



void HCHeuristic::initialize()
{
    cout << "Initializing h^max(Pi^C) heuristic ..." << endl;
    ::verify_no_axioms_no_conditional_effects();
    compile_strips();
    if (_c_init) {
        _c_init->initialize(this);
        dump_compilation_information();
    }
}

Fact HCHeuristic::get_fact(int var, int val) const
{
    return make_pair(var, val);
}

unsigned HCHeuristic::get_fact_id(int var, int val) const
{
    return variable_offset[var] + val;
}

unsigned HCHeuristic::get_fact_id(const Fact &fact) const
{
    return variable_offset[fact.first] + fact.second;
}

void HCHeuristic::create_unit_conjunction(int var,
        int val,  Fluent &fluent) const
{
    fluent.insert(get_fact(var, val));
}

void HCHeuristic::add_counter_precondition(ActionEffectCounter
        *counter,
        Conjunction *conj)
{
    bool dominated = false;
    if (prune_counter_precondition) {
        if (counter_preconditions.size() <= counter->id) {
            counter_preconditions.resize(counter->id + 1);
        }
        vector<unsigned>::iterator it = counter_preconditions[counter->id].begin();
        while (it != counter_preconditions[counter->id].end()) {
            if (is_subset(_fluents[conj->id], _fluents[*it])) {
                dominated = true;
                break;
            } else if (is_subset(_fluents[*it], _fluents[conj->id])) {
                conjunctions[*it].triggered_counters.erase(std::find(
                            conjunctions[*it].triggered_counters.begin(),
                            conjunctions[*it].triggered_counters.end(),
                            counter));
                it = counter_preconditions[counter->id].erase(it);
                counter->preconditions--;
            } else {
                it++;
            }
        }
        if (!dominated) {
            counter_preconditions[counter->id].push_back(conj->id);
        }
    }
    if (!dominated) {
        conj->triggered_counters.push_back(counter);
        counter->preconditions++;
    }
}

/*
 *  Compiling Fast Downwards planning task to STRIPS encoding and
 *  building graph for hmax computation
 *
 */
void HCHeuristic::compile_strips()
{
    cout << "Constructing Pi^C for h^max computation ..." << endl;

    ::verify_no_axioms_no_conditional_effects();

    conjunction_offset = 0;
    variable_offset.resize(g_variable_domain.size());
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        variable_offset[var] = conjunction_offset;
        conjunction_offset += g_variable_domain[var];
    }

    facts_conjunctions_relation.resize(conjunction_offset);

    // Build a conjunction for every fact (pair<variable, value>)
    unsigned conj_id = 0;
    //conjunctions.reserve(conjunction_offset);
    _fluents.reserve(conjunction_offset);
    for (uint var = 0; var < g_variable_domain.size(); var++) {
        for (int value = 0; value < g_variable_domain[var]; value++) {
            Fluent fluent;
            create_unit_conjunction(var, value, fluent);
            //conjunctions.push_back(Conjunction(conj_id, fluent));
            conjunctions.push_back(Conjunction(conj_id, 1));
            conjunction_achievers.push_back(std::vector<unsigned>());
            facts_conjunctions_relation[conj_id].push_back(conj_id);
            //_unique_conjunctions.insert(conj_id);
            _fluents.push_back(fluent);
            _unique_conjunctions.insert(conj_id);
            conj_id++;
        }
    }

    m_true_id = conjunctions.size();
    conjunctions.push_back(Conjunction(m_true_id, 0));
    conjunction_achievers.push_back(std::vector<unsigned>());
    _fluents.push_back(Fluent());

    // Build strips actions
    actions.reserve(g_operators.size());
    //counters.reserve(g_operators.size() * 3);

    facts_to_add.resize(conjunction_offset);
    facts_to_del.resize(conjunction_offset);
    facts_to_counters.resize(conjunction_offset);

    int strips_action_id = 0;
    for (uint i = 0; i < g_operators.size(); i++) {
        const GlobalOperator &op = g_operators[i];
        int base_cost = get_adjusted_cost(op);
        const std::vector<GlobalCondition> &pre = op.get_preconditions();
        const std::vector<GlobalEffect> &eff = op.get_effects();

        StripsAction action;
        action.base_cost = base_cost;
        action.operator_no = i;

        Fluent &precondition = action.precondition;
        Fluent &add_effect = action.add_effect;
        Fluent &del_effect = action.del_effect;

        std::vector<int> prec;
        prec.resize(g_variable_domain.size(), -1);

        for (uint i = 0; i < pre.size(); i++) {
            precondition.insert(get_fact(pre[i].var,
                                         pre[i].val));
            prec[pre[i].var] = pre[i].val;
        }

        for (uint i = 0; i < eff.size(); i++) {
            int var = eff[i].var;
            int add = eff[i].val;

            if (prec[var] != -1) {
                Fact fact = get_fact(var, prec[var]);
                del_effect.insert(fact);
                facts_to_del[get_fact_id(fact)].push_back(strips_action_id);
            } else {
                for (int val = 0; val < g_variable_domain[var]; val++) {
                    if (val != add) {
                        Fact fact = get_fact(var, val);
                        del_effect.insert(fact);
                        facts_to_del[get_fact_id(fact)].push_back(strips_action_id);
                    }
                }
            }

            Fact fact = get_fact(var, add);
            add_effect.insert(fact);
            facts_to_add[get_fact_id(fact)].push_back(strips_action_id);

            create_counter(get_fact_id(fact), base_cost, precondition);
        }

        // if add(a) non empty -> add it to the set of actions
        // it might be empty because for example it has only conditional
        // effects
        if (add_effect.size() > 0) {
            action.aid = strips_action_id;
            actions.push_back(action);
            strips_action_id++;
        }
    }

    m_goal_counter = counters.size();
    m_goal_id = m_true_id + 1;
    conjunctions.push_back(Conjunction(m_goal_id, 0));
    conjunction_achievers.push_back(std::vector<unsigned>());
    _fluents.push_back(Fluent());

    //counter_preconditions.resize(counters.size());
    //conj_to_counters.resize(conjunctions.size());

    Fluent goal;
    for (uint i = 0; i < g_goal.size(); i++) {
        goal.insert(g_goal[i]);
    }
    create_counter(m_goal_id, 0, goal);

    _num_counters = counters.size();

    set_size_limit_ratio(max_ratio_repr_counters);

    cout << "Parsed Pi into "
         << conjunction_offset << " facts, "
         << actions.size() << " actions, and "
         << counters.size() << " counters." << endl;

    if (_m > 1) {
        cout << "Adding <= " << _m <<
             " sized conjunctions to C until limit is reached..."
             << endl;
        Fluent empty;
        add_subsets_m(empty, true, _m);
        dump_compilation_information();
    }

    load_conjunctions_from_file(__load_from_file);
}

bool HCHeuristic::fluent_in_state(const Fluent &pi,
        const GlobalState &state) const
{
    if (pi.empty()) return false;
    for (Fluent::iterator f = pi.begin(); f != pi.end(); f++) {
        if (state[f->first] != f->second) {
            return false;
        }
    }
    return true;
}

// heuristic computation
void HCHeuristic::enqueue_if_necessary(Conjunction *conj,
        ActionEffectCounter * /*counter*/, int cost)
{
    //if (conj->check_and_update(cost, counter)) {
    //    queue.push(cost, conj);
    //}
    if (conj->cost == -1 || conj->cost > cost) {
        conj->cost = cost;
        queue.push(cost, conj);
    }
}

void HCHeuristic::clear_exploration_queue()
{
    queue.clear();

    for (uint cid = 0; cid < conjunctions.size(); cid++) {
        conjunctions[cid].cost = -1;
    }

    for (uint i = 0; i < counters.size(); i++) {
        ActionEffectCounter &counter = counters[i];
        counter.unsatisfied_preconditions = counter.preconditions;
    }
}

void HCHeuristic::setup_exploration_queue_state(
    const GlobalState &state)
{
    for (uint cid = 0; cid < conjunctions.size(); cid++) {
        if (fluent_in_state(_fluents[cid], state)) {
            enqueue_if_necessary(&conjunctions[cid], NULL, 0);
        }
    }
    enqueue_if_necessary(&conjunctions[m_true_id], NULL, 0);
}

/*
 * Computation of hmax
 *
 */
void HCHeuristic::relaxed_exploration()
{
    int distance;
    Conjunction *conj = NULL;
    while (!queue.empty()) {
        pair<int, Conjunction *> top_pair = queue.pop();
        distance = top_pair.first;
        conj = top_pair.second;
        if (conj->cost < distance) {
            continue;
        }
        //if (termination_option == EXPLORE_GOAL_COST &&
        //    goal_cost_max >= 0 && current_cost > goal_cost_max) {
        //    break;
        //}
        if (early_termination && conj->id == m_goal_id) {
            //if (termination_option == EARLY_TERMINATION) {
            break;
            //} else if (termination_option == EXPLORE_GOAL_COST) {
            //    goal_cost_max = current_cost;
            //}
        }
        const vector<ActionEffectCounter *> &triggered_counters =
            conj->triggered_counters;
        for (uint i = 0; i < triggered_counters.size(); i++) {
            ActionEffectCounter *counter = triggered_counters[i];
            if (--counter->unsatisfied_preconditions == 0) {
                counter->cost = conj->cost;
                enqueue_if_necessary(counter->effect,
                                     counter, counter->base_cost + counter->cost);
            }
        }
    }
}

int HCHeuristic::priority_traversal(const GlobalState &state)
{
    clear_exploration_queue();
    setup_exploration_queue_state(state);
    relaxed_exploration();
    return conjunctions[m_goal_id].is_achieved() ? conjunctions[m_goal_id].cost : DEAD_END;
}


int HCHeuristic::simple_traversal_setup(const std::vector<std::pair<int, int> > &state,
                                    std::vector<unsigned> &exploration)
{
    for (size_t i = 0; i < num_conjunctions(); i++) {
        get_conjunction(i).clear();
    }

    vector<int> subset;
    subset.resize(num_conjunctions(), 0);
    vector<pair<int, int> >::const_iterator it = state.begin();
    for (int var = g_variable_domain.size() - 1; var >= 0; var--) {
        bool added = false;
        while (it != state.end() && it->first == var) {
            added = true;
            const vector<unsigned> &conjs = get_fact_conj_relation(get_fact_id(*it));
            for (size_t j = 0; j < conjs.size(); j++) {
                Conjunction &conj = get_conjunction(conjs[j]);
                if (++subset[conj.id] == conj.fluent_size) {
                    conj.check_and_update(0, NULL);
                    exploration.push_back(conj.id);
                }
            }
            ++it;
        }
        if (!added) {
            for (int val = 0; val < g_variable_domain[var]; val++) {
                const vector<unsigned> &conjs = get_fact_conj_relation(get_fact_id(var, val));
                for (size_t j = 0; j < conjs.size(); j++) {
                    Conjunction &conj = get_conjunction(conjs[j]);
                    if (++subset[conj.id] == conj.fluent_size) {
                        conj.check_and_update(0, NULL);
                        exploration.push_back(conj.id);
                    }
                }
            }
        }
    }
    subset.clear();
    conjunctions[m_true_id].check_and_update(0, NULL);
    exploration.push_back(m_true_id);

    for (uint i = 0; i < counters.size(); i++) {
        ActionEffectCounter &counter = counters[i];
        counter.unsatisfied_preconditions = counter.preconditions;
    }

    return exploration.size();
}

//int HCHeuristic::simple_traversal_setup(const vector<GlobalState> &states,
//        std::vector<int> &exploration)
//{
//    int lvl0 = 0;
//
//    exploration.clear();
//    exploration.reserve(conjunctions.size());
//
//    for (size_t i = 0; i < conjunctions.size(); i++) {
//        conjunctions[i].clear();
//    }
//
//    for (size_t j = 0; j < states.size(); j++) {
//        const GlobalState &state = states[j];
//        for (uint i = 0; i < conjunctions.size(); i++) {
//            Conjunction &conj = conjunctions[i];
//            if (!conj.is_achieved() && fluent_in_state(_fluents[i], state)) {
//                conj.check_and_update(0, NULL);
//                exploration.push_back(i);
//            }
//        }
//    }
//
//    lvl0 = exploration.size();
//
//    for (uint i = 0; i < counters.size(); i++) {
//        ActionEffectCounter &counter = counters[i];
//        counter.unsatisfied_preconditions = counter.preconditions;
//        if (counter.unsatisfied_preconditions == 0) {
//            if (counter.effect->check_and_update(1, NULL)) {
//                exploration.push_back(counter.effect->id);
//            }
//        }
//    }
//
//    return lvl0;
//}

int HCHeuristic::simple_traversal_setup(const GlobalState &state,
        std::vector<unsigned> &exploration)
{
    exploration.clear();
    exploration.reserve(conjunctions.size());

    for (uint i = 0; i < conjunctions.size(); i++) {
        Conjunction &conj = conjunctions[i];
        conj.clear();
        if (fluent_in_state(_fluents[i], state)) {
            conj.check_and_update(0, NULL);
            exploration.push_back(i);
        }
    }
    conjunctions[m_true_id].check_and_update(0, NULL);
    exploration.push_back(m_true_id);

    for (uint i = 0; i < counters.size(); i++) {
        ActionEffectCounter &counter = counters[i];
        counter.unsatisfied_preconditions = counter.preconditions;
    }

    return exploration.size();
}


int HCHeuristic::simple_traversal_wrapper(
    std::vector<unsigned> &exploration, int lvl0)
{
    if (early_termination && conjunctions[m_goal_id].is_achieved()) {
        return 0;
    }

    unsigned i = 0;
    unsigned border = lvl0;
    int level = 0;
    int goal_level = 0;
    while (i < exploration.size()) {
        if (i == border) {
            border = exploration.size();
            level += 1;
        }
        unsigned conj_id = exploration[i++];
        const vector<ActionEffectCounter *> &triggered_counters =
            conjunctions[conj_id].triggered_counters;
        for (uint j = 0; j < triggered_counters.size(); j++) {
            ActionEffectCounter *counter = triggered_counters[j];
            if (--counter->unsatisfied_preconditions > 0) {
                continue;
            }
            if (!counter->effect->is_achieved()) {
                counter->effect->check_and_update(level, NULL);
                exploration.push_back(counter->effect->id);
                if (m_goal_id == counter->effect->id) {
                    goal_level = level;
                    if (early_termination) {
                        return level;
                    }
                }
            }
        }
    }

    return conjunctions[m_goal_id].is_achieved() ? goal_level : DEAD_END;
}

int HCHeuristic::simple_traversal(const GlobalState &state)
{
    vector<unsigned> exploration;
    int x = simple_traversal_setup(state, exploration);
    int res = simple_traversal_wrapper(exploration, x);
    exploration.clear();
    return res;
}


int HCHeuristic::compute_heuristic(const GlobalState &state)
{
    if (unit_cost()) {
        return simple_traversal(state);
    } else {
        return priority_traversal(state);
    }
    //return simple_traversal(state);
    //return priority_traversal(state);
}

bool HCHeuristic::contains_mutex(const Fluent &f1,
        const Fluent &f2) const
{
    Fluent::const_iterator it1 = f1.begin(), it1End = f1.end();
    while (it1 != it1End) {
        Fluent::const_iterator it2 = f2.begin(), it2End = f2.end();
        while (it2 != it2End) {
            if (are_mutex(*it1, *it2)) {
                //cout << "MUTEX: " << g_fact_names[it1->first][it1->second]
                //     << ", " << g_fact_names[it2->first][it2->second] << endl;
                return true;
            }
            it2++;
        }
        it1++;
    }

    return false;
}

bool HCHeuristic::contains_mutex(const Fluent &fluent) const
{
    if (fluent.size() <= 1) {
        return false;
    }

    Fluent::iterator
    it1 = fluent.begin(),
    it2 = fluent.end();

    while (it1 != fluent.end()) {
        it2 = it1;
        it2++;
        while (it2 != fluent.end()) {
            if (are_mutex(*it1, *it2)) {
                return true;
            }
            it2++;
        }
        it1++;
    }

    return false;
}

bool HCHeuristic::extract_mutex(const Fluent &fluent,
        Conflict &mutex) const
{
    if (fluent.size() <= 1) {
        return false;
    }

    Fluent::iterator
    it1 = fluent.begin(),
    it2 = fluent.end();

    while (it1 != fluent.end()) {
        it2 = it1;
        while (++it2 != fluent.end()) {
            if (are_mutex(*it1, *it2)) {
                unsigned f1 = get_fact_id(*it1);
                unsigned f2 = get_fact_id(*it2);
                mutex.merge(_fluents[f1]);
                mutex.merge(_fluents[f2]);
                return true;
            }
        }
        it1++;
    }

    return false;
}

void HCHeuristic::extract_all_conjunctions(const Fluent &fluent,
        std::vector<unsigned> &conjs_unr, std::vector<unsigned> &conjs, int cost) const
{
    vector<int> in_fluent;
    in_fluent.resize(conjunctions.size(), 0);
    for (Fluent::iterator f = fluent.begin(); f != fluent.end(); f++) {
        const vector<unsigned> &f_conjs = facts_conjunctions_relation[get_fact_id(*f)];
        for (uint i = 0; i < f_conjs.size(); i++) {
            unsigned cid = f_conjs[i];
            const Conjunction &conj = conjunctions[cid];
            if (++in_fluent[cid] == conj.fluent_size) {
                if (conj.is_achieved()) {
                    conjs_unr.push_back(cid);
                } else if (conj.cost >= cost) {
                    conjs.push_back(cid);
                }
            }
        }
    }
    in_fluent.clear();
}


void HCHeuristic::extract_all_conjunctions(const Fluent &fluent,
        std::vector<unsigned> &conjs)
{
    vector<int> in_fluent;
    in_fluent.resize(conjunctions.size(), 0);
    for (Fluent::iterator f = fluent.begin(); f != fluent.end(); f++) {
        const vector<unsigned> &f_conjs = facts_conjunctions_relation[get_fact_id(*f)];
        for (uint i = 0; i < f_conjs.size(); i++) {
            unsigned cid = f_conjs[i];
            in_fluent[cid]++;
            if (cid >= conjunction_offset &&
                //in_fluent[cid] == conjunctions[cid].fluent.size()) {
                in_fluent[cid] == conjunctions[cid].fluent_size) {
                conjs.push_back(cid);
            }
        }
    }
    in_fluent.clear();
}


/*
 * Updating conjunction set
 *
 */
bool HCHeuristic::add_subsets_m(const Fluent &/*base*/,
        bool /*is_goal*/, unsigned to_go)
{
    unsigned current_size = 2;
    unsigned start = 0,
           end = conjunction_offset;
    while (current_size <= to_go) {
        for (unsigned j = start; j < end; j++) {
            for (unsigned i = 0; i < conjunction_offset; i++) {
                const Fluent &fact = _fluents[i];
                if (_fluents[j].find(*fact.begin()) != _fluents[j].end()) {
                    continue;
                }
                if (hard_size_limit && exceeded_size_limit()) {
                    return false;
                }
                Fluent pi(_fluents[j]);
                pi.insert(*fact.begin());
                add_conflict(Conflict(pi));
            }
        }
        start = end;
        end = conjunctions.size();
        current_size++;
    }
    return true;
}

void HCHeuristic::compute_can_add(std::vector<int> &can_add_fluent,
        const Fluent &fluent) const
{
    can_add_fluent.resize(actions.size(), 0);
    // can_add_fluent[a] =
    //      -1: deletes some part of conjunction
    //      0: neither adds nor removes part of conjunction
    //      1: adds part of conjunction, but does not remove any part of
    //          conjunction
    for (Fluent::iterator f = fluent.begin(); f != fluent.end(); f++) {
        const vector<unsigned> &del_acts = facts_to_del[get_fact_id(*f)];
        for (uint j = 0; j < del_acts.size(); j++) {
            int aid = del_acts[j];
            can_add_fluent[aid] = -1;
        }
        const vector<unsigned> &add_acts = facts_to_add[get_fact_id(*f)];
        for (uint i = 0; i < add_acts.size(); i++) {
            int aid = add_acts[i];
            if (can_add_fluent[aid] != -1) {
                can_add_fluent[aid] = 1;
            }
        }
    }
}

void HCHeuristic::update_triggered_counters(unsigned conj_id)
{
    Conjunction &conj = conjunctions[conj_id];
    const Fluent &pi = _fluents[conj_id];

    // update counters where the current conjunction is in precondition
    // computing the set of existing counters where conj is in precondition
    //const set<int> &rel_counters = it->precondition_of;

    vector<int> comp_counters;
    comp_counters.resize(counters.size(), 0);
    for (Fluent::iterator fact = pi.begin(); fact != pi.end(); fact++) {
        unsigned fact_id = get_fact_id(*fact);
        facts_conjunctions_relation[fact_id].push_back(conj_id);
        for (uint i = 0; i < facts_to_counters[fact_id].size(); i++) {
            ActionEffectCounter *counter = facts_to_counters[fact_id][i];
            if (++comp_counters[counter->id] == conj.fluent_size) {
                add_counter_precondition(counter, &conj);
            }
        }
    }
    comp_counters.clear();
}

void HCHeuristic::create_counter(unsigned conj_id, int cost,
        const Fluent &precondition)
{
    unsigned counter_id = counters.size();
    counters.push_back(ActionEffectCounter(counter_id,
                       &conjunctions[conj_id],
                       cost));
    //if (conj_id >= conjunction_achievers.size()) {
    //    conjunction_achievers.resize(conj_id + 1);
    //}
    conjunction_achievers[conj_id].push_back(counter_id);
    //counter_preconditions.push_back(vector<int>());
    ActionEffectCounter &counter = counters[counter_id];

    if (!precondition.empty()) {
        vector<int> subset;
        subset.resize(conjunctions.size(), 0);
        for (Fluent::const_iterator it = precondition.begin(); it != precondition.end();
             it++) {
            unsigned fid = get_fact_id(*it);
            facts_to_counters[fid].push_back(&counter);
            const vector<unsigned> &conjs = facts_conjunctions_relation[fid];
            for (size_t i = 0; i < conjs.size(); i++) {
                const unsigned &cid = conjs[i];
                if (++subset[cid] == conjunctions[cid].fluent_size) {
                    add_counter_precondition(&counter, &conjunctions[cid]);
                }
            }
        }
        subset.clear();
    } else {
        add_counter_precondition(&counter, &conjunctions[m_true_id]);
    }
}

void HCHeuristic::add_conflict(const Conflict &confl)
{
    if (contains_mutex(confl.get_fluent())) {
        return;
    }

    unsigned conj_id = conjunctions.size();

    /* Update existing part */
    // add new conjunction to conjunctions set
    //conjunctions.push_back(Conjunction(conj_id, it->get_fluent()));
    // check whether conjunction existed before
    _fluents.push_back(confl.get_fluent());
    auto res = _unique_conjunctions.insert(conj_id);
    //pair<set<int>::iterator, bool> res;
    //res = _unique_conjunctions.insert(conj_id);
    if (!res.second) {
        // conjunction was already contained in conjunction set
        _fluents.pop_back();
        return;
    }

    // create new conjunction
    current_fluents++;
    conjunctions.push_back(Conjunction(conj_id, confl.get_fluent().size()));
    conjunction_achievers.push_back(std::vector<unsigned>());
    // if conjunction is goal, update goal_conjunctions accordingly

    update_triggered_counters(conj_id);

    vector<int> can_add_fluent;
    compute_can_add(can_add_fluent, confl.get_fluent());

    // add counters that add the new conjunction
    for (uint act = 0; act < can_add_fluent.size(); act++) {
        if (can_add_fluent[act] == 1) {
            const StripsAction &action = actions[act];

            //if (contains_mutex(confl.get_fluent(), action.precondition) ||
            //    contains_mutex(confl.get_fluent(), action.add_effect)) {
            //    continue;
            //}

            Fluent precondition;
            // precondition of new action consists of two parts
            //  (a) pre(a) \cup (c \setminus \add(a))
            //  (b) \pi_{c'} for every c' \in C and
            //          c' \subseteq (pre(a) \cup (c \setminus \add(a)))
            precondition.insert(action.precondition.begin(),
                                action.precondition.end());
            set_minus(confl.get_fluent(), action.add_effect, precondition);
            if (contains_mutex(precondition)) {
                continue;
            } else {
                (contains_mutex(confl.get_fluent(), action.add_effect));
            }
            create_counter(conj_id, act, precondition);
            precondition.clear();
        }
    }
}

bool HCHeuristic::update_c(
    set<Conflict> &new_conjunctions)
{
    if (new_conjunctions.size() == 0) {
        return true;
    }

    if (exceeded_size_limit()) {
        return false;
    }

    /* Instead of recompiling the whole task, we simply extend the existing
     * compiliation by introducing the new conjunctions, updating the
     * precondition of the existing actions, and adding new actions
     * accordingly */

    bool added_all_conjunctions = true;
    //conjunctions.reserve(conjunctions.size() + new_conjunctions.size());
    for (set<Conflict>::iterator it = new_conjunctions.begin();
         it != new_conjunctions.end(); it++) {
        if (hard_size_limit && exceeded_size_limit()) {
            added_all_conjunctions = false;
            break;
        }
        add_conflict(*it);
    }

    return added_all_conjunctions;
}

bool HCHeuristic::update_c(
    vector<Conflict> &new_conjunctions)
{
    if (new_conjunctions.size() == 0) {
        return true;
    }

    if (exceeded_size_limit()) {
        return false;
    }

    /* Instead of recompiling the whole task, we simply extend the existing
     * compiliation by introducing the new conjunctions, updating the
     * precondition of the existing actions, and adding new actions
     * accordingly */

    bool added_all_conjunctions = true;
    //conjunctions.reserve(conjunctions.size() + new_conjunctions.size());
    for (vector<Conflict>::const_iterator it = new_conjunctions.begin();
         it != new_conjunctions.end(); it++) {
        if (hard_size_limit && exceeded_size_limit()) {
            added_all_conjunctions = false;
            break;
        }
        add_conflict(*it);
    }

    return added_all_conjunctions;
}


void HCHeuristic::reset_size_limit_ratio()
{
    if (max_ratio_repr_counters < 0) {
        max_num_counters = -1;
    } else {
        max_num_counters = (int)(max_ratio_repr_counters * _num_counters);
    }
}

void HCHeuristic::set_size_limit_ratio(float ratio)
{
    if (ratio < 0) {
        max_num_counters = -1;
    } else {
        max_num_counters = (int)(ratio * _num_counters);
    }
    //std::cout << "SIZE LIMIT SET TO " << ratio << std::endl;
    //std::cout << "MAX#COUNTERS: " << max_num_counters << std::endl;
    //std::cout << _num_counters << std::endl;
    //std::cout << exceeded_size_limit() << std::endl;
}

bool HCHeuristic::reached_max_conjunctions() const
{
    return (max_number_fluents != (unsigned)-1 &&
            current_fluents >= max_number_fluents);
}

bool HCHeuristic::exceeded_size_limit() const
{
    return (max_number_fluents != (unsigned)-1 &&
            current_fluents >= max_number_fluents) ||
           (max_num_counters != (unsigned)-1 &&
            counters.size() >= max_num_counters);
}




void HCHeuristic::add_options_to_parser(OptionParser &parser)
{
    Heuristic::add_options_to_parser(parser);

    //parser.add_option<int>("c", "maximum size of conjunction set C", "-1");
    //parser.add_option<float>("x",
    //                         "maximum size of the compilation Pi^C relative to Pi", "-1");
    parser.add_option<bool>("hard_limit", "hard size limit", "true");
    parser.add_option<int>("m", "adding all conjunctions of size <= m", "0");
    parser.add_option<bool>("prune_pre", "prune precondition", "true");
    parser.add_option<string>("file", "load conjunctions from file", "none");
    parser.add_option<bool>("early_term", "", "true");
    parser.add_option<CInitializer*>("cinit", "", "", OptionFlags(false));
}

string HCHeuristic::get_description() const
{
    return "hc";
}
void HCHeuristic::dump_options(std::ostream &out) const
{
    out << "Maximal size of conjunctions set: ";
    if (max_number_fluents == (unsigned)-1) {
        out << "unlimited" << endl;
    } else {
        out << max_number_fluents << endl;
    }
    out << "Maximal number of counters: ";
    if (max_num_counters == (unsigned)-1) {
        out << "unlimited" << endl;
    } else {
        out << max_num_counters << " (ratio: "
            << ((max_num_counters / _num_counters)) << ")"
            << endl;
    }
    cout << "Hard size limit: " << hard_size_limit << endl;
}
void HCHeuristic::dump_statistics(std::ostream &out) const
{
    dump_compilation_information(out);
#if TIME_ANALYSIS
    out << "["
        << ((double) G_t1 / CLOCKS_PER_SEC)
        << "]" << endl;
#endif
#if DUMP_CONJUNCTIONS_
    //dump_c_pddl(true, false, false);
    std::ofstream fout("pi_fluents.txt");
    dump_conjunctions_to_ostream(fout);
    fout.close();
#endif
}


void HCHeuristic::dump_heuristic_values(std::ostream &out) const
{
    for (size_t i = 0; i < conjunctions.size(); i++) {
        out << "(" << i << ") ";
        dump_fluent_pddl(_fluents[i], out);
        out << ": ";
        if (!conjunctions[i].is_achieved()) {
            out << "infinity" << endl;
        } else {
            out << conjunctions[i].cost << endl;
        }
    }
}

void HCHeuristic::dump_statistics_json(std::ostream &out) const
{
    out << ","
        << "\"pic_size_C\":" << current_fluents << ","
        << "\"pic_max_size_C\":" << max_number_fluents << ","
        << "\"pic_num_facts\":" << conjunction_offset << ","
        << "\"pic_num_actions\":" << actions.size() << ","
        << "\"pic_num_counters\":" << counters.size() << ","
        << "\"pic_num_repr_counters\":" << counters.size() - _num_counters << ","
        << "\"pic_max_num_counters\":" << max_num_counters;
}

void HCHeuristic::dump_compilation_information(ostream &out) const
{
    out << "Pi^C: "
        << conjunction_offset << " facts, "
        << current_fluents << " conjunctions, "
        << counters.size() << " (" << _num_counters << ") counters, "
        << get_counter_ratio() << " counter ratio"
        << endl;
}

static Heuristic *_parse(OptionParser &parser)
{
    HCHeuristic::add_options_to_parser(parser);

    Options opts = parser.parse();

    if (parser.dry_run()) {
        return 0;
    } else {
        return new HCHeuristic(opts);
    }
}


static Plugin<Heuristic> _plugin("hc", _parse);


