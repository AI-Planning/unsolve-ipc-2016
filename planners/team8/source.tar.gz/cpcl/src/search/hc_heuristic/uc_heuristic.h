
#ifndef UC_HEURISTIC_H
#define UC_HEURISTIC_H

#include "../unsatisfiability_heuristic.h"

#include "hc_heuristic.h"
#include "uc_clause_learning.h"
#include "uc_refinement.h"
#include "uc_statistics.h"

#include <unordered_set>
#include <vector>

class UCHeuristic : public HCHeuristic, public UnsatisfiabilityHeuristic
{
protected:
    UCHeuristicStatistics statistics;
    ClauseStore *clause_store;
    UCRefinement *refinement;
    UCClauseLearning *clause_learning;
    const bool c_rnc;
    const bool c_eval_hc;
public:
    UCHeuristic(const Options &opts);
    virtual bool evaluate_dead_end(const GlobalState &state);
    virtual bool refine(const std::vector<GlobalState> &root,
                        const std::unordered_set<StateID> &rn);
    virtual void learn(const GlobalState &state);
    virtual void learn(const std::vector<GlobalState> &dead_ends);
    virtual bool fast_dead_end_check(const GlobalState &state);
    virtual bool slow_dead_end_check(const GlobalState &state);
    virtual bool is_refinement_enabled() const;
    virtual bool refinement_requires_rn() const;
    virtual bool refinement_requires_scc() const;
    virtual void print_statistics() const;
    virtual void print_statistics_short() const;

    static void add_options_to_parser(OptionParser &parser);
};

#endif

