
#ifndef SEARCH_H
#define SEARCH_H

#include "search_engine.h"

#include "search_space.h"
#include "state_id.h"

#include <ctime>

class Heuristic;
class UnsatisfiabilityHeuristic;
class OpenSet;
class Options;
class OptionParser;
class GlobalState;

#include <vector>
#include <unordered_set>

class Search : public SearchEngine
{
protected:
    SearchSpace search_space;

    size_t _num_expansions;
    bool unsath_refine;

    const bool c_unsath_new;
    const bool c_unsath_open;
    const bool c_unsath_closed;

    OpenSet *open_set;
    Heuristic *search_h;
    UnsatisfiabilityHeuristic *unsat_h;
    Heuristic *unsat_h_search;

    int cached_h;
    bool cached_dead_end;

    StateID init_state_id;

    void evaluate(const GlobalState &state);

    bool check_goal_and_set_plan(const GlobalState &state);

    bool check_and_learn_dead_end(const SearchNode &node);
    bool search_open_state(SearchNode node,
                           std::vector<GlobalState> &closed_states,
                           std::unordered_set<StateID> &rn,
                           std::vector<GlobalState> &open_states,
                           bool &init);
    void backward_propagation(const GlobalState &state);
    void backward_propagation(const std::vector<GlobalState> &state);
    void mark_dead_ends(SearchNode node, std::vector<GlobalState> &open);
    void mark_dead_ends(std::vector<GlobalState> &dead_ends, std::vector<GlobalState> &open);

    virtual void initialize();
    virtual SearchStatus step();

    void print_statistics() const;
public:
    Search(const Options &opts);
    static void add_options_to_parser(OptionParser &parser);
};

#endif
