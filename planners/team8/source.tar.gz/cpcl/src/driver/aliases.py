# -*- coding: utf-8 -*-
from __future__ import print_function

import os

from .run_components import DRIVER_DIR


PORTFOLIO_DIR = os.path.join(DRIVER_DIR, "portfolios")

ALIASES = {}

ALIASES["unsat-ipc-dfsh1"] = ["--search", "search(search_h=hc(cost_type=ONE), cost_type=ONE)"]

ALIASES["unsat-ipc-cl-1"] = ["--search", "search(unsat_h=uc(x=-1, refinement=bw2_1(u_succ=true, u_size=true), clauses=cpg, cinit=scc, cost_type=ONE), u_new=false, u_open=true, u_closed=false, cost_type=ONE)"]

ALIASES["unsat-ipc-cl-2"] = ["--search", "search(open_set=dfsrt(), unsat_h=uc(x=-1, refinement=bw2_1(u_succ=true, u_size=true), clauses=cpg, cinit=scc, cost_type=ONE), u_new=false, u_open=true, u_closed=false, cost_type=ONE)"]

PORTFOLIOS = {}
for portfolio in os.listdir(PORTFOLIO_DIR):
    name, ext = os.path.splitext(portfolio)
    assert ext == ".py", portfolio
    PORTFOLIOS[name.replace("_", "-")] = os.path.join(PORTFOLIO_DIR, portfolio)


def show_aliases():
    for alias in sorted(ALIASES.keys() + PORTFOLIOS.keys()):
        print(alias)


def set_options_for_alias(alias_name, args):
    """
    If alias_name is an alias for a configuration, set args.search_options
    to the corresponding command-line arguments. If it is an alias for a
    portfolio, set args.portfolio to the path to the portfolio file.
    Otherwise raise KeyError.
    """
    assert not args.search_options
    assert not args.portfolio

    if alias_name in ALIASES:
        args.search_options = ALIASES[alias_name]
    elif alias_name in PORTFOLIOS:
        args.portfolio = PORTFOLIOS[alias_name]
    else:
        raise KeyError(alias_name)
