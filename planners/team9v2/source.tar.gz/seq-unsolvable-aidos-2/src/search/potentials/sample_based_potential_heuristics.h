#ifndef POTENTIALS_SAMPLE_BASED_POTENTIAL_HEURISTICS_H
#define POTENTIALS_SAMPLE_BASED_POTENTIAL_HEURISTICS_H

/*
  The corresponding .cc file defines a plugin that creates sample-based
  potential heuristics.

  We keep the empty header to simplify our build system.
*/

#endif
