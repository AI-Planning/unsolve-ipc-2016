#ifndef GLOBALS_H
#define GLOBALS_H

#include <iosfwd>
#include <string>
#include <vector>

#ifndef NDEBUG
// #define DEBUG_SEARCH    // general debugging
// #define DEBUG_PAINTING
// #define DEBUG_PLAN_EXTRACTION
//#define DEBUG_SUCCESSOR_GENERATION
#endif

class Axiom;
class AxiomEvaluator;
class CausalGraph;
class DomainTransitionGraph;
class Painting;
class IntPacker;
class Operator;
class RandomNumberGenerator;
class State;
class StateID;
class SuccessorGenerator;
class Timer;
class StateRegistry;

bool test_goal(const State &state);
void save_plan(const std::vector<const Operator *> &plan, int iter);
int calculate_plan_cost(const std::vector<const Operator *> &plan);

void read_everything(std::istream &in);
void dump_everything();

bool is_unit_cost();
bool has_axioms();
void verify_no_axioms();
bool has_conditional_effects();
void verify_no_conditional_effects();
void verify_no_axioms_no_conditional_effects();

void check_magic(std::istream &in, std::string magic);

bool are_mutex(const std::pair<int, int> &a, const std::pair<int, int> &b);

// ~MJ. states whether to use reorder or not
extern bool g_reordering;
// ~MJ. defines which reordering technique to use
extern std::string g_reordering_technique;
// ~MJ. to decide between hill_climbing versions
extern std::string g_reordering_version;
// ~MJ. max number of plans to compute during optimal reordering
extern int G_MAX_SAMPLES;

//~MJ. number of random plan redblack reorderings to compute during sampling
extern int G_RANDOM_SAMPLES;

//~MJ. computes on random reordered rb plan from operators
std::vector<const Operator *> sample_random_rb_plan(std::vector<const Operator *> &operators);


// ~MJ. the number of conflicts from the initial red-black plan
extern int g_conflicts;
int countConflicts(const std::vector<const Operator *> &plan);

extern bool g_use_metric;
extern int g_min_action_cost;
extern int g_max_action_cost;

extern bool g_random_reorder;

extern bool g_rb_plan_sampling;
extern int G_SAMPLING_TIMEOUT;
extern std::string g_input_plan_name;

extern Painting *g_painting;
extern bool g_use_redblack_search;

extern std::vector<std::string> g_variable_name;
extern std::vector<int> g_variable_domain;

extern std::vector<std::vector<std::string> > g_fact_names;
extern std::vector<int> g_axiom_layers;
extern std::vector<int> g_default_axiom_values;

extern IntPacker *g_state_packer;

// This vector holds the initial values *before* the axioms have been evaluated.
// Use the state registry to obtain the real initial state.
extern std::vector<int> g_initial_state_data;
// TODO The following function returns the initial state that is registered
//      in g_state_registry. This is only a short-term solution. In the
//      medium term, we should get rid of the global registry.
extern const State &g_initial_state();

extern std::vector<std::pair<int, int> > g_goal;

extern std::vector<Operator> g_operators;
extern std::vector<Operator> g_axioms;
extern AxiomEvaluator *g_axiom_evaluator;
extern SuccessorGenerator *g_successor_generator;
extern std::vector<DomainTransitionGraph *> g_transition_graphs;
extern CausalGraph *g_causal_graph;
extern Timer g_timer;
extern std::string g_plan_filename;
extern RandomNumberGenerator g_rng;
// Only one global object for now. Could later be changed to use one instance
// for each problem in this case the method State::get_id would also have to be
// changed.
extern StateRegistry *g_state_registry;



#endif
