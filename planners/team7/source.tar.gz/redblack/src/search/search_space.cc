#include "search_space.h"

#include "globals.h"
#include "operator.h"
#include "painting.h"
#include "search_node_info.h"
#include "state.h"

#include <cassert>
#include <limits>

using namespace std;
using namespace __gnu_cxx;


SearchNode::SearchNode(StateID state_id_, SearchNodeInfo &info_,
                       OperatorCost cost_type_)
    : state_id(state_id_), info(info_), cost_type(cost_type_) {
    assert(state_id != StateID::no_state);
}

State SearchNode::get_state() const {
    return g_state_registry->lookup_state(state_id);
}

bool SearchNode::is_open() const {
    return info.status == SearchNodeInfo::OPEN;
}

bool SearchNode::is_closed() const {
    return info.status == SearchNodeInfo::CLOSED;
}

bool SearchNode::is_dead_end() const {
    return info.status == SearchNodeInfo::DEAD_END;
}

bool SearchNode::is_new() const {
    return info.status == SearchNodeInfo::NEW;
}

int SearchNode::get_g() const {
    return info.g;
}

int SearchNode::get_real_g() const {
    return info.real_g;
}

int SearchNode::get_h() const {
    return info.h;
}

bool SearchNode::is_h_dirty() const {
    return info.h_is_dirty;
}

void SearchNode::set_h_dirty() {
    info.h_is_dirty = true;
}

void SearchNode::clear_h_dirty() {
    info.h_is_dirty = false;
}

void SearchNode::open_initial(int h) {
    assert(info.status == SearchNodeInfo::NEW);
    info.status = SearchNodeInfo::OPEN;
    info.g = 0;
    info.real_g = 0;
    info.h = h;
    info.parent_state_id = StateID::no_state;
    info.creating_operator = 0;
}

void SearchNode::open(int h, const SearchNode &parent_node,
                      const Operator *parent_op) {
    assert(info.status == SearchNodeInfo::NEW);
    info.status = SearchNodeInfo::OPEN;
    info.g = parent_node.info.g + get_adjusted_action_cost(*parent_op, cost_type);
    info.real_g = parent_node.info.real_g + parent_op->get_cost();
    info.h = h;
    info.parent_state_id = parent_node.get_state_id();
    info.creating_operator = parent_op;
}

void SearchNode::reopen(const SearchNode &parent_node,
                        const Operator *parent_op) {
    assert(info.status == SearchNodeInfo::OPEN ||
           info.status == SearchNodeInfo::CLOSED);

    // The latter possibility is for inconsistent heuristics, which
    // may require reopening closed nodes.
    info.status = SearchNodeInfo::OPEN;
    info.g = parent_node.info.g + get_adjusted_action_cost(*parent_op, cost_type);
    info.real_g = parent_node.info.real_g + parent_op->get_cost();
    info.parent_state_id = parent_node.get_state_id();
    info.creating_operator = parent_op;
}

// like reopen, except doesn't change status
void SearchNode::update_parent(const SearchNode &parent_node,
                               const Operator *parent_op) {
    assert(info.status == SearchNodeInfo::OPEN ||
           info.status == SearchNodeInfo::CLOSED);
    // The latter possibility is for inconsistent heuristics, which
    // may require reopening closed nodes.
    info.g = parent_node.info.g + get_adjusted_action_cost(*parent_op, cost_type);
    info.real_g = parent_node.info.real_g + parent_op->get_cost();
    info.parent_state_id = parent_node.get_state_id();
    info.creating_operator = parent_op;
}

void SearchNode::increase_h(int h) {
    assert(h >= info.h);
    info.h = h;
}

void SearchNode::close() {
    assert(info.status == SearchNodeInfo::OPEN);
    info.status = SearchNodeInfo::CLOSED;
}

void SearchNode::mark_as_dead_end() {
    info.status = SearchNodeInfo::DEAD_END;
}

void SearchNode::dump() const {
    cout << state_id << ": ";
    cout << "g = " << info.g << " h = " << info.h << endl;
    g_state_registry->lookup_state(state_id).dump_pddl();
    if (info.creating_operator) {
        cout << " created by " << info.creating_operator->get_name()
             << " from " << info.parent_state_id << endl;
    } else {
        cout << " no parent" << endl;
    }
}

SearchSpace::SearchSpace(OperatorCost cost_type_)
    : cost_type(cost_type_) {
}

SearchNode SearchSpace::get_node(const State &state) {
    return SearchNode(state.get_id(), search_node_infos[state], cost_type);
}

void SearchSpace::trace_path(const State &goal_state,
                             vector<const Operator *> &path) const {

    State current_state = goal_state;
    
    vector<vector<vector<const Operator*> > > best_supporters;
    
    assert(path.empty());
    
    for (;;) {          // backtrace solution path
        const SearchNodeInfo &info = search_node_infos[current_state];
        const Operator *op = info.creating_operator;

        if (op == 0) {  // reached initial state => done
            best_supporters.push_back(g_state_registry->get_init_state_best_supporters());
            assert(info.parent_state_id == StateID::no_state);
            break;
        }
        
        assert(!g_use_redblack_search || op->is_black_op());

        path.push_back(op);
        current_state = g_state_registry->lookup_state(info.parent_state_id);
        
        if (g_use_redblack_search){
            g_state_registry->get_successor_state(current_state, *op, true);
            best_supporters.push_back(g_state_registry->get_stored_best_supporters());
            // TODO to not waste so much memory, could do the whole relaxed plan reconstruction here
        }
    }
    
    reverse(path.begin(), path.end());
    
    if (g_use_redblack_search){
        
        reverse(best_supporters.begin(), best_supporters.end());
        
        set<pair<int, int> > marked_facts;
        for (auto const &goal : g_goal){
            if (g_painting->is_red_var(goal.first)){
                marked_facts.insert(goal);
#ifdef DEBUG_PLAN_EXTRACTION
                cout << "marked goal fact " << g_fact_names[goal.first][goal.second] << endl;
#endif
            }
        }
        
        vector<const Operator*> plan;
        
        for (int step = best_supporters.size() - 1; step >= 0; --step){
#ifdef DEBUG_PLAN_EXTRACTION
            cout << "step " << step << endl;
#endif
            
            vector<const Operator*> ops_current_step;
            set<pair<int, int> > remaining_marked;
            set<pair<int, int> > new_marked;
            
            bool change = true;
            while (change){
                change = false;
                
                new_marked.clear();
                for (auto const &fact : marked_facts){
#ifdef DEBUG_PLAN_EXTRACTION
                    cout << "handling fact " << g_fact_names[fact.first][fact.second];
#endif
                    const Operator *op = best_supporters[step][fact.first][fact.second];
                    if (op == 0){
#ifdef DEBUG_PLAN_EXTRACTION                        
                        cout << " => cannot be achieved in this step" << endl;
#endif
                        remaining_marked.insert(fact);
                        continue;
                    }
                    
#ifdef DEBUG_PLAN_EXTRACTION                        
                    cout << endl << "best supporter: " << op->get_name() << endl;;
#endif
                    
                    if (find(ops_current_step.begin(), ops_current_step.end(), op) == ops_current_step.end()){
                        ops_current_step.push_back(op);
                        for (auto const &pre : op->get_red_pre()){
                                
                            change |= new_marked.insert(make_pair(pre->var, pre->val)).second;
#ifdef DEBUG_PLAN_EXTRACTION
                            cout << "marked precondition fact " << g_fact_names[pre->var][pre->val] << endl;
#endif
                        }
                    }
                }
                marked_facts.swap(new_marked);
            }
            marked_facts.insert(remaining_marked.begin(), remaining_marked.end());
            
            
            // sequence the red operators so that they form a valid relaxed plan
            vector<vector<bool> > current_red_state(g_variable_domain.size());
            for (size_t var = 0; var < g_variable_domain.size(); ++var){
                if (g_painting->is_red_var(var)){
                    current_red_state[var].resize(g_variable_domain[var], false);
                }
            }
            
            vector<const Operator*> sorted_ops;
            vector<bool> handled_ops(ops_current_step.size(), false);
            while (sorted_ops.size() < ops_current_step.size()){
                for (size_t i = 0; i < ops_current_step.size(); ++i){
                    if (handled_ops[i]){
                        continue;
                    }
                    const Operator *op = ops_current_step[i];
#ifdef DEBUG_PLAN_EXTRACTION                        
                    cout << "handling op " << op->get_name();
#endif                
                    bool is_applicable = true;
                    for (auto const &pre : op->get_red_pre()){
                        if (!current_red_state[pre->var][pre->val] && best_supporters[step][pre->var][pre->val] != 0){
                            is_applicable = false;
#ifdef DEBUG_PLAN_EXTRACTION                        
                            cout << " not applicable => keep for later";
#endif
                            break;
                        }
                    }
                    if (is_applicable){
                        handled_ops[i] = true;
                        sorted_ops.push_back(op);
                        for (auto const &eff : op->get_red_eff()){
                            current_red_state[eff->var][eff->val] = true;
                        }
                    }
                }
            }
            
            plan.insert(plan.end(), sorted_ops.rbegin(), sorted_ops.rend());
            if (step != 0){
                const Operator *black_op = path[step - 1];
#ifdef DEBUG_PLAN_EXTRACTION
                cout << "appended black action " << black_op->get_name() << endl;
#endif
                plan.push_back(black_op);
                for (auto const &pre : black_op->get_red_pre()){
                    marked_facts.insert(make_pair(pre->var, pre->val));
                }
                for (auto const &eff : black_op->get_red_eff()){
                    marked_facts.erase(make_pair(eff->var, eff->val));
                }
            }
        }
        
        path = plan;
        
        reverse(path.begin(), path.end());
        
#ifdef DEBUG_PLAN_EXTRACTION
        cout << endl;
        for (auto const &op : path){
            cout << op->get_name() << endl;
        }
        cout << endl;
#endif
        
#ifndef NDEBUG
        size_t number_red = 0;
        for (size_t var = 0; var < g_variable_domain.size(); ++var){
            if (g_painting->is_red_var(var)){
                ++number_red;
            }
        }
        // only init state fact must be marked in the end
        // this is kind of a weak condition, it still allows multiple marked
        // facts for a single red variable in case there are others that are
        // not used at all
        assert(marked_facts.size() <= number_red);
#endif        
        assert(is_redblack_plan(path));
        
        if (!is_real_plan(path)){
            exit_with(EXIT_UNSOLVED_INCOMPLETE);
        }
        
    }
}

bool SearchSpace::is_real_plan(const vector<const Operator*> &plan) const {
    vector<int> state(g_variable_domain.size(), -1);
    
    for (size_t var = 0; var < g_variable_domain.size(); ++var){
        state[var] = g_initial_state_data[var];
    }
    
    for (auto const &op : plan){
        for (auto const &pre : op->get_preconditions()){
            if (state[pre.var] != pre.val){
                return false;
            }
        }
        
        for (auto const &eff : op->get_effects()){
            state[eff.var] = eff.val;
        }
    }
    
    for (auto const &goal : g_goal){
        if (state[goal.first] != goal.second){
            return false;
        }
    }
    
    return true;
}

bool SearchSpace::is_redblack_plan(const vector<const Operator*> &plan) const {
    vector<int> black_state(g_variable_domain.size(), -1);
    vector<vector<bool> > red_state(g_variable_domain.size());
    for (size_t var = 0; var < g_variable_domain.size(); ++var){
        if (g_painting->is_black_var(var)){
            black_state[var] = g_initial_state_data[var];
        } else {
            red_state[var].resize(g_variable_domain[var], false);
            red_state[var][g_initial_state_data[var]] = true;
        }
    }
    
    for (auto const &op : plan){
#ifdef DEBUG_PLAN_EXTRACTION
        cout << op->get_name() << endl;
#endif
        for (auto const &pre : op->get_red_pre()){
            if (!red_state[pre->var][pre->val]){
                cout << "red precondition of op not fulfilled: " << op->get_name() << " - " << g_fact_names[pre->var][pre->val] << endl;;
                return false;
            }
        }
        for (auto const &pre : op->get_black_pre()){
            if (black_state[pre->var] != pre->val){
                cout << "black precondition of op not fulfilled: " << op->get_name() << " - " << g_fact_names[pre->var][pre->val] << endl;;
                return false;
            }
        }
        
        for (auto const &eff : op->get_red_eff()){
            red_state[eff->var][eff->val] = true;
        }
        for (auto const &eff : op->get_black_eff()){
            black_state[eff->var] = eff->val;
        }
    }
    
    for (auto const &goal : g_goal){
        if (g_painting->is_black_var(goal.first)){
            if (black_state[goal.first] != goal.second){
                cout << "black goal is not fulfilled: " << g_fact_names[goal.first][goal.second] << endl;
                return false;
            }
        } else {
            if (!red_state[goal.first][goal.second]){
                cout << "red goal is not fulfilled: " << g_fact_names[goal.first][goal.second] << endl;
                return false;
            }
        }
    }
    
    return true;
}

void SearchSpace::dump() const {
    for (PerStateInformation<SearchNodeInfo>::const_iterator it =
            search_node_infos.begin(g_state_registry);
         it != search_node_infos.end(g_state_registry); ++it) {
        StateID id = *it;
        State s = g_state_registry->lookup_state(id);
        const SearchNodeInfo &node_info = search_node_infos[s];
        cout << id << ": ";
        s.dump_fdr();
        if (node_info.creating_operator && node_info.parent_state_id != StateID::no_state) {
            cout << " created by " << node_info.creating_operator->get_name()
                 << " from " << node_info.parent_state_id << endl;
        } else {
            cout << "has no parent" << endl;
        }
    }
}

void SearchSpace::statistics() const {
    cout << "Number of registered states: " << g_state_registry->size() << endl;
}
