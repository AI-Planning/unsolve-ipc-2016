#include "globals.h"

#include "axioms.h"
#include "causal_graph.h"
#include "domain_transition_graph.h"
#include "painting.h"
#include "heuristic.h"
#include "int_packer.h"
#include "operator.h"
#include "rng.h"
#include "state.h"
#include "state_registry.h"
#include "successor_generator.h"
#include "timer.h"
#include "utilities.h"

#include <cstdlib>
#include <fstream>
#include <iostream>
#include <limits>
#include <set>
#include <string>
#include <vector>
#include <sstream>
#include <ctime>
#include <utility>
#include <random>
#include <chrono>
#include <locale>

using namespace std;


static const int PRE_FILE_VERSION = 3;


// ~MJ. generate all possible successor nodes for hill climbing reordering
//#define GENALL


/*
  ~MJ. helper methods used by all reordering techniques
*/
bool isApplicable(std::vector<int> &stateFacts,const Operator* a);
int countConflicts(const std::vector<const Operator *> &plan);
std::vector<int> determineConflictOps(const std::vector<const Operator *> &plan);
std::vector< std::vector< int > > getInitialStateFactsRb();
bool isRbApplicable(const std::vector<std::vector<int> > &s, const Operator * a);
std::vector<std::vector<int> > applyRbAction(const std::vector<std::vector<int> > &stateFacts, const Operator *a);
std::vector< std::pair < int,int > > unsuppPreconditions(std::vector<int> &stateFacts,const Operator *a);
void applyRealEffectsOfAction(vector <int> &stateFacts,const Operator* op);
template<class T> void shuffle(vector<T> &vector);
bool validate_redblack_plan(const vector < const Operator*> &plan);


int g_seed = chrono::high_resolution_clock::now().time_since_epoch().count();
mt19937 random_generator(g_seed);
/*
  ~MJ. methods implementing optimal but computational intensive reordering technique
*/
std::vector<const Operator *> reorderNaive(std::vector<const Operator *> &plan);
std::pair<const std::vector<const Operator *>, int> reorderRedBlack(
		const std::vector<const Operator *> &planPart,
		std::vector<const Operator *> &remainingOps,
		const std::vector<std::vector<int> > &stateFacts);

/*
  ~MJ. methods used for Hill climbing reordering technique
*/
std::vector<const Operator *> reorderHillClimbing (const std::vector<const Operator *> &plan);
void generateChildNode(std::vector < std::vector<const Operator *> > &plan);
void generateChildNodeOld(std::vector < std::vector< const Operator *> > &plan);


//~MJ for optimal reordering technique
int minConflicts;
vector<const Operator *> minPlan;
int sample_count = 0;

// TODO: This needs a proper type and should be moved to a separate
//       mutexes.cc file or similar, accessed via something called
//       g_mutexes. (Right now, the interface is via global function
//       are_mutex, which is at least better than exposing the data
//       structure globally.)

static vector<vector<set<pair<int, int> > > > g_inconsistent_facts;

bool test_goal(const State &state) {
	for (size_t i = 0; i < g_goal.size(); ++i) {
		if (g_use_redblack_search && g_painting->is_red_var(g_goal[i].first)) {
			if (!state.has_fact(g_goal[i].first, g_goal[i].second)) {
				return false;
			}
		} else if (state[g_goal[i].first] != g_goal[i].second) {
			return false;
		}
	}
	return true;
}

bool test_goal_rb(const vector<vector<int> > &stateFacts) {
	for (size_t i = 0; i < g_goal.size(); i++) {
		bool fulfilled = false;
		int var = g_goal[i].first;
		int val = g_goal[i].second;
		for (size_t j = 0; j < stateFacts[var].size(); j++) {
			if (stateFacts[var][j] == val) {
				fulfilled = true;
				break;
			}
		}
		if(!fulfilled)
			return false;
	}
	return true;
}


int calculate_plan_cost(const vector<const Operator *> &plan) {
    // TODO: Refactor: this is only used by save_plan (see below)
    //       and the SearchEngine classes and hence should maybe
    //       be moved into the SearchEngine (along with save_plan).
    int plan_cost = 0;
    for (size_t i = 0; i < plan.size(); ++i) {
        plan_cost += plan[i]->get_cost();
    }
    return plan_cost;
}


/* ~MJ. begin
  ##############################################################################
  ##############################################################################
  helper methods for reordering techniques
*/
/**
	returns the initial state of the red-black planning task
*/
vector<vector<int> > getInitialStateFactsRb() {
	// ~MJ. taken from lazy_search_rb.cc
	vector<vector<int> > initstatefacts;
	initstatefacts.resize(g_variable_name.size());
	for (size_t i = 0; i < g_variable_name.size(); i++) {
		// There is exactly one value for each variable in the initial state.
		initstatefacts[i].resize(1);
		initstatefacts[i][0] = g_initial_state_data[i];
	}
	return initstatefacts;
}


/** ~MJ. uses real semantics to count the number of Conflicts in the given plan
	returns the number of conflicts (= number of unsupported preconditions)
*/

int countConflicts(const vector<const Operator *> &plan) {
	//initialize initstate facts
	int conflicts = 0;

	vector<int> currentStateFacts = g_initial_state_data;

	//iterate over plan actions
	for (size_t i = 0; i < plan.size(); i++) {
		const Operator* currentOp = plan[i];
		//check for conflict
		conflicts += unsuppPreconditions(currentStateFacts, currentOp).size();
		//apply effects of action
		applyRealEffectsOfAction(currentStateFacts, currentOp);
	}

	for (size_t i = 0; i < g_goal.size(); i++) {
		int var = g_goal[i].first;
		int val = g_goal[i].second;
		if (currentStateFacts[var] != val)
			conflicts++;
	}

	return conflicts;
}

/*
 Same as countConflicts, but stores also the conflict Operators offset in the plan;
 */
vector<int> determineConflictOps(const vector<const Operator *> &plan) {
	//initialize initstate facts
	vector<int> conflictActionsOffsets;
	vector<int> currentStateFacts = g_initial_state_data;
	//iterate over plan actions
	for (size_t i = 0; i < plan.size(); i++) {
		const Operator* currentOp = plan[i];
		//check for conflict
		if (!isApplicable(currentStateFacts, currentOp)) {
			conflictActionsOffsets.push_back(i);
		}
		//apply effects of action
		applyRealEffectsOfAction(currentStateFacts, currentOp);

	}
	return conflictActionsOffsets;
}

bool isApplicable(vector<int> &stateFacts,const Operator* a){
   // ~MJ. check appliability for stateFacts
   const vector< Condition > &preconditions = a->get_preconditions();
   //cout << "isApplicable preconditions size = " << preconditions.size() << endl;
   for(size_t i=0; i< preconditions.size(); i++) {
        int var = preconditions[i].var;
        int val = preconditions[i].val;
        if(stateFacts[var] != val){
            return false;
        }
   }
   return true;
}
/*
  returns the unsupported Preconditions of the operator a in the state given by
  stateFacts
*/
vector< pair < int,int > > unsuppPreconditions(vector<int> &stateFacts,const Operator* a){
  vector< pair< int,int > > unsuppPrecond;
  const vector< Condition > &preconditions = a->get_preconditions();
  for(size_t i=0; i< preconditions.size(); i++) {
       int var = preconditions[i].var;
       int val = preconditions[i].val;
       if(stateFacts[var] != val){
         unsuppPrecond.push_back(make_pair(var,val));
       }

  }
  return unsuppPrecond;
}

/*
  ~MJ. start reordering techniques
  ################################################################
  ################################################################
*/


/**
	Finds the conflict minimizing ordering of the given plan.
	Brute forces all orderings resulting in a valid red-black plan
  This is the iterative version, seems to be slower than the recursive
*/
/*
vector< std::tr1::tuple < vector <const Operator *>, vector <const Operator *>, vector< vector <int> > > > stack;
vector<const Operator *> reorderNaive2 (const vector<const Operator *> &plan){
  vector <const Operator *> minPlan = plan;
  int minConflicts = countConflicts(plan);
  int initConflicts = minConflicts;
  vector<const Operator *> planPrefix;
  stack.push_back(std::tr1::make_tuple(planPrefix, plan, getInitialStateFactsRb()));
  while(stack.size() != 0){
    std::tr1::tuple < vector <const Operator *>, vector <const Operator *>, vector< vector <int> > > currTuple = stack[stack.size() - 1];
    stack.pop_back();
    vector <const Operator *> planPrefix = std::tr1::get<0>(currTuple);
    vector <const Operator *> remainingOps = std::tr1::get<1>(currTuple);

    vector< vector<int> > stateFacts = std::tr1::get<2>(currTuple);

    int currConflicts = countConflicts(planPrefix);
    if(currConflicts >= initConflicts){
      continue;
    }
    // planPrefix contains all operators
    if( remainingOps.size() == 0){
      // planPrefix is valid plan
      //StateRB* goalTest = new StateRB(stateFacts);
      //bool isGoal = test_goal_rb(goalTest);
      //delete goalTest;
      //if(isGoal){
        //compare with so far best ordering
        if(currConflicts < minConflicts){
          minConflicts = currConflicts;
          minPlan = planPrefix;
        }
      //}
      continue;
    }

    // compute the red-black applicable operators
    vector< int > applicableOps;
    for(size_t i = 0; i < remainingOps.size(); i++){
        const Operator* curOp = remainingOps[i];
        if(isRbApplicable(stateFacts,curOp)){
            applicableOps.push_back(i);
        }
    }
    for(size_t i = 0; i< applicableOps.size(); i++){
      int applOpOffset = applicableOps[i];
      const Operator* curOp = remainingOps[applOpOffset];

      //prepare the stack entry
      vector<const Operator *> newPlanPart = planPrefix;
      newPlanPart.push_back(curOp);

      vector<const Operator *> newRemainingOps = remainingOps;

      newRemainingOps.erase(newRemainingOps.begin() + applOpOffset);
      vector < vector <int> > succState = applyRbAction(stateFacts,curOp);
      stack.push_back(std::tr1::make_tuple(newPlanPart,newRemainingOps, succState));
    }

  }
  return minPlan;
}
*/

/**
	Finds the conflict minimizing ordering of the given plan.
	Brute forces all orderings resulting in a valid red-black plan
  recursive approach
*/
vector<const Operator *> reorderNaive(vector<const Operator *> &plan) {
	// ~MJ.
	//take in initialstate applicable actions as first action of the ordering
	//for every this action build an ordering by using the remaining operators
	// always take an action that is applicable by the red-black semantic
	// generate legitimite red-black plan with minimal conflicts
	// bruteforce all possible orderings

	vector<const Operator *> partPlan;
	if (countConflicts(plan) == 0) {
		return plan;
	} else {
		shuffle<>(plan);
		pair<const vector<const Operator *>, int> reordered = reorderRedBlack(
				partPlan, plan, getInitialStateFactsRb());

		return reordered.first;
	}
}


// ~MJ. logic for optimal naive reordering
pair<const vector<const Operator *>, int> reorderRedBlack(
		const vector<const Operator *> &planPart,
		vector<const Operator *> &remainingOps,
		const vector<vector<int> > &stateFacts) {

	int curConflicts = countConflicts(planPart);

	if (remainingOps.size() == 0) {
		//check that planPart reaches the goal!
		if (!test_goal_rb(stateFacts))
			return make_pair(planPart, numeric_limits<int>::max());
		sample_count++;
		return make_pair(planPart, curConflicts);
	}

	// no need to recure if partial plan already worse than original complete plan
	if (curConflicts >= minConflicts) {
		return make_pair(planPart, numeric_limits<int>::max());
	}

	// compute the red-black applicable operators
	for (size_t i = 0; i < remainingOps.size(); i++) {
		const Operator* curOp = remainingOps[i];
		if (isRbApplicable(stateFacts, curOp)) {
			// do recursion and take the plan with minimal conflicts

			//prepare the arguments for recursive call
			vector<const Operator *> newPlanPart = planPart;
			newPlanPart.push_back(curOp);
			vector<const Operator *> newRemainingOps = remainingOps;
			newRemainingOps.erase(newRemainingOps.begin() + i);

			shuffle<>(newRemainingOps);

			// do recursion
			const vector<vector<int> > &succState = applyRbAction(stateFacts,
					curOp);
			pair<vector<const Operator*>, int> planAndConflicts =
					reorderRedBlack(newPlanPart, newRemainingOps, succState);

			//take the minimum
			int currConflicts = planAndConflicts.second;

			if (currConflicts < minConflicts) {
				minPlan = planAndConflicts.first;
				minConflicts = currConflicts;
			}

			//stop search if limit is reached
			if (G_MAX_SAMPLES != -1 && sample_count >= G_MAX_SAMPLES) {
				break;
			}

		}
	}
	//return the best plan with min number of conflicts
	return make_pair(minPlan, minConflicts);
}

vector<const Operator *> sample_random_rb_plan_rec(
		vector<const Operator *> partPlan,
		vector<const Operator *> remainingOps,
		vector<vector<int> > stateFacts) {

	if (remainingOps.size() == 0) {
		//check that planPart reaches the goal!
		if (!test_goal_rb(stateFacts))
			return vector<const Operator *>();
		return partPlan;
	}

	vector<pair <const Operator *, int>> appl_ops;
	for(size_t i = 0; i < remainingOps.size(); i++){
		if (isRbApplicable(stateFacts, remainingOps[i])) {
			appl_ops.push_back(make_pair(remainingOps[i],i));
		}
	}


	// compute the red-black applicable operators
	for (size_t i = 0; i < appl_ops.size(); i++) {
		const Operator* curOp = appl_ops[i].first;
		// do recursion

		//prepare the arguments for recursive call;
		vector <const Operator *> newPartPlan = partPlan;
		newPartPlan.push_back(curOp);
		vector <const Operator *> newRemainingOps = remainingOps;
		newRemainingOps.erase(newRemainingOps.begin() + appl_ops[i].second);
		shuffle<>(newRemainingOps);

		// do recursion
		vector<vector<int> > succState = applyRbAction(stateFacts, curOp);
		vector<const Operator*> plan = sample_random_rb_plan_rec(newPartPlan,
				newRemainingOps, succState);

		if (plan.empty() && curOp->is_black_op()) {
			continue;
		}

		return plan;
	}

	return vector<const Operator *>();
}

vector<const Operator *> sample_random_rb_plan(vector<const Operator *> &operators) {

	vector < vector <int> > initialStateRb = getInitialStateFactsRb();
	vector <const Operator *> min_plan = operators;
	int min_conflicts = countConflicts(min_plan);

	for (int i = 0; i < G_RANDOM_SAMPLES; i++) {
		vector<const Operator *> partPlan;
		shuffle<>(operators);
		vector < const Operator *>  rec_operators = operators;
		vector<const Operator *> random_sample = sample_random_rb_plan_rec(
				partPlan, rec_operators, initialStateRb);

		if(g_timer() >= G_SAMPLING_TIMEOUT){
			break;
		}

		//random sampling failed -> redo
		if(random_sample.empty()){
			G_RANDOM_SAMPLES++;
			continue;
		}

		int cur_conflicts = countConflicts(random_sample);

		if(cur_conflicts <= min_conflicts){
			min_plan = random_sample;
			min_conflicts = cur_conflicts;
		}
	}

	cout << "sampling runs: " << G_RANDOM_SAMPLES << endl;
	return min_plan;
}


//~MJ.
vector<vector<int> > applyRbAction(const vector<vector<int> > &stateFacts,
		const Operator *a) {
	vector<vector<int> > newfacts;
	const vector<Effect> &effects = a->get_effects(); // We only need the effects .
	newfacts.resize(g_variable_name.size());
	// Fetch all facts from the the given state.
	for (size_t i = 0; i < stateFacts.size(); i++) {
		for (size_t j = 0; j < stateFacts[i].size(); j++) {
			newfacts[i].push_back(stateFacts[i][j]);
		}
	}
	// Include the red effects and replace the black facts by the black effects.
	for (size_t i = 0; i < effects.size(); i++) {
		const Effect &curEffect = effects[i];
		int var = curEffect.var;
		int val = curEffect.val;
		// Check whether the variable is black.
		if (g_painting->is_black_var(var)) {
			newfacts[var][0] = val;
		} else {
			bool contained = false;
			for (size_t j = 0; j < newfacts[var].size(); j++) {
				if (newfacts[var][j] == val) {
					contained = true;
					break;
				}
			}
			if (!contained) {
				newfacts[var].push_back(val);
			}
		}
	}
	return newfacts;
}

//~MJ. taken from lazy_search_rb.cc
bool isRbApplicable(const vector<vector<int> > &s, const Operator *a) {
	const vector<Condition> &preconditions = a->get_preconditions();
	// Check whether those preconditions are fulfilled in the given state.
	for (size_t i = 0; i < preconditions.size(); i++) {
		int var = preconditions[i].var;
		int val = preconditions[i].val;
		bool found = false;
		for (size_t j = 0; j < s[var].size(); j++) {
			if (s[var][j] == val) {
				found = true;
				break;
			}
		}
		if (!found) {
			return false;
		}
	}
	return true;
}



/* ~MJ. begin hill climbing reordering
  ###############################################################
*/

/*
  Converts a set of blocks into a sequence of actions
*/
vector < const Operator *> blocksToPlan(vector < vector <const Operator *> > &state){
  vector < const Operator *> plan;
  for(size_t i = 0; i < state.size(); i++){
    for (size_t j = 0; j < state[i].size(); j++){
      plan.push_back(state[i][j]);
    }
  }
  return plan;
}
/*
  Converts a plan into a set of blocks with each block only containing one action
*/
vector < vector < const Operator *> > planToBlocks(vector < const Operator *> &plan){
  vector < vector < const Operator *> > blocks;
  for(size_t i = 0; i < plan.size(); i++){
    vector < const Operator *> block;
    block.push_back(plan[i]);
    blocks.push_back(block);
  }
  return blocks;
}


/*
  Fields used in reorderHillClimbing
*/
int currentConflicts;
vector < vector <const Operator *> > currentState;
vector<vector<vector <const Operator *> > > currentSuccessors;

vector<const Operator *> reorderHillClimbing (const vector<const Operator *> &plan){
  //take plan as initial ordering
  //generate successor states with the two given reordering trategies
  //take reordering with minimal conflicts as next state
  //if minimal ordering not better than current state then stop return current state
  //else loop

  currentConflicts = minConflicts;
  for (size_t i = 0; i < plan.size(); i++) {
    //initialize blocks, every action in one block
    vector< const Operator* > oneBlock;
    oneBlock.push_back(plan[i]);
    currentState.push_back(oneBlock);
  }

  cout << "Starting hill climbing" << endl;
  while (true) {
    //TODO: don't check every single time, but once
    if(g_reordering_version == "v1"){
      generateChildNodeOld(currentState);
    } else {
      generateChildNode(currentState);
    }
    cout << "generated " << currentSuccessors.size() << " child nodes" << endl;

    vector < vector <vector <const Operator  *> > > minSuccessors = vector < vector < vector<const Operator *> > >();
    int minConflicts = numeric_limits<int>::max();
    for (size_t i = 0; i< currentSuccessors.size(); i++) {
      int succConflicts = countConflicts(blocksToPlan(currentSuccessors[i]));
      if( succConflicts < minConflicts){
        minConflicts = succConflicts;
        minSuccessors =  vector < vector < vector<const Operator *> > >();
        minSuccessors.push_back(currentSuccessors[i]);
      } else if ( succConflicts == minConflicts){
          minSuccessors.push_back(currentSuccessors[i]);
      }
    }
    if (minConflicts >= currentConflicts){
      cout << "found local minimum, returning" << endl;
      return blocksToPlan(currentState);
    }
    cout << "minimal successor conflicts: " << minConflicts << endl;
    cout << "number of minimal successors: " << minSuccessors.size() << endl;
    //choose a random minimal successor
    int random = g_rng.next(minSuccessors.size());
    currentState = minSuccessors[random];
    currentConflicts = minConflicts;
  }

}


/*
  determines an action fullfilling the missing preconditions of conflictOp at
  conflictOpOffset in plan
*/
vector < pair < const Operator*, int > > getFullfiller(const vector<const Operator *> &plan, int conflictOpOffset){
  vector< pair < const Operator* , int > > fullfillers;

  //get the unsupported precondition
  vector<int> currentStateFacts = g_initial_state_data;

  #ifdef DEBUGMJHC
  cout << "applying action effects, until offset " << conflictOpOffset << endl;
  #endif

  for (int i = 0; i < conflictOpOffset ; i++) {
    applyRealEffectsOfAction(currentStateFacts,plan[i]);
  }
  #ifdef DEBUGMJHC
  cout << "applied actions, determine unsuppPreconditions" << endl;
  #endif

  vector < pair< int,int > > unsuppPrecond =  unsuppPreconditions(currentStateFacts, plan[conflictOpOffset]);
  assert(unsuppPrecond.size() > 0);
  #ifdef DEBUGMJHC
  cout << "determined " << unsuppPrecond.size() << "unsupported preconditions" << endl;
  cout << "finding the fullfilling actions" << endl;
  #endif

  // find the fullfilling actions
  for (size_t i = 0; i < plan.size(); i++) {
    if(i == (size_t) conflictOpOffset){
      continue;
    }
    const Operator* currentOp = plan[i];
    size_t numfullfilled = 0;
    for(size_t j = 0; j < currentOp->get_effects().size(); j++){
      const Effect &effect = currentOp->get_effects()[j];
      //we do not check the precondition
      int var = effect.var;
      int val = effect.val;

      for (size_t k = 0; k < unsuppPrecond.size(); k++) {
        if(var == unsuppPrecond[k].first && val == unsuppPrecond[k].second){
          numfullfilled++;
        }
      }

      if(numfullfilled == unsuppPrecond.size()){
        fullfillers.push_back(make_pair(currentOp,i));
        #ifdef DEBUGMJHC
        cout << "found " << fullfillers.size() << "fullfiller" << endl;
        #endif
      }
    }


  }
    return fullfillers;
}

void applyRealEffectsOfAction(vector <int> &stateFacts,const Operator* op){
  for (size_t j = 0; j < op->get_effects().size(); ++j) {
      const Effect &effect = op->get_effects()[j];
      stateFacts[effect.var] = effect.val;
  }
}

/*
  convertes plan offset to the according offset in the state (blockNumber,blockAction)
*/
pair < int,int > planOffsetTostateOffset(vector < vector<const Operator *> > &state, int planOffset){
  int counter = 0;
  for(size_t i = 0; i < state.size(); i++){
    for(size_t j = 0; j < state[i].size(); j++){
      if(counter == planOffset){
        return make_pair(i,j);
      }
      counter++;
    }
  }
  assert(0 != 0);
  return make_pair(-1,-1);
}

void generateSupportingActionSuccs(vector < vector<const Operator *> > &state, vector<int> &conflictOpsOffsets){
  /*
  for every action in conflict apply the second strategy:
    take an action fullfilling the precondition of the conflict action and place it before
    the conflict action (promotion)
  */

  for (size_t i = 0; i < conflictOpsOffsets.size(); i++) {


    int conflictOpOffset = conflictOpsOffsets[i];

    pair < int,int > conflictOffsetInState = planOffsetTostateOffset(state,conflictOpOffset);
    #ifdef DEBUGMJHC
    cout << "conflictOffsetInState = " << conflictOffsetInState.first << ", " << conflictOffsetInState.second << endl;
    //TODO: ueberlegen die fullfiller = action oder block die/der den conflict löst ?
    #endif
    //determine the fullfiller
    #ifdef DEBUGMJHC
    cout << "(" << i+1 <<".) conflict getFullfiller run"   <<endl;
    #endif

    vector < pair < const Operator * , int > > fullfillers = getFullfiller(blocksToPlan(state),conflictOpOffset);

    if(fullfillers.size() == 0){
      continue;
    }
    #ifdef GENALL
    for(size_t k = 0; k < fullfillers.size(); k++){
    #endif
      vector < vector < const Operator *> > succ;

      #ifndef GENALL
      pair < int, int> fullfillerOffsetInState = planOffsetTostateOffset(state,fullfillers[fullfillers.size() -1].second);
      #endif
      #ifdef GENALL
      pair < int, int> fullfillerOffsetInState = planOffsetTostateOffset(state,fullfillers[k].second);
      #endif

      //create new reordered plan where fullfiller is directly before conflictOp
      int newConflictBlockOffset = -1;

      //if fullfiller and conflictop are in the same block you cannot reorder them
      if(conflictOffsetInState.first == fullfillerOffsetInState.first){
        continue;
      }

      for(int j = 0; j < (int) state.size(); j++){
        vector < const Operator *> block;

        if(j == fullfillerOffsetInState.first){
          continue;
        }

        if(j == conflictOffsetInState.first){
          newConflictBlockOffset = succ.size();
        }

        for(size_t m = 0; m < state[j].size(); m++){
          block.push_back(state[j][m]);
        }
        succ.push_back(block);

      }

      assert(newConflictBlockOffset != -1);
      for(int j = state[fullfillerOffsetInState.first].size() - 1; j >= 0  ; j--){
        succ[newConflictBlockOffset].insert(succ[newConflictBlockOffset].begin(), state[fullfillerOffsetInState.first][j]);
      }
      currentSuccessors.push_back(succ);

    }
    #ifdef GENALL
    }
    #endif
}


void generateBlockLayerSuccs(vector<vector<const Operator *> > &state,
		vector<int> &conflictOpsOffsets) {

	/*
	 for every action in conflict apply the first strategy (demotion):
	 add the conflict actions into a layer fullfilling all it's preconditions
	 */

	for (size_t i = 0; i < conflictOpsOffsets.size(); i++) {

		int conflictOpOffset = conflictOpsOffsets[i];

		pair<int, int> conflictOffsetInState = planOffsetTostateOffset(state,
				conflictOpOffset);

		//get initiale state
		vector<int> currentStateFacts = g_initial_state_data;

		//  go over every block apply a complete block and find the Layers where conflictOp
		//  can be inserted

		//contains the block offset in which conflictOp needs to be inserted at the end
		//because conflictOp is applicable after this block
		vector<int> supportingLayers;

		for (size_t j = 0; j < state.size(); j++) {
			if (isApplicable(currentStateFacts,
					state[conflictOffsetInState.first][conflictOffsetInState.second])) {
				supportingLayers.push_back(j);
				break;
			}

			for (size_t m = 0; m < state[j].size(); m++) {
				const Operator* currentOp = state[j][m];

				//we cannot consider the effects of the conflictOp itself
				if (j == (size_t) conflictOffsetInState.first
						&& m == (size_t) conflictOffsetInState.second) {
					continue;
				}

				applyRealEffectsOfAction(currentStateFacts, currentOp);
			}

		}

		if (isApplicable(currentStateFacts,
				state[conflictOffsetInState.first][conflictOffsetInState.second])) {
			supportingLayers.push_back(state.size());
		}

		if (supportingLayers.size() == 0) {
			continue;
		}

#ifdef GENALL
		for(size_t k = 0; k < supportingLayers.size(); k++) {
#endif
		vector<vector<const Operator *> > succ;
		//dekrementieren da schleife 0 zurück gibt für "init zustand = supporting layer"
#ifdef GENALL
		int supportingLayer = supportingLayers[k] - 1;
#endif
#ifndef GENALL
		int supportingLayer = supportingLayers[0] - 1;
#endif
		// supportingLayer index may change when conflict block before supportingLayerblock
		int newSupportingLayer = supportingLayer;
		for (size_t j = 0; j < state.size(); j++) {
			vector<const Operator *> block;

			if ((int) j == conflictOffsetInState.first) {
				continue;
			}

			if ((int) j == supportingLayer) {
				newSupportingLayer = succ.size();
			}

			for (size_t m = 0; m < state[j].size(); m++) {
				block.push_back(state[j][m]);
			}
			succ.push_back(block);
		}

		assert(newSupportingLayer != -2);
		//insert the conflict block into the new supporting layer at the end
		if (newSupportingLayer == -1) {
			//in init ist der zustand applicable, also neuen block einfuegen
			succ.insert(succ.begin(), state[conflictOffsetInState.first]);
		} else {
			for (size_t j = 0; j < state[conflictOffsetInState.first].size();
					j++) {
				succ[newSupportingLayer].push_back(
						state[conflictOffsetInState.first][j]);
			}
		}

		currentSuccessors.push_back(succ);
#ifdef GENALL
	}
#endif

	}
}

void generateOldSuppLayerSuccs(const vector<const Operator *> &plan,
		vector<int> conflictOpsOffsets) {

	for (size_t i = 0; i < conflictOpsOffsets.size(); i++) {
		int conflictOpOffset = conflictOpsOffsets[i];

		//get initial state
		vector<int> currentStateFacts = g_initial_state_data;
		//apply plan actions until layer found which supports all preconditions of conflictOp
		// offset of plan in which to insert the conflictAction
		vector<int> supportingLayers;
		for (size_t j = 0; j < plan.size(); j++) {
			const Operator* currentOp = plan[j];
			if (isApplicable(currentStateFacts, plan[conflictOpOffset])) {
				//cout << "supportingLayer = " << j << endl;
				supportingLayers.push_back(j);
			}

			if ((int) j == conflictOpOffset) {
				continue;
			}
			//apply current action/operator
			applyRealEffectsOfAction(currentStateFacts, currentOp);
		}

		if (isApplicable(currentStateFacts, plan[conflictOpOffset])) {
			//cout << "supportingLayer = " << j << endl;
			supportingLayers.push_back(plan.size());
		}

		// only if supporting layer found
		// generate new successors by reordering the conflictOp according to the supportingLayers
		bool lastLayerSupp = false;
		if (supportingLayers.size() == 0) {
			continue;
		}

#ifdef GENALL
		for(size_t k = 0; k < supportingLayers.size(); k++) {
#endif
		vector<const Operator *> succ;
#ifdef GENALL
		int supportingLayer = supportingLayers[k];
#endif
#ifndef GENALL
		int supportingLayer = supportingLayers[0];
#endif
		if (supportingLayer == (int) plan.size()) {
			lastLayerSupp = true;
		}
		for (int j = 0; j < (int) plan.size(); j++) {
			if (j == conflictOpOffset) {
				continue;
			} else if (j == supportingLayer) {
				succ.push_back(plan[conflictOpOffset]);
			}
			succ.push_back(plan[j]);
		}

		if (lastLayerSupp) {
			succ.push_back(plan[conflictOpOffset]);
		}

		//add action into found layer and push_back a new successor
		currentSuccessors.push_back(planToBlocks(succ));
#ifdef GENALL
	}
#endif

	}

}

void generateOldSupportingActionSuccs(const vector < const Operator *> &plan, vector < int > &conflictOpsOffsets){

    /*
    for every action in conflict apply the second strategy:
      take an action fullfilling the precondition of the conflict action and place it before
      the conflict action
    */

    for (size_t i = 0; i < conflictOpsOffsets.size(); i++) {
      vector<const Operator *> succ;
      int conflictOpOffset = conflictOpsOffsets[i];
      //determine the fullfiller
      vector < pair <const Operator *, int > > fullfillers = getFullfiller(plan,conflictOpOffset);

      if(fullfillers.size() == 0){
        continue;
      }

      #ifdef GENALL
      for(size_t k = 0; k < fullfillers.size(); k++){
      #endif


      #ifdef GENALL
      const Operator* fullfiller = fullfillers[k].first;
      #endif
      #ifndef GENALL
      const Operator* fullfiller = fullfillers[0].first;
      #endif
      if(fullfiller == NULL){
        continue;
      }
      //create new reordered plan where fullfiller is directly before conflictOp
      int insertFullfillerOffset = -1;
      for(int j = 0; j < (int) plan.size(); j++){
        if(j == conflictOpOffset){
          succ.push_back(plan[j]);
          insertFullfillerOffset = succ.size() - 1 ;
          succ.push_back(plan[j]);
        } else if (plan[j] == fullfiller) {
          continue;
        } else {
          succ.push_back(plan[j]);
        }
      }
      assert(insertFullfillerOffset != -1);
      succ[insertFullfillerOffset] = fullfiller;

      currentSuccessors.push_back(planToBlocks(succ));

    #ifdef GENALL
    }
    #endif
    }
}



/*
  Generates for the given plan all it's child nodes reordered by the two specified
  reordering strategies
  sets the field currentSuccessors
*/
void generateChildNode(vector < vector< const Operator *> > &plan){
  currentSuccessors = vector < vector<vector <const Operator  *> > >();
  /*
    determine the actions that are in conflict
  */

  vector<int> conflictOpsOffsets = determineConflictOps(blocksToPlan(plan));

  generateBlockLayerSuccs(plan,conflictOpsOffsets);


  generateSupportingActionSuccs(plan, conflictOpsOffsets);

}

void generateChildNodeOld(vector < vector< const Operator *> > &plan){
  currentSuccessors = vector < vector<vector <const Operator  *> > >();
  /*
    determine the actions that are in conflict
  */
  #ifdef DEBUGMJHC
  cout << "###" << endl;
  cout << "before determineconflicts plan size = " << plan.size() << endl;
  cout << "fist action: " << plan[0][0]->get_name() << endl;
  #endif
  vector<int> conflictOpsOffsets = determineConflictOps(blocksToPlan(plan));
  #ifdef DEBUGMJHC
  cout << "determined conflicts (" << conflictOpsOffsets.size() << ")" << endl;
  #endif


  generateOldSuppLayerSuccs(blocksToPlan(plan),conflictOpsOffsets);

  #ifdef DEBUGMJHC
  cout << "currentSuccessors size after 1. technique = " << currentSuccessors.size() << endl;
  #endif

  generateOldSupportingActionSuccs(blocksToPlan(plan),conflictOpsOffsets);

  #ifdef DEBUGMJHC
  cout << "currentSuccessors size after 2. technique = " << currentSuccessors.size() << endl;
  #endif
}

/*
 * Implementation of Fisher-Yates shuffle algorithm, in place.
 */
template<class T>
void shuffle(vector<T> &vector) {
	for (int currentIndexCounter = vector.size() - 1; currentIndexCounter >= 1;
			--currentIndexCounter) {
		uniform_int_distribution<int> distribution(0, currentIndexCounter);
		int randomIndex = distribution(random_generator);
		swap(vector.at(currentIndexCounter), vector.at(randomIndex));

	}

}

bool validate_redblack_plan(const vector < const Operator*> &plan){

	vector < vector <int> > cur_state = getInitialStateFactsRb();
	for(size_t i = 0; i < plan.size(); i++){
		cur_state = applyRbAction(cur_state, plan[i]);
	}
	return test_goal_rb(cur_state);
}

void save_plan(const vector<const Operator *> &plan, int iter) {
	// TODO: Refactor: this is only used by the SearchEngine classes
	//       and hence should maybe be moved into the SearchEngine.

	vector<const Operator *> editable_plan = plan;
	int conflicts_before = countConflicts(plan);

	//run optimal or hill_climbing reordering
	if (g_reordering) {
		minConflicts = conflicts_before;
		minPlan = plan;
		cout << "--------------------" << endl;
		cout << "reordering started [" << g_timer << "]" << endl;
		g_timer.resume();
		if (g_reordering_technique == "optimal") {
			cout << "optimal reordering started" << endl;
			editable_plan = reorderNaive(editable_plan);
		} else if (g_reordering_technique == "hill_climbing") {
			editable_plan = reorderHillClimbing(editable_plan);
		} else {
			cout << g_reordering_technique << "is no valid reordering technique"
					<< endl;
			cout << "no reordering performed" << endl;
		}
		cout << "reordering finished [" << g_timer << "]" << endl;
		g_timer.stop();

	}

	ofstream outfile;
	if (iter == 0) {
		outfile.open(g_plan_filename.c_str(), ios::out);
	} else {
		ostringstream out;
		out << g_plan_filename << "." << iter;
		outfile.open(out.str().c_str(), ios::out);
	}
	if (g_reordering || g_random_reorder)
		cout << "Reordered Plan:" << endl;

	locale loc;
	for (size_t i = 0; i < editable_plan.size(); ++i) {
		cout << editable_plan[i]->get_name() << " ("
				<< editable_plan[i]->get_cost() << ")" << endl;

		//reudig!
		string s = editable_plan[i]->get_name();
		while (isspace(s[s.size() - 1], loc)) {
			s.erase(s.end() - 1);
		}

		outfile << "(" << s << ")" << endl;
	}
	int plan_cost = calculate_plan_cost(plan);
	outfile << "; cost = " << plan_cost << " ("
			<< (is_unit_cost() ? "unit-cost" : "general-cost") << ")" << endl;
	outfile.close();

	if (g_use_redblack_search) {
		cout << "Is valid redblack plan: "
				<< validate_redblack_plan(editable_plan) << endl;
	}
	cout << "Plan length: " << plan.size() << " step(s)." << endl;
	cout << "Plan cost: " << plan_cost << endl;

	if ((g_reordering || g_random_reorder) && !g_rb_plan_sampling) {
		cout << "Conflicts before reordering: " << conflicts_before << endl;
		cout << "Conflicts after reordering: " << countConflicts(editable_plan) << endl;
		if (g_reordering_technique == "optimal") {
			cout << "Reorderings computed: " << sample_count << endl;
			if (G_MAX_SAMPLES != -1 && sample_count >= G_MAX_SAMPLES)
				cout << "Reordering limit was reached!" << endl;

		}
	}
	if(g_rb_plan_sampling){
		cout << "Conflicts before reordering: " << g_conflicts << endl;
		cout << "Conflicts after reordering: " << countConflicts(editable_plan) << endl;
		if (g_timer() < G_SAMPLING_TIMEOUT)
			cout << "Sampling end time: " << g_timer << endl;
		else
			cout << "Reached timeout: " << g_timer << endl;
	}
}

bool peek_magic(istream &in, string magic) {
    string word;
    in >> word;
    bool result = (word == magic);
    for (int i = word.size() - 1; i >= 0; --i)
        in.putback(word[i]);
    return result;
}

void check_magic(istream &in, string magic) {
    string word;
    in >> word;
    if (word != magic) {
        cout << "Failed to match magic word '" << magic << "'." << endl;
        cout << "Got '" << word << "'." << endl;
        if (magic == "begin_version") {
            cerr << "Possible cause: you are running the planner "
                 << "on a preprocessor file from " << endl
                 << "an older version." << endl;
        }
        exit_with(EXIT_INPUT_ERROR);
    }
}

void read_and_verify_version(istream &in) {
    int version;
    check_magic(in, "begin_version");
    in >> version;
    check_magic(in, "end_version");
    if (version != PRE_FILE_VERSION) {
        cerr << "Expected preprocessor file version " << PRE_FILE_VERSION
             << ", got " << version << "." << endl;
        cerr << "Exiting." << endl;
        exit_with(EXIT_INPUT_ERROR);
    }
}

void read_metric(istream &in) {
    check_magic(in, "begin_metric");
    in >> g_use_metric;
    check_magic(in, "end_metric");
}

void read_variables(istream &in) {
    int count;
    in >> count;
    for (int i = 0; i < count; ++i) {
        check_magic(in, "begin_variable");
        string name;
        in >> name;
        g_variable_name.push_back(name);
        int layer;
        in >> layer;
        g_axiom_layers.push_back(layer);
        int range;
        in >> range;
        g_variable_domain.push_back(range);
        in >> ws;
        vector<string> fact_names(range);
        for (size_t j = 0; j < fact_names.size(); ++j)
            getline(in, fact_names[j]);
        g_fact_names.push_back(fact_names);
        check_magic(in, "end_variable");
    }
}

void read_mutexes(istream &in) {
    g_inconsistent_facts.resize(g_variable_domain.size());
    for (size_t i = 0; i < g_variable_domain.size(); ++i)
        g_inconsistent_facts[i].resize(g_variable_domain[i]);

    int num_mutex_groups;
    in >> num_mutex_groups;

    /* NOTE: Mutex groups can overlap, in which case the same mutex
       should not be represented multiple times. The current
       representation takes care of that automatically by using sets.
       If we ever change this representation, this is something to be
       aware of. */

    for (int i = 0; i < num_mutex_groups; ++i) {
        check_magic(in, "begin_mutex_group");
        int num_facts;
        in >> num_facts;
        vector<pair<int, int> > invariant_group;
        invariant_group.reserve(num_facts);
        for (int j = 0; j < num_facts; ++j) {
            int var, val;
            in >> var >> val;
            invariant_group.push_back(make_pair(var, val));
        }
        check_magic(in, "end_mutex_group");
        for (size_t j = 0; j < invariant_group.size(); ++j) {
            const pair<int, int> &fact1 = invariant_group[j];
            int var1 = fact1.first, val1 = fact1.second;
            for (size_t k = 0; k < invariant_group.size(); ++k) {
                const pair<int, int> &fact2 = invariant_group[k];
                int var2 = fact2.first;
                if (var1 != var2) {
                    /* The "different variable" test makes sure we
                       don't mark a fact as mutex with itself
                       (important for correctness) and don't include
                       redundant mutexes (important to conserve
                       memory). Note that the preprocessor removes
                       mutex groups that contain *only* redundant
                       mutexes, but it can of course generate mutex
                       groups which lead to *some* redundant mutexes,
                       where some but not all facts talk about the
                       same variable. */
                    g_inconsistent_facts[var1][val1].insert(fact2);
                }
            }
        }
    }
}

void read_goal(istream &in) {
    check_magic(in, "begin_goal");
    int count;
    in >> count;
    if (count < 1) {
        cerr << "Task has no goal condition!" << endl;
        exit_with(EXIT_INPUT_ERROR);
    }
    for (int i = 0; i < count; ++i) {
        int var, val;
        in >> var >> val;
        g_goal.push_back(make_pair(var, val));
    }
    check_magic(in, "end_goal");
}

void dump_goal() {
    cout << "Goal Conditions:" << endl;
    for (size_t i = 0; i < g_goal.size(); ++i)
        cout << "  " << g_variable_name[g_goal[i].first] << ": "
             << g_goal[i].second << endl;
}

void read_operators(istream &in) {
    int count;
    in >> count;
    for (int i = 0; i < count; ++i)
        g_operators.push_back(Operator(in, false));
}

void read_axioms(istream &in) {
    int count;
    in >> count;
    for (int i = 0; i < count; ++i)
        g_axioms.push_back(Operator(in, true));

    g_axiom_evaluator = new AxiomEvaluator;
}

void read_everything(istream &in) {
    cout << "reading input... [t=" << g_timer << "]" << endl;
    read_and_verify_version(in);
    read_metric(in);
    read_variables(in);
    read_mutexes(in);
    g_initial_state_data.resize(g_variable_domain.size());
    check_magic(in, "begin_state");
    for (size_t i = 0; i < g_variable_domain.size(); ++i) {
        in >> g_initial_state_data[i];
    }
    check_magic(in, "end_state");
    g_default_axiom_values = g_initial_state_data;

    read_goal(in);
    read_operators(in);
    read_axioms(in);
    check_magic(in, "begin_SG");
    g_successor_generator = read_successor_generator(in);
    check_magic(in, "end_SG");
    DomainTransitionGraph::read_all(in);
    check_magic(in, "begin_CG"); // ignore everything from here

    cout << "done reading input! [t=" << g_timer << "]" << endl;

    // NOTE: causal graph is computed from the problem specification,
    // so must be built after the problem has been read in.

    cout << "building causal graph..." << flush;
    g_causal_graph = new CausalGraph;
    cout << "done! [t=" << g_timer << "]" << endl;


    if (g_use_redblack_search){
        verify_no_axioms_no_conditional_effects();

        g_painting->do_painting();
    }

    assert(!g_variable_domain.empty());

    g_state_packer = new IntPacker(g_variable_domain);

    cout << "Variables: " << g_variable_domain.size() << endl;
    cout << "Bytes per state: "
         << g_state_packer->get_num_bins() *
            g_state_packer->get_bin_size_in_bytes() << endl;

    cout << "done! [t=" << g_timer << "]" << endl;

    // NOTE: state registry stores the sizes of the state, so must be
    // built after the problem has been read in.
    g_state_registry = new StateRegistry;

    cout << "done initalizing global data [t=" << g_timer << "]" << endl;
}

void dump_everything() {
    cout << "Use metric? " << g_use_metric << endl;
    cout << "Min Action Cost: " << g_min_action_cost << endl;
    cout << "Max Action Cost: " << g_max_action_cost << endl;
    // TODO: Dump the actual fact names.
    cout << "Variables (" << g_variable_name.size() << "):" << endl;
    for (size_t i = 0; i < g_variable_name.size(); ++i)
        cout << "  " << g_variable_name[i]
             << " (range " << g_variable_domain[i] << ")" << endl;
    State initial_state = g_initial_state();
    cout << "Initial State (PDDL):" << endl;
    initial_state.dump_pddl();
    cout << "Initial State (FDR):" << endl;
    initial_state.dump_fdr();
    dump_goal();
    /*
    cout << "Successor Generator:" << endl;
    g_successor_generator->dump();
    for(int i = 0; i < g_variable_domain.size(); ++i)
      g_transition_graphs[i]->dump();
    */
}

bool is_unit_cost() {
    return g_min_action_cost == 1 && g_max_action_cost == 1;
}

bool has_axioms() {
    return !g_axioms.empty();
}

void verify_no_axioms() {
    if (has_axioms()) {
        cerr << "Heuristic does not support axioms!" << endl << "Terminating."
             << endl;
        exit_with(EXIT_UNSUPPORTED);
    }
}

static int get_first_conditional_effects_op_id() {
    for (size_t i = 0; i < g_operators.size(); ++i) {
        const vector<Effect> &effects = g_operators[i].get_effects();
        for (size_t j = 0; j < effects.size(); ++j) {
            const vector<Condition> &cond = effects[j].conditions;
            if (!cond.empty())
                return i;
        }
    }
    return -1;
}

bool has_conditional_effects() {
    return get_first_conditional_effects_op_id() != -1;
}

void verify_no_conditional_effects() {
    int op_id = get_first_conditional_effects_op_id();
    if (op_id != -1) {
        cerr << "Heuristic does not support conditional effects "
             << "(operator " << g_operators[op_id].get_name() << ")" << endl
             << "Terminating." << endl;
        exit_with(EXIT_UNSUPPORTED);
    }
}

void verify_no_axioms_no_conditional_effects() {
    verify_no_axioms();
    verify_no_conditional_effects();
}

bool are_mutex(const pair<int, int> &a, const pair<int, int> &b) {
    if (a.first == b.first) // same variable: mutex iff different value
        return a.second != b.second;
    return bool(g_inconsistent_facts[a.first][a.second].count(b));
}

const State &g_initial_state() {
    return g_state_registry->get_initial_state();
}

bool g_use_metric;
int g_min_action_cost = numeric_limits<int>::max();
int g_max_action_cost = 0;

Painting *g_painting;
bool g_use_redblack_search;

//~MJ for reordering of plan
bool g_rb_plan_sampling = false;
bool g_random_reorder;
bool g_reordering = false; // ~MJ.
string g_reordering_technique = "none"; // ~MJ.
string g_reordering_version = "v2";
int G_MAX_SAMPLES = -1;
int G_RANDOM_SAMPLES = 10;
int G_SAMPLING_TIMEOUT = 900;
string g_input_plan_name;
int g_conflicts;


vector<string> g_variable_name;
vector<int> g_variable_domain;

vector<vector<string> > g_fact_names;
vector<int> g_axiom_layers;
vector<int> g_default_axiom_values;
IntPacker *g_state_packer;

vector<int> g_initial_state_data;

vector<pair<int, int> > g_goal;

vector<Operator> g_operators;
vector<Operator> g_axioms;
AxiomEvaluator *g_axiom_evaluator;
SuccessorGenerator *g_successor_generator;
vector<DomainTransitionGraph *> g_transition_graphs;
CausalGraph *g_causal_graph;

Timer g_timer;
string g_plan_filename = "sas_plan";
RandomNumberGenerator g_rng(2011); // Use an arbitrary default seed.
StateRegistry *g_state_registry = 0;
