#include "painting.h" 

#include "causal_graph.h"
#include "globals.h"
#include "operator.h"
#include "option_parser.h"
#include "plugin.h"
#include "../preprocess/scc.h"
#include "successor_generator.h"
#include "timer.h"
#include "utilities.h"
#include "rng.h"

#include <ctime>
#include <fstream>
#include <iostream>
#include <limits>
#include <map>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <sstream>
#include <time.h>
#include <algorithm>
#include <functional>

using namespace std;



Painting::Painting(const Options &) {
}

class CGTopFirstPainting : public Painting {
    
    int number_black_vars;
    
    int ratio_black;
    
    bool force_cg_leaves_red;
    
public:
    
    CGTopFirstPainting(const Options &opts)
            : Painting(opts) {
        force_cg_leaves_red = opts.get<bool>("force_cg_leaves_red");
        if (force_cg_leaves_red){
            cout << "causal graph leaf variables will always be painted red" << endl;
        }
        ratio_black = opts.get<int>("ratio_black");
        cout << "painting CG root variables black first" << endl;
        if (opts.contains("number_black_vars")){
            number_black_vars = opts.get<int>("number_black_vars");
            cout << "painting " << number_black_vars << " variables black" << endl;
        } else {
            number_black_vars = -1;
            cout << "painting " << ratio_black << "% of the variables black" << endl;
        }
    };
    
    virtual vector<bool> get_painting();
    
    static void add_options_to_parser(OptionParser &parser);
    
};


class CGBranchFirstPainting : public Painting {

    int number_black_vars;

    int ratio_black;

    bool force_cg_leaves_red;

    vector<bool> scc_painted;
    vector<int> scc_offset_to_level;


    bool paint_dfs_sccs(int cur_scc_offset, int starting_var_of_scc ,vector< set<int> > sccs,
    		vector<bool> &painting, int &already_black);

    bool paint_succ_rec(int cur_node, vector<bool> &painting, int &already_black,
    		set<int> &scc);

    bool compare_scc_level(int scc_offset1, int scc_offset2);


public:

    CGBranchFirstPainting(const Options &opts)
            : Painting(opts) {
        force_cg_leaves_red = opts.get<bool>("force_cg_leaves_red");
        if (force_cg_leaves_red){
            cout << "causal graph leaf variables will always be painted red" << endl;
        }
        ratio_black = opts.get<int>("ratio_black");
        cout << "painting CG branch variables black first" << endl;
        if (opts.contains("number_black_vars")){
            number_black_vars = opts.get<int>("number_black_vars");
            cout << "painting " << number_black_vars << " variables black" << endl;
        } else {
            number_black_vars = -1;
            cout << "painting " << ratio_black << "% of the variables black" << endl;
        }

    };

    virtual vector<bool> get_painting();

    static void add_options_to_parser(OptionParser &parser);

};

class IPCFirst : public Painting {
        
public:
    
    IPCFirst(const Options &opts)
            : Painting(opts) {

        ofstream new_file("last_painting");

        if(new_file.is_open()){
            new_file << "";
            new_file.close();
        }

    };
    
    virtual vector<bool> get_painting();
    
};

class IPCNext : public Painting {
     
public:
    
    IPCNext(const Options &opts)
            : Painting(opts) {
        
    };
    
    virtual vector<bool> get_painting();
    
};

void Painting::apply_painting() {
    for (auto &op : g_operators){
        op.do_paint();
    }
}

void Painting::print_painting() const {
    for (size_t var = 0; var < g_variable_domain.size(); ++var){
        cout << g_fact_names[var][0] << " was painted " << (is_red_variable[var] ? "red" : "black") << endl;
    }
}

void Painting::exit_error(string message, int exit_code) const {
    cout << "Error while painting planning task!" << endl;
    cout << message << endl;
    exit(exit_code);
}

void Painting::do_painting() {

    // for calculating the painting time
    Timer t;
    
    cout << "started painting" << endl;
    is_red_variable = get_painting();
    
    cout << "painting time " << t << endl;
    
    if (g_use_redblack_search){
        apply_painting();    
        
        print_painting();
    }
}

vector<bool> CGTopFirstPainting::get_painting() {    ///////////////////////////  start painting CG root variables black
   vector<bool> painting(g_variable_domain.size(), true);
   
   int number_black = number_black_vars;
   if (number_black_vars == -1){        // not set by command line
       number_black = floor(g_variable_domain.size() * ratio_black / 100);
   }
   
   if (number_black == (int) g_variable_domain.size()){
        g_use_redblack_search = false;
        return painting;
   }
   
   for (int i = 0; i < min(number_black, (int) g_variable_domain.size()); ++i){
       if (!force_cg_leaves_red || !g_causal_graph->get_successors(i).empty()){
           painting[i] = false;
       } else {
            ++number_black;
       }
   }

   return painting;
}

vector<bool> IPCFirst::get_painting() {
    return vector<bool>(g_variable_domain.size(), true);
}

inline void randomly_paint_scc(vector<bool> &is_red_var, const vector<int> &scc, size_t number_black) {
    if (number_black == scc.size()){
        for (const auto &var : scc){
//             cout << "painted " << g_fact_names[var][0] << " black" << endl;
            is_red_var[var] = false;
        }
    } else {
        g_rng.seed(static_cast<int>(time(0)));
        
        size_t painted_black = 0;
        bool prefer = true;
        while (painted_black < number_black){
            
            int var;
            if (prefer){
                var = scc[g_rng.next(scc.size() / 2)];
            } else {
                var = scc[g_rng.next(scc.size())];
            }
            
            prefer = !prefer;
            
            if (is_red_var[var]){
//                 cout << "painted " << g_fact_names[var][0] << " black" << endl;
                is_red_var[var] = false;       
                ++painted_black;
            }
        }
    }
}

inline void write_black_vars_to_file(const vector<bool> &is_red_var) {
    ofstream out_file("last_painting");

    if(out_file.is_open()){
        for (size_t var = 0; var < g_variable_domain.size(); ++var){
            if (!is_red_var[var]){
                out_file << var << "\n";
            }
        }
        out_file.close();
    }
}

vector<bool> IPCNext::get_painting() {
    
    vector<bool> is_red_var(g_variable_domain.size(), true);
    size_t num_black = 0;
            
    string line;
    ifstream in_file ("last_painting");
    if (in_file.is_open()){
        
        while (getline(in_file,line)){
            if (line != ""){
                int index;                    

                stringstream convert(line);
                
                if (convert >> index){
                    cout << "variable already black last time: " << index << endl;
//                     is_red_var[index] = false;
                    ++num_black;
                }
                
            }
        }
        
        in_file.close();
    }
    
    if (num_black + 1 == g_variable_domain.size()){
        write_black_vars_to_file(vector<bool>(g_variable_domain.size(), false));
        return vector<bool>(g_variable_domain.size(), false);
    }
    
    vector<set<int> > sccs = get_sccs();
    if (sccs.size() == 1){
        cout << "CG is strongly connected" << endl;
        is_red_var = vector<bool>(g_variable_domain.size(), true);
        randomly_paint_scc(is_red_var, vector<int>(sccs[0].begin(),sccs[0].end()), num_black + 1);
    } else {
       
        // detect SCC lvls

        vector<vector<set<int> > > sccs_per_level(1);
        
        set<set<int> > root_sccs;
        
        for (const auto &scc : sccs){
            bool all_contained = true;
            for (const int var : scc){
                const vector<int> &predecessors = g_causal_graph->get_predecessors(var);
                for (const int succ : predecessors){
                    if (find(scc.begin(), scc.end(), succ) == scc.end()){
                        all_contained = false;
                        break;
                    }
                }
                if (!all_contained){
                    break;
                }
            }
            if (all_contained){
                sccs_per_level[0].push_back(scc);
                root_sccs.insert(scc);
            }
        }
        
        if (sccs.size() > 3 && num_black == 0){
            // if there are "many" SCCs, just paint one root SCC completely black in the first iteration of the search
            
            is_red_var = vector<bool>(g_variable_domain.size(), true);
            
            randomly_paint_scc(is_red_var, vector<int>(sccs_per_level[0][0].begin(), sccs_per_level[0][0].end()), sccs_per_level[0][0].size());
            
            write_black_vars_to_file(is_red_var);
            return is_red_var;
        }
        
        for (size_t i = 0; i < sccs.size(); ++i){
            if (root_sccs.find(sccs[i]) != root_sccs.end()){
                continue;
            }
            bool got_lvl = false;
            for (const int var : sccs[i]){
                for (int lvl = sccs_per_level.size() - 1; lvl >= 0; --lvl){
                    for (const auto &scc : sccs_per_level[lvl]){
                        for (const int ref : scc){
                            const vector<int> &successors = g_causal_graph->get_successors(ref);
                            if (find(successors.begin(), successors.end(), var) != successors.end()){
                                size_t new_lvl = lvl + 1;
                                if (new_lvl >= sccs_per_level.size()){
                                    sccs_per_level.resize(new_lvl + 1);
                                }
                                sccs_per_level[new_lvl].push_back(sccs[i]);
                                got_lvl = true;
                                break;
                            }
                        }
                        if (got_lvl){
                            break;
                        }
                    }
                    if (got_lvl){
                        break;
                    }
                }
                if (got_lvl){
                    break;
                }
            }
        }
        
        // do actual painting
        
        is_red_var = vector<bool>(g_variable_domain.size(), true);
        
        size_t left_to_paint_black = num_black + 1;
        size_t curr_lvl = 0;
        while (left_to_paint_black > 0){
        
            size_t per_scc = ceil((float) left_to_paint_black / (float) sccs_per_level[curr_lvl].size());
            
            size_t left = 0;
            
            for (const auto &scc : sccs_per_level[curr_lvl]){
                size_t max_fit = scc.size();
                
                randomly_paint_scc(is_red_var, vector<int>(scc.begin(), scc.end()), min(left + per_scc, max_fit));
                left_to_paint_black -= min(left_to_paint_black, min(left + per_scc, max_fit));
                
                if (max_fit > per_scc){
                    if (left > 0){
                        left = max(0, (int) left - (int) (max_fit - per_scc));
                    }
                } else {
                    left += per_scc - max_fit;
                }
            }
        
            if (left > 0 && left_to_paint_black > 0){
                // if something left, check if there exists an SCC at curr_lvl that is not completely black
                for (const auto &scc : sccs_per_level[curr_lvl]){
                    for (const int var : scc){
                        // not very efficient, but who cares..
                        if (is_red_var[var]){
                            is_red_var[var] = false;
                            --left_to_paint_black;
                            --left;
                            if (left == 0 || left_to_paint_black == 0){
                                break;
                            }
                        }
                    }
                    if (left == 0 || left_to_paint_black == 0){
                        break;
                    }
                }
            }
        
            ++curr_lvl;
        }
        
        
    }   

    write_black_vars_to_file(is_red_var);
    return is_red_var;
}

vector<bool> CGBranchFirstPainting::get_painting() { ///////////////////////////  start painting CG branch variables black
	vector<bool> painting(g_variable_domain.size(), true);

	if (number_black_vars == -1) {        // not set by command line
		number_black_vars = floor(g_variable_domain.size() * ratio_black / 100);
	}

	if (number_black_vars == (int) g_variable_domain.size()) {
		g_use_redblack_search = false;
		return painting;
	}
	vector<int> all_vars(g_variable_domain.size());
	for (size_t i = 0; i < g_variable_domain.size(); i++) {
		all_vars.at(i) = i;
	}
	vector<set<int> > ccs = get_connected_components(all_vars);
	cout << "connected compontents size: " << ccs.size() << endl;
	bool limit_reached = false;
	for (size_t i = 0; i < ccs.size(); i++) {
		//paint one connected component at a time

		//find the strongly connected components
		vector<int> component(ccs[i].begin(), ccs[i].end());
		vector<set<int> > sccs = get_sccs(component);

		//init arrays
		scc_painted = vector<bool>(sccs.size(),false);
		scc_offset_to_level = vector<int>(sccs.size(),-1);

		cout << "strongly cc size: " << sccs.size() << endl;

		//find the sccs that are a sources of the sccs graph
		//for every scc go through all nodes in the scc and find the scc which's nodes have no incoming edges from other sccs
		vector<int> source_sccs_offsets;
		for (size_t j = 0; j < sccs.size(); j++) {
			bool is_source = true;
			for (set<int>::iterator it = sccs[j].begin(); it != sccs[j].end();
					++it) {
				int var = *it;
				//check whether the predecessors are inside the current scc
				for (size_t k = 0; k < g_causal_graph->get_predecessors(var).size(); k++) {
					int pred = g_causal_graph->get_predecessors(var)[k];
					if(sccs[j].find(pred) == sccs[j].end()){
						is_source = false;
						break;
					}
				}
				if(!is_source)
					break;


			}
			if (is_source){
				source_sccs_offsets.push_back(j);
				scc_offset_to_level[j] = 0;
			}

		}
		cout << "sources size: " << source_sccs_offsets.size() << endl;

		int already_black = 0;
		//paint the strongly connected components black starting from sources
		for(size_t j = 0; j < source_sccs_offsets.size(); j++){
			if(paint_dfs_sccs(source_sccs_offsets[j], *sccs[source_sccs_offsets[j]].begin() , sccs, painting, already_black)){
				limit_reached = true;
				break;
			}
			cout << "one source completely painted" << endl;
		}

		if(limit_reached)
			break;

	}

	return painting;
}

bool CGBranchFirstPainting::compare_scc_level(int scc_offset1, int scc_offset2) {
	return (scc_offset_to_level[scc_offset1] > scc_offset_to_level[scc_offset2]);
}

bool CGBranchFirstPainting::paint_dfs_sccs(int cur_scc_offset, int starting_var_of_scc ,vector< set<int> > sccs,
		vector<bool> &painting, int &already_black) {

	set<int> cur_scc = sccs[cur_scc_offset];
	//paint the current scc
	if (paint_succ_rec(starting_var_of_scc, painting, already_black, cur_scc)) {
		cout << "painting scc limit reached" << endl;
		return true;
	} else {
		scc_painted[cur_scc_offset] = true;
		cout << "painting scc completed" << endl;

	}

	//compute successors of cur_scc
	vector <int> succ_outside_scc;
	for (set<int>::iterator it = cur_scc.begin(); it != cur_scc.end(); ++it) {
		int var = *it;
		for (size_t i = 0; i < g_causal_graph->get_successors(var).size(); i++) {
			int successor = g_causal_graph->get_successors(var)[i];
			if (cur_scc.find(successor) == cur_scc.end()) {
				//the successor is inside another scc
				succ_outside_scc.push_back(successor);
			}
		}
	}
	set<int> offsets_for_scc_succs_of_cur_scc;
	vector<int> map_scc_to_starting_var(sccs.size(), -1);
	for(size_t i = 0; i < succ_outside_scc.size(); i ++){
		for(size_t j = 0; j < sccs.size(); j++){
			if(sccs[j].find(succ_outside_scc[i]) != sccs[j].end()){
				//the scc containing [i] is [j]
				offsets_for_scc_succs_of_cur_scc.insert(j);

				if(scc_offset_to_level[j] == -1)
					scc_offset_to_level[j] = scc_offset_to_level[cur_scc_offset] + 1;

				if(map_scc_to_starting_var[j] == -1)
					map_scc_to_starting_var[j] = succ_outside_scc[i];

			}
		}
	}
	//cout << "successors of current scc: "<< offsets_for_scc_succs_of_cur_scc.size() << endl;

	using namespace std::placeholders;
	auto bound_comparator = std::bind(&CGBranchFirstPainting::compare_scc_level, this, _1, _2);

	vector<int> offsets_for_scc_succs_as_array (offsets_for_scc_succs_of_cur_scc.begin(),offsets_for_scc_succs_of_cur_scc.end());
	std::sort(offsets_for_scc_succs_as_array.begin(), offsets_for_scc_succs_as_array.end(), bound_comparator);

	//paint the successor sccs
	int limit_reached = false;
	for (size_t i = 0; i < offsets_for_scc_succs_as_array.size(); i++) {
		int scc_offset = offsets_for_scc_succs_as_array[i];
		if (!scc_painted[scc_offset]) {
			if (paint_dfs_sccs(scc_offset, map_scc_to_starting_var[scc_offset] ,sccs, painting, already_black)) {
				limit_reached = true;
				break;
			}
		}
	}

	return limit_reached;

}


bool CGBranchFirstPainting::paint_succ_rec(int cur_node, vector<bool> &painting, int &already_black,
		set<int> &scc) {
	//cout << "remaining_black: " << already_black << endl;
	if (already_black >= min(number_black_vars, (int) g_variable_domain.size())) {
		return true;
	}
	if (!(g_causal_graph->get_successors(cur_node).empty() && force_cg_leaves_red)) {
		painting[cur_node] = false;
		already_black++;

	} else {
		//cout << "leave_red var" << endl;
		number_black_vars++;
	}
	int limit_reached = false;
	for (size_t i = 0; i < g_causal_graph->get_successors(cur_node).size(); i++) {
		int successor = g_causal_graph->get_successors(cur_node)[i];
		if (painting[successor] && (scc.find(successor) != scc.end())) {
			//cout << "recuring to child var inside cur scc" << endl;
			if (paint_succ_rec(successor, painting, already_black, scc)) {
				limit_reached = true;
				break;
			}
		}
	}
	return limit_reached;
}

// vector<bool> ForkFactoring::get_painting() { ////////////////////////////////  (INVERTED) FORK
 /*   
    FactoredVars factoring;
    if (maximize_mobility){
        factoring = get_fork_maximize_mobility(vector<int>(), inverted);
    } else {
        factoring = get_fork_maximize_leaves(vector<int>(), inverted);
    }

    if (factoring.size() < min_number_leaves){
        return FactoredVars();
    }

    return factoring;*/
//     return vector<bool>();
// }

// vector<bool> IncidentArcsFactoring::get_painting() {  ///////////////////// INCIDENT ARCS
      
    // all variables sorted descendingly by number of incident arcs
//     vector<vector<int> > variables;
//     
//     for (size_t var = 0; var < g_variable_domain.size(); ++var){
//         size_t arcs = g_causal_graph->get_successors(var).size();
//         arcs += g_causal_graph->get_predecessors(var).size();
//         if (arcs >= variables.size()){
//             variables.resize(arcs + 1);
//         }
//         variables[arcs].push_back(var);
//     }
//     
//     FactoredVars best_factoring;
//     int best_number_leaves = 0;
//     
//     vector<bool> discarded_leaves;
//     
//     set<int> leaf_vars;
//     for (size_t var = 0; var < g_variable_domain.size(); ++var){
//         leaf_vars.insert(var);
//     }
//     
//     for (int arcs = variables.size() -1 ; arcs >= 0; --arcs){
//         for (size_t cand = 0; cand < variables[arcs].size(); cand++){
//             //center.push_back(variables[arcs][cand]);
//             
//             leaf_vars.erase(variables[arcs][cand]);            
//             
//             FactoredVars factoring = get_connected_components(vector<int>(leaf_vars.begin(), leaf_vars.end()));
//             
//             vector<bool> discard_leaf = get_frozen_leaves(factoring);
//             
//             int number_leaves = factoring.size();
//             for (size_t i = 0; i < factoring.size(); ++i){
//                 if (discard_leaf[i]){
//                     number_leaves--;
//                     continue;
//                 }
//                 uint64_t size = 1;
//                 for (set<int>::iterator it = factoring[i].begin(); it != factoring[i].end(); ++it){
//                     size *= g_variable_domain[*it];
//                     if (max_leaf_size != 0 && size > max_leaf_size){
//                         break;
//                     }
//                 }
//                 if (max_leaf_size != 0 && size > max_leaf_size){
//                     --number_leaves;
//                     discard_leaf[i] = true;
//                 }
//             }
//             
//             if (number_leaves >= best_number_leaves){
//                 best_factoring = factoring;
//                 discarded_leaves = discard_leaf;
//                 best_number_leaves = number_leaves;
//             }
//         }
//     }
//     
//     bool change = true;         // put frozen leaves back to center
//     int ind = best_factoring.size();
//     while (change){
//         change = false;
//         for (int i = ind - 1; i >= 0; --i){
//             if (discarded_leaves[i]){
//                 best_factoring.erase(best_factoring.begin() + i);
//                 
//                 change = true;
//                 ind = i;
//                 break;
//             }
//         }
//     }
//     
//     if (best_factoring.size() < min_number_leaves){
//         return FactoredVars();
//     }
//     
// #ifdef DEBUG_PAINTING
//     cout << endl;                      // output factoring
//     for (size_t l = 0; l < best_factoring.size(); ++l){
//         cout << "leaf factor " << l << ":" << endl;
//         for (set<int>::iterator it = best_factoring[l].begin(); it != best_factoring[l].end(); ++it){
//             cout << "   " << g_fact_names[*it][0] << endl;
//         }        
//     }
//     cout << endl;
// #endif
//     
//     return best_factoring;
//     return vector<bool>();
// }

// Painting::FactoredVars Painting::get_fork_maximize_leaves(vector<int> used_vars, bool inverted) const {             ///////////////////////// HELPER FUNCTIONS
    /*
    FactoredVars sccs = get_sccs(used_vars);
    
    FactoredVars best_factoring;

    if (sccs.size() == 1){
#ifdef DEBUG_PAINTING
        cout << "CG is a single SCC" << endl;
#endif
        return best_factoring;
    }
    
    for (size_t i = 0; i < sccs.size(); ++i){
        uint64_t current_size = 1;
        bool is_leaf = true;
        
        for (set<int>::iterator it = sccs[i].begin(); it != sccs[i].end(); ++it){
            int var = *it;
            if (current_size <= max_leaf_size){
                current_size *= g_variable_domain[var];
            }

            size_t bound = g_causal_graph->get_successors(var).size();
            if (inverted){
                bound = g_causal_graph->get_predecessors(var).size();
            }
            for (size_t succ = 0; succ < bound; ++succ){
                int succ_pred;
                if (inverted){
                    succ_pred = g_causal_graph->get_predecessors(var)[succ];
                } else {
                    succ_pred = g_causal_graph->get_successors(var)[succ];
                }

                if (used_vars.empty() || used_vars.size() == g_variable_domain.size() 
                    || find(used_vars.begin(), used_vars.end(), succ_pred) != used_vars.end()){
                    if (sccs[i].find(succ_pred) == sccs[i].end()){
                        // SCC has successor/predecessor SCC
                        is_leaf = false;
                    }
                }
            }
        }

#ifdef DEBUG_PAINTING
        cout << "=========      SCC with " << sccs[i].size() << " variables" << endl;
        for (set<int>::iterator it = sccs[i].begin(); it != sccs[i].end(); ++it){
            cout << "   " << g_fact_names[*it][0] << endl;
        }
        cout << "=========      end SCC; has size " << current_size << endl;
#endif
        if (is_leaf && (max_leaf_size == 0 || current_size <= max_leaf_size)){
            best_factoring.push_back(sccs[i]);
        }
    }
    return best_factoring;
}

Painting::FactoredVars Painting::get_fork_maximize_mobility(vector<int> used_vars, bool inverted) const {
    // perform the actual factoring
    
    typedef multimap<uint64_t, pair<vector<int>, set<int> > > CandSCCs;
    
#ifdef DEBUG_PAINTING
    cout << "maximizing leaf mobility" << endl;
#endif
    
    FactoredVars sccs = get_sccs(used_vars);
    
    FactoredVars best_factoring;

    if (sccs.size() == 1){
#ifdef DEBUG_PAINTING
    cout << "CG is a single SCC" << endl;
#endif
        return best_factoring;
    }
    
    vector<size_t> mobility(sccs.size(), 0);
    
    for (size_t i = 0; i < g_operators.size(); ++i){
        // only need to consider first effect, because each action
        // can only affect a single SCC, otherwise, eff-eff cycles between
        // another SCC => contradiction
        int var = g_operators[i].get_effects()[0].var;
        for (size_t j = 0; j < sccs.size(); ++j){
            if (sccs[j].find(var) != sccs[j].end()){
                ++mobility[j];
            }
        }
    }
    
    vector<int> vars_to_sccs(g_variable_domain.size());
    
    bool all_sscs_fit_bound = true;
    
    uint64_t best_mobility = 1;
    
    uint64_t current_size = 1;
    
    // contains all leaf SCCs sorted by size
    CandSCCs canditate_sccs;

    for (size_t i = 0; i < sccs.size(); ++i){
        assert(mobility[i] > 0);
#ifdef DEBUG_PAINTING
        cout << "mobility of SCC " << i << " = " << mobility[i] << endl;
#endif
        
        set<int> succ_pred_sccs;
        current_size = 1;
        bool is_leaf = true;
        
        for (set<int>::iterator it = sccs[i].begin(); it != sccs[i].end(); ++it){
            int var = *it;
            vars_to_sccs[var] = i;
            if (current_size <= max_leaf_size){
                current_size *= g_variable_domain[var];
            }

            size_t bound = g_causal_graph->get_successors(var).size();
            if (inverted){
                bound = g_causal_graph->get_predecessors(var).size();
            }
            for (size_t succ = 0; succ < bound; ++succ){
                int succ_pred;
                if (inverted){
                    succ_pred = g_causal_graph->get_predecessors(var)[succ];
                } else {
                    succ_pred = g_causal_graph->get_successors(var)[succ];
                }

                if (used_vars.empty() || used_vars.size() == g_variable_domain.size() 
                    || find(used_vars.begin(), used_vars.end(), succ_pred) != used_vars.end()){
                    if (sccs[i].find(succ_pred) == sccs[i].end()){
                        // SCC has successor/predecessor SCC
                        succ_pred_sccs.insert(-1);
                        is_leaf = false;
                    }
                }
            }
        }

#ifdef DEBUG_PAINTING
        cout << "=========      SCC with " << sccs[i].size() << " variables" << endl;
        for (set<int>::iterator it = sccs[i].begin(); it != sccs[i].end(); ++it){
            cout << "   " << g_fact_names[*it][0] << endl;
        }
        cout << "=========      end SCC; has size " << current_size << endl;
#endif
        if (max_leaf_size == 0 || current_size <= max_leaf_size){
            if (is_leaf){
                best_factoring.push_back(sccs[i]);
                best_mobility *= mobility[i];
            } else {
                canditate_sccs.insert(make_pair(current_size, make_pair(vector<int>(sccs[i].begin(), sccs[i].end()), succ_pred_sccs)));
            }
        } else {
            all_sscs_fit_bound = false;
#ifdef DEBUG_PAINTING
            cout << " => too large" << endl;
#endif
        }
    }
    
#ifdef DEBUG_PAINTING
    cout << "number leaf factors with leaf-SCCs only: " << best_factoring.size() << " mobility = " << best_mobility << endl;
    cout << "number canditate sccs: " << canditate_sccs.size() << endl;
#endif
    
    FactoredVars current_factoring = best_factoring;
    
    bool change = !all_sscs_fit_bound || canditate_sccs.size() > 1;
    while (change){

        change = false;
        
        // update interaction graph of remaining SCCs
        for (CandSCCs::iterator it = canditate_sccs.begin(); it != canditate_sccs.end(); ++it){
            set<int> &succ_pred_facts = it->second.second;
            succ_pred_facts.clear();
            
            const vector<int> &vars = it->second.first;
            
            for (size_t i = 0; i < vars.size(); ++i){
                bool found = true;
                size_t bound = g_causal_graph->get_successors(vars[i]).size();
                if (inverted){
                    bound = g_causal_graph->get_predecessors(vars[i]).size();
                }
                for (size_t var = 0; var < bound; ++var){
                    found = false;
                    int succ_pred;
                    if (inverted){
                        succ_pred = g_causal_graph->get_predecessors(vars[i])[var];
                    } else {
                        succ_pred = g_causal_graph->get_successors(vars[i])[var];
                    }
                    if (used_vars.empty() || used_vars.size() == g_variable_domain.size() 
                        || find(used_vars.begin(), used_vars.end(), succ_pred) != used_vars.end()){
                        if (find(vars.begin(), vars.end(), succ_pred) != vars.end()){
                            found = true;
                            continue;
                        }
                        for (size_t j = 0; j < current_factoring.size(); ++j){
                            if (current_factoring[j].find(succ_pred) != current_factoring[j].end()){
                                succ_pred_facts.insert(j);
                                found = true; 
                                break;
                            }
                        }
                        if (!found){
                            break;
                        }
                    }
                }
                if (!found){
                    succ_pred_facts.insert(-1);
                    break;
                }
            }
        }
        
        
        // find best SCC to add to leaves
        CandSCCs::iterator best_successor_scc;
        uint64_t successor_mobility = 0;

        for (CandSCCs::iterator it = canditate_sccs.begin(); it != canditate_sccs.end(); ++it){
            bool can_add = true;
            
            set<int> &succ_pred_sccs = it->second.second;
            
#ifdef DEBUG_PAINTING
            const vector<int> &variables = it->second.first;
            cout << "current SCC: " << variables.size() << " vars, size = " << it->first << endl;
            for (vector<int>::const_iterator d_it = variables.begin(); d_it != variables.end(); ++d_it){
                cout << "       " << g_fact_names[*d_it][0] << endl;
            }
#endif

            if (succ_pred_sccs.find(-1) != succ_pred_sccs.end()){
#ifdef DEBUG_PAINTING
                cout << "has non leaf-factor successors => drop for the moment" << endl;
#endif
                can_add = false;
            } else {
#ifdef DEBUG_PAINTING
                cout << "all successors are leaf factors => combining to new leaf factor" << endl;
#endif
                current_size = it->first;
                
                for (set<int>::iterator succ_it = succ_pred_sccs.begin(); succ_it != succ_pred_sccs.end(); ++succ_it){
                    const set<int> &successor = current_factoring[*succ_it];
                    for (set<int>::iterator succ_pred_vars = successor.begin(); succ_pred_vars != successor.end(); ++succ_pred_vars){
                        current_size *= g_variable_domain[*succ_pred_vars];
                        if (max_leaf_size != 0 && current_size > max_leaf_size){
                            break;
                        }
                    }
                    if (max_leaf_size != 0 && current_size > max_leaf_size){
                        break;
                    }
                }
                
                if (max_leaf_size != 0 && current_size > max_leaf_size){
                    can_add = false;
#ifdef DEBUG_PAINTING
                    cout << "resulting leaf factor would be too large" << endl;
#endif
                }
            }
            
            if (can_add){
                // reconstruct of which SCCs the current leaf factors consist
                uint64_t new_mobility = 1;
                vector<set<int> > sccs(current_factoring.size() + 1);
                for (size_t i = 0; i < current_factoring.size(); ++i){
                    for (set<int>::iterator v_it = current_factoring[i].begin(); v_it != current_factoring[i].end(); ++v_it){
                        sccs[i].insert(vars_to_sccs[*v_it]);
                    }
                }
                const set<int> &succ_pred_sccs = it->second.second;
                set<int> factors_to_remove;
                for (set<int>::iterator succ_it = succ_pred_sccs.begin(); succ_it != succ_pred_sccs.end(); ++succ_it){
                    const set<int> &successors = current_factoring[*succ_it];
                    for (set<int>::iterator scc_it = successors.begin(); scc_it != successors.end(); ++scc_it){
                        sccs.back().insert(vars_to_sccs[*scc_it]);
                    }
                    factors_to_remove.insert(*succ_it);
                }
                sccs.back().insert(vars_to_sccs[it->second.first.front()]);// the new SCC
                
                for (set<int>::reverse_iterator rem_it = factors_to_remove.rbegin(); rem_it != factors_to_remove.rend(); ++rem_it){
                    FactoredVars::iterator r_it = sccs.begin() + *rem_it;
                    sccs.erase(r_it);
                }                
                
                // compute mobility of potentially new factoring
                for (size_t i = 0; i < sccs.size(); ++i){
                    size_t mob = 0;
                    for (set<int>::iterator scc_it = sccs[i].begin(); scc_it != sccs[i].end(); ++scc_it){
                        mob += mobility[*scc_it];
                    }
                    new_mobility *= mob;
                }
#ifdef DEBUG_PAINTING
                cout << "new factoring would have mobility " << new_mobility << " and " << sccs.size() << " leaf factors" << endl;
#endif
                
                if (new_mobility > successor_mobility && sccs.size() >= min_number_leaves){
#ifdef DEBUG_PAINTING
                    cout << "better than current best successor factoring => replace" << endl;
#endif                    
                    best_successor_scc = it;
                    successor_mobility = new_mobility;
                    change = true;
                }
            }
        }
        
        // update best factoring and check if any candidates left
        if (change){
            const set<int> &succ_pred_sccs = best_successor_scc->second.second;
            
            current_factoring.push_back(set<int>());
            set<int> &new_factor = current_factoring.back();
            
            set<int> factors_to_remove;
            for (set<int>::iterator succ_it = succ_pred_sccs.begin(); succ_it != succ_pred_sccs.end(); ++succ_it){
                set<int> succ_pred = current_factoring[*succ_it];
                
                factors_to_remove.insert(*succ_it);
                for (set<int>::iterator var_it = succ_pred.begin(); var_it != succ_pred.end(); ++var_it){
                    new_factor.insert(*var_it);
                }
            }
            
            const vector<int> &variables = best_successor_scc->second.first;
            
            for (size_t i = 0; i < variables.size(); ++i){
                new_factor.insert(variables[i]);
            }
            
            for (set<int>::reverse_iterator rem_it = factors_to_remove.rbegin(); rem_it != factors_to_remove.rend(); ++rem_it){
                FactoredVars::iterator r_it = current_factoring.begin() + *rem_it;
                current_factoring.erase(r_it);
            }
                    
            canditate_sccs.erase(best_successor_scc);
            
            if (successor_mobility > best_mobility){
                best_factoring = current_factoring;
                best_mobility = successor_mobility;
#ifdef DEBUG_PAINTING
                cout << "found a new best factoring with " << best_factoring.size() << " leaf factors and mobility " << best_mobility << endl;
#endif
            }
            
            if (canditate_sccs.empty() || (all_sscs_fit_bound && canditate_sccs.size() == 1)){
#ifdef DEBUG_PAINTING
                cout << "no more candidates left, factoring completed" << endl;
#endif
                break;
            }
        }
    }
    
#ifdef DEBUG_PAINTING
    for (size_t i = 0; i < best_factoring.size(); i++){
        cout << "leaf factor " << i << endl;
        for (set<int>::iterator set_it = best_factoring[i].begin(); set_it != best_factoring[i].end(); ++set_it){
            cout << "   variable " << (*set_it) << " :"  << g_fact_names[*set_it][0] << endl;
        }
    }
    cout << "mobility: " << best_mobility << endl;
#endif

    return best_factoring;
}*/

vector<set<int> > Painting::get_sccs(vector<int> variables) const {
    vector<vector<int> > vars(g_variable_domain.size());
    size_t bound = variables.empty() ? g_variable_domain.size() : variables.size();
    for (size_t i = 0; i < bound; i++){
        if (variables.empty() || variables.size() == g_variable_domain.size()){
            vars[i] = g_causal_graph->get_successors(i);
        } else {
            vector<int> successors = g_causal_graph->get_successors(variables[i]);
            for (size_t succ = 0; succ < successors.size(); succ++){
                if (find(variables.begin(), variables.end(), successors[succ]) != variables.end()){
                    vars[variables[i]].push_back(successors[succ]);
                }
            }
        }
    }
    
    SCC scc(vars);
    vector<vector<int> > found_sccs = scc.get_result();
    vector<set<int> > real_sccs;
    
    for (size_t i = 0; i < found_sccs.size(); i++){
        if (found_sccs[i].size() != 1 || variables.empty() || variables.size() == g_variable_name.size()){
            real_sccs.push_back(set<int>(found_sccs[i].begin(), found_sccs[i].end()));
        } else if (find(variables.begin(), variables.end(), found_sccs[i][0]) != variables.end()){
	    // this can happen if not all variables are in *variables*
	    // the SCC class needs the input vector to be aligned very specifically
            real_sccs.push_back(set<int>(found_sccs[i].begin(), found_sccs[i].end()));
        }
    }
    
#ifdef DEBUG_PAINTING
    cout << "found " << real_sccs.size() << " SCCs" << endl;
#endif
    
    return real_sccs;
}

vector<set<int> > Painting::get_connected_components(vector<int> variables) const {
	vector<set<int> > components;

	vector<bool> vars(g_variable_domain.size(), false);
	for (size_t i = 0; i < variables.size(); i++) {
		vars[variables[i]] = true;
	}

	vector<bool> seen_vars(g_variable_domain.size(), false);
	vector<int> var_comp_map(g_variable_domain.size(), -1);

	size_t number_seen_vars = 0;

	set<int> open_vars;

	//cout << "before while" << endl;
	//cout << "variabled.size: " << variables.size() << endl;
	while (number_seen_vars < variables.size()) {
		//cout << "open_vars.size = " << open_vars.size() << endl;
		if (open_vars.empty()) {
			for (size_t i = 0; i < variables.size(); i++) {
				int var = variables[i];
				if (!seen_vars[var]) {
					open_vars.insert(var);
					var_comp_map[var] = components.size();
					components.push_back(set<int>());
					components[var_comp_map[var]].insert(var);
					break;
				}
			}
			continue;
		}

		//cout << "number_seen_vars: " << number_seen_vars << endl;

		int curr = *open_vars.begin();
		open_vars.erase(open_vars.begin());

		if (seen_vars[curr]) {
			continue;
		}

		seen_vars[curr] = true;
		number_seen_vars++;

		for (size_t pre = 0;
				pre < g_causal_graph->get_predecessors(curr).size(); pre++) {
			int var = g_causal_graph->get_predecessors(curr)[pre];
			if (vars[var]) {
				open_vars.insert(var);
				var_comp_map[var] = var_comp_map[curr];
				components[var_comp_map[var]].insert(var);
			}
		}
		for (size_t succ = 0;
				succ < g_causal_graph->get_successors(curr).size(); succ++) {
			int var = g_causal_graph->get_successors(curr)[succ];
			if (vars[var]) {
				open_vars.insert(var);
				var_comp_map[var] = var_comp_map[curr];
				components[var_comp_map[var]].insert(var);
			}
		}
	}
	return components;
}

void Painting::add_options_to_parser(OptionParser &parser) {
    // TODO add docu
    parser.add_option<bool>(
        "force_cg_leaves_red",
        "",
        "false"
    );
}

static Painting *_parse_cg_top_first(OptionParser &parser) {
    // TODO docu
    Painting::add_options_to_parser(parser);
    
    parser.add_option<int>(
        "number_black_vars",
        "",
        "",
        OptionFlags(false)
    );
    parser.add_option<int>(
        "ratio_black",
        "give the ratio in percent, i.e. ratio in [0, 100]",
        "0"
    );
    
    Options opts = parser.parse();

    CGTopFirstPainting *factoring = 0;
    if (!parser.dry_run()) {
        factoring = new CGTopFirstPainting(opts);
    }

    return factoring;
}

static Painting *_parse_cg_branches_first(OptionParser &parser) {
	Painting::add_options_to_parser(parser);

    parser.add_option<int>(
        "number_black_vars",
        "The number of variables to paint black",
        "",
        OptionFlags(false)
    );
    parser.add_option<int>(
        "ratio_black",
        "give the ratio in percent, i.e. ratio in [0, 100]",
        "0"
    );


	Options opts = parser.parse();
	CGBranchFirstPainting* factoring = 0;
    if (!parser.dry_run()) {
        factoring = new CGBranchFirstPainting(opts);
    }
	return factoring;
}

static Painting *_parse_ipc_first(OptionParser &parser) {
    Options opts = parser.parse();
    IPCFirst* factoring = 0;
    if (!parser.dry_run()) {
        factoring = new IPCFirst(opts);
    }
    return factoring;
}

static Painting *_parse_ipc_next(OptionParser &parser) {    
    Options opts = parser.parse();
    IPCNext* factoring = 0;
    if (!parser.dry_run()) {
        factoring = new IPCNext(opts);
    }
    return factoring;
}

static Plugin<Painting> _plugin_ipc_first("ipc_first", _parse_ipc_first);
static Plugin<Painting> _plugin_ipc_next("ipc_next", _parse_ipc_next);

static Plugin<Painting> _plugin_cg_top_first("cg_top_first", _parse_cg_top_first);
static Plugin<Painting> _plugin_cg_branches_first("cg_branches_first", _parse_cg_branches_first);

