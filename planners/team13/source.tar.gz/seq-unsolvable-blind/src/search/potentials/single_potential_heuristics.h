#ifndef POTENTIALS_SINGLE_POTENTIAL_HEURISTICS_H
#define POTENTIALS_SINGLE_POTENTIAL_HEURISTICS_H

/*
  The corresponding .cc file defines plugins that create single
  potential heuristics.

  We keep the empty header to simplify our build system.
*/

#endif
