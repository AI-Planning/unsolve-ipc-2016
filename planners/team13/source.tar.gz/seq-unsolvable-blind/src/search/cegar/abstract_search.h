#ifndef CEGAR_ABSTRACT_SEARCH_H
#define CEGAR_ABSTRACT_SEARCH_H

// TODO: Move include to .cc file when Arc typedef is no longer needed.
#include "abstract_state.h"

#include "../priority_queue.h"

#include <deque>
#include <unordered_set>
#include <utility>
#include <vector>

namespace cegar {
using AbstractStates = std::unordered_set<AbstractState *>;
using Solution = std::deque<Arc>;

class AbstractSearch {
    const std::vector<int> operator_costs;
    AbstractStates &states;
    const bool use_general_costs;

    AdaptiveQueue<AbstractState *> open_queue;
    Solution solution;

    void reset();

    void extract_solution(AbstractState *init, AbstractState *goal);

    // TODO: Replace use_h by lambda functions?
    AbstractState *astar_search(
        bool forward,
        bool use_h,
        AbstractStates *goals = nullptr,
        std::vector<int> *needed_costs = nullptr);

public:
    AbstractSearch(
        std::vector<int> &&operator_costs,
        AbstractStates &states,
        bool use_general_costs);
    ~AbstractSearch() = default;

    bool find_solution(AbstractState *init, AbstractStates &goals);

    void backwards_dijkstra(const AbstractStates goals);

    /*
      Settle all nodes in the abstract transition system and remember
      the minimum cost we need to keep for each operator in order not
      to decrease any heuristic values.
    */
    std::vector<int> get_needed_costs(AbstractState *init, int num_ops);

    const Solution &get_solution() {
        return solution;
    }
};
}

#endif
