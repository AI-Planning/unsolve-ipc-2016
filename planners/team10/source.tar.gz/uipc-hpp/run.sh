#! /bin/bash

./test_ilb -x -c 3 $1 $2 > log 2> err

last=`awk '/./{line=$0} END{print line}' log`

if [[ "$last" == "unsolvable" ]];
then
    echo $last
else if [[ "$last" == "solvable" ]];
then
    echo $last
else
    echo "unknown"
fi
fi
