/*
  TODO: This file is currently empty because we cannot even #include
  "token_parser.h" safely due to the tangled dependency with option_parser.h.
  Needs to be untangled.
*/
