#include "prunable.h"

#include "../globals.h"
#include "../factoring.h"


using namespace std;


bool Prunable::store_frontier = false;

bool Prunable::propagate_goal_prices = false;

bool Prunable::do_pruning() {
    if (g_factoring->ipc && g_factoring->get_profile() != FORK){
        store_frontier = false;
        propagate_goal_prices = false;
        return false;
    }
    return store_frontier || propagate_goal_prices || !SimulationRelation::simulated_states.empty();
}
