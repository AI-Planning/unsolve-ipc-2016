#!/usr/bin/env python

# ONLY ONE COPY OF THIS SCRIPT CAN RUN AT A TIME AT ONE LOCATION (HELMERT's translate.py GENERATES A FILE output.sas, and thus two instances could overwrite each others' output)

import subprocess, time, os, sys, signal

global p
global q

p = None
q = None

def killer(signum, frame):
  sys.stdout.flush()
  if p:
    os.kill(p.pid, signal.SIGKILL)
  if q:
    os.kill(q.pid, signal.SIGKILL)   
  sys.exit(0)

if __name__ == "__main__":  
  # first parse the params
  
  domain   = sys.argv[-3]
  instance = sys.argv[-1]
  to_exec  = sys.argv[1:-4]
  
  # """
  print "domain", domain
  print "instance", instance
  print "to_exec", to_exec
  # """
  
  x = time.time()
  
  # register killer
  signal.signal(signal.SIGINT, killer)  
  
  # clear the input file
  # p = subprocess.Popen("rm output.sas",shell=True)
  # p.wait()
  
  # translate to sas
  # p = subprocess.Popen(["python3","MinireachIC3/translate/translate.py",domain,instance])
  # p.wait()
  
  # we use precomputed sas files instead of translation each time
  # sasi = instance+".sas"
  sasi = "output.sas"
  
  # clear the results file (no result reporting anymore ...)
  p = subprocess.Popen("rm -f output.sas.soln",shell=True)
  p.wait()
  
  # translate to spec and "pipe it" to executable writing the result to 'output.sas.soln'
  # we simulate the pipe here since with running Popen with shell=True we lose the ability to kill the respective processes (killing the shell process itself is not enough)
  #print sasi
  #p = subprocess.Popen(["java","-Xmx4028m","-jar","MinireachIC3/srt.jar","compactReinforced",sasi],stdout=subprocess.PIPE,bufsize=-1)
  p = subprocess.Popen(["java","-Xmx8192m","-jar","MinireachIC3/srt.jar","compactReinforced",sasi],stdout=subprocess.PIPE,bufsize=-1)
  q = subprocess.Popen(to_exec,stdin=subprocess.PIPE,stdout=subprocess.PIPE,bufsize=-1)

  nooutput = True
  for line in iter(p.stdout.readline, b''):
    #print "<<%s>>" % line
    q.stdin.write(line)
    nooutput = False

  q.stdin.close()

  if p.returncode or nooutput:
    print "Java error"
    killer(0,0)
  
  for line in q.stdout:
    print line,
  
  # the main part of the code for checking solutions 
  # (the latest version of minireachIC3 would need "-psol" to print the solution)
  # the code below worked for the forward direction only
  # its main problem was that sometimes long solutions took long time to parse and write 
  # so there were a few cases combining plan being found with Timeout as the final result -> BAD!
  """
  output = open("output.sas.soln","w")  
  for line in q.stdout:    
    output.write(line)
    if "SAT" in line:
      print line
      print "TIME", time.time() - x
  output.close()
  sys.stdout.flush()  
  
  # run the checker 
  p = subprocess.Popen("java -jar MinireachIC3/srt.jar output.sas output.sas.soln",shell=True)
  p.wait()
  """
  
