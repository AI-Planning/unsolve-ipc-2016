#!/bin/bash

# USAGE: ./run.sh <domain.pddl> <problem.pddl>

dom=$1
prob=$2

#get the sas file
rm -f output.sas log.txt
python MinireachIC3/translate/translate.py $dom $prob &>> log.txt
condtest=`egrep "^[0-9]* [0-9]* [0-9]* [0-9]*" output.sas | cut -d" " -f1 | uniq`
if [ "$condtest" != "0" ]
then
echo "The problem contains conditional effects"
exit
fi

#try to solve it with bfs
echo "Attempting to solve using BFS ============================================================================" &>> log.txt
#timeout 6m java -Xmx`ulimit -v` -jar bfs.jar output.sas &>> log.txt
#timeout 6m java -Xmx4028m -jar bfs.jar output.sas &>> log.txt
#timeout 6m java -Xmx8192m -jar bfs.jar output.sas &>> log.txt
./ctimeout 360 java -Xmx8192m -jar bfs.jar output.sas &>> log.txt
if [[ `grep "Plan does not exist" log.txt` ]]
then
    echo "unsolvable"
    echo "BFS solved the problem" &>> log.txt
    exit
fi
if [[ `grep ";Solved;" log.txt` ]]
then
    echo "solvable"
    echo "BFS solved the problem" &>> log.txt
    exit
fi
echo " ... BFS failed" &>> log.txt
echo "Trying to solve with MiniReach QUIP0 ===========================================================================" &>> log.txt
#timeout 12m python MinireachIC3/wrapper-srt-compactReinforced.py MinireachIC3/minireachIC3_QUIP0 -format=dimspec -o $dom -f $prob &>> log.txt
./ctimeout 720 python MinireachIC3/wrapper-srt-compactReinforced.py MinireachIC3/minireachIC3_QUIP0 -format=dimspec -o $dom -f $prob &>> log.txt
if [[ `grep "// UNSAT:" log.txt` ]]
then
    echo "unsolvable"
    echo "QUIP0 solved the problem" &>> log.txt
    exit
fi
if [[ `grep "// SAT:" log.txt` ]]
then
    echo "solvable"
    echo "QUIP0 solved the problem" &>> log.txt
    exit
fi

echo " ... QUIP0 failed" &>> log.txt
echo "Trying to solve with MiniReach QUIP1 ===========================================================================" &>> log.txt
#python MinireachIC3/wrapper-srt-compactReinforced.py MinireachIC3/minireachIC3_QUIP1 -format=dimspec -o $dom -f $prob &>> log.txt
python MinireachIC3/wrapper-srt-compactReinforced.py MinireachIC3/minireachIC3_aux -format=dimspec -o $dom -f $prob &>> log.txt
if [[ `grep "// UNSAT:" log.txt` ]]
then
    echo "unsolvable"
    echo "QUIP1 solved the problem" &>> log.txt
    exit
fi
if [[ `grep "// SAT:" log.txt` ]]
then
    echo "solvable"
    echo "QUIP1 solved the problem" &>> log.txt
    exit
fi
